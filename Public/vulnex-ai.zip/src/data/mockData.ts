export type VulnerabilityCategory =
  | 'Injection'
  | 'Cross-Site Scripting'
  | 'Path Traversal'
  | 'Hardcoded Secrets'
  | 'Insecure Deserialization'
  | 'SSRF'
  | 'Broken Auth'
  | 'Prototype Pollution';

export type RemediationStatus =
  | 'Open'
  | 'Patch Ready'
  | 'In Review'
  | 'Verified Fixed'
  | 'Suppressed';

export type ConfidenceLevel = 'Deterministic' | 'High' | 'Medium' | 'Heuristic';

export interface Vulnerability {
  id: string;
  cwe: string;
  cve?: string; // NO fake CVEs allowed. Only genuine public CVEs if applicable.
  title: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  cvss: number;
  category: VulnerabilityCategory;
  repository: string;
  file: string;
  line: number;
  language: string;
  status: RemediationStatus;
  confidence: number; // 0-100 percentage
  confidenceLevel: ConfidenceLevel;
  evidenceSource: string;
  whyFlagged: string;
  potentialImpact: {
    confidentiality: 'High' | 'Medium' | 'Low' | 'None';
    integrity: 'High' | 'Medium' | 'Low' | 'None';
    availability: 'High' | 'Medium' | 'Low' | 'None';
    summary: string;
  };
  suggestedRemediation: string;
  description: string;
  attackVector: string;
  taintedFlow: string;
  vulnerableCode: string;
  surroundingContext?: {
    startLine: number;
    code: string;
  };
  patchedCode: string;
  patchExplanation: string;
  formalInvariant: string;
  validationTests: {
    name: string;
    type: 'Exploit Simulation' | 'Regression Unit Test' | 'Boundary Check';
    status: 'passed' | 'failed' | 'pending';
    duration: string;
    detail: string;
  }[];
}

export interface ScanRecord {
  id: string;
  repoName: string;
  branch: string;
  commitHash: string;
  language: string;
  timestamp: string;
  duration: string;
  findingsCount: number;
  highestSeverity: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'Completed' | 'Validating' | 'Failed';
  linesScanned: number;
}

export interface SecurityActivity {
  id: string;
  type: 'scan_completed' | 'vulnerability_found' | 'patch_generated' | 'validation_passed' | 'validation_failed';
  title: string;
  target: string;
  timestamp: string;
  severity?: 'Critical' | 'High' | 'Medium' | 'Low';
}

export const MOCK_SUMMARY = {
  totalFindings: 24,
  criticalFindings: 3,
  fixesValidated: 12,
  validationPassRate: 83,
  isDemo: true,
  lastUpdated: '12 minutes ago',
  activeScansCount: 0,
  repositoriesProtected: 14,
};

export const MOCK_SEVERITY_BREAKDOWN = {
  Critical: 3,
  High: 8,
  Medium: 9,
  Low: 4,
};

export const MOCK_CWE_DISTRIBUTION = [
  { cwe: 'CWE-89', name: 'SQL Injection', count: 6, percentage: 25 },
  { cwe: 'CWE-918', name: 'Server-Side Request Forgery', count: 5, percentage: 21 },
  { cwe: 'CWE-1321', name: 'Prototype Pollution', count: 4, percentage: 17 },
  { cwe: 'CWE-502', name: 'Deserialization of Untrusted Data', count: 3, percentage: 12 },
  { cwe: 'CWE-287', name: 'Improper Authentication', count: 3, percentage: 12 },
  { cwe: 'CWE-79', name: 'Cross-Site Scripting (Reflected)', count: 3, percentage: 12 },
];

export const MOCK_RECENT_SCANS: ScanRecord[] = [
  {
    id: 'SCN-2026-9021',
    repoName: 'checkout-service-api',
    branch: 'main',
    commitHash: 'a7f39b1',
    language: 'TypeScript',
    timestamp: 'Today, 11:42',
    duration: '42s',
    findingsCount: 7,
    highestSeverity: 'Critical',
    status: 'Completed',
    linesScanned: 38410,
  },
  {
    id: 'SCN-2026-9020',
    repoName: 'auth-gateway-v2',
    branch: 'release/2.4',
    commitHash: 'e92bc44',
    language: 'Go',
    timestamp: 'Today, 09:15',
    duration: '28s',
    findingsCount: 3,
    highestSeverity: 'Critical',
    status: 'Completed',
    linesScanned: 24190,
  },
  {
    id: 'SCN-2026-9019',
    repoName: 'payment-vault',
    branch: 'feat/token-exchange',
    commitHash: '6d1109a',
    language: 'Rust',
    timestamp: 'Yesterday, 17:30',
    duration: '1m 12s',
    findingsCount: 1,
    highestSeverity: 'High',
    status: 'Completed',
    linesScanned: 52400,
  },
  {
    id: 'SCN-2026-9018',
    repoName: 'k8s-ingress-controller',
    branch: 'master',
    commitHash: 'c881fa2',
    language: 'Go',
    timestamp: 'Oct 30, 2026',
    duration: '35s',
    findingsCount: 9,
    highestSeverity: 'High',
    status: 'Completed',
    linesScanned: 41200,
  },
  {
    id: 'SCN-2026-9017',
    repoName: 'inventory-worker',
    branch: 'main',
    commitHash: 'b331008',
    language: 'Python',
    timestamp: 'Oct 29, 2026',
    duration: '19s',
    findingsCount: 4,
    highestSeverity: 'Medium',
    status: 'Completed',
    linesScanned: 16820,
  },
];

export const MOCK_SECURITY_ACTIVITIES: SecurityActivity[] = [
  {
    id: 'act-1',
    type: 'scan_completed',
    title: 'Scan completed on checkout-service-api',
    target: 'Branch main (commit a7f39b1)',
    timestamp: '14m ago',
    severity: 'Critical',
  },
  {
    id: 'act-2',
    type: 'vulnerability_found',
    title: 'High-severity finding identified in auth/jwt_verifier.go',
    target: 'CWE-287: Missing Signature Algorithm Validation',
    timestamp: '1h ago',
    severity: 'High',
  },
  {
    id: 'act-3',
    type: 'validation_failed',
    title: 'Patch validation failed on data/sanitizer.ts',
    target: 'Regression test: Boundary payload with Unicode nulls timed out',
    timestamp: '3h ago',
    severity: 'Medium',
  },
  {
    id: 'act-4',
    type: 'validation_passed',
    title: 'Proposed fix passed regression & exploit checks',
    target: 'payment-vault: src/crypto/envelope.rs (14/14 tests verified)',
    timestamp: '5h ago',
    severity: 'Critical',
  },
  {
    id: 'act-5',
    type: 'patch_generated',
    title: 'AI synthesized AST invariant patch for SQL Injection',
    target: 'src/controllers/orderController.ts line 42',
    timestamp: 'Yesterday',
    severity: 'Critical',
  },
];

export const MOCK_VULNERABILITIES: Vulnerability[] = [
  {
    id: 'VULN-2026-8941',
    cwe: 'CWE-89',
    title: 'Tainted SQL Injection via Raw String Interpolation in Customer Query',
    severity: 'Critical',
    cvss: 9.8,
    category: 'Injection',
    repository: 'checkout-service-api',
    file: 'src/controllers/orderController.ts',
    line: 42,
    language: 'TypeScript',
    status: 'Patch Ready',
    confidence: 99,
    confidenceLevel: 'Deterministic',
    evidenceSource: 'AST Taint Propagation Engine (Inter-procedural Dataflow)',
    whyFlagged: 'Direct string template interpolation into database driver raw statement without parameter tokenization.',
    potentialImpact: {
      confidentiality: 'High',
      integrity: 'High',
      availability: 'High',
      summary: 'Complete database extraction, authentication bypass via SQL tautology, and arbitrary record tampering.',
    },
    suggestedRemediation: 'Replace dynamic string concatenation with parameterized prepared statements ($1, $2) and strictly sanitize HTTP parameters.',
    description: 'Unsanitized user input from `req.query.customerId` is directly concatenated into a dynamic SQL query string executed via `db.raw()`. An attacker can manipulate this parameter to inject arbitrary SQL statements, bypass row-level access controls, and dump customer payment tokens.',
    attackVector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H',
    taintedFlow: 'req.query.customerId (Source) → customerFilter [no sanitizer] → db.raw(sql) (Sink)',
    surroundingContext: {
      startLine: 32,
      code: `// Express Route Controller: Customer Order History
// Endpoint: GET /api/v1/orders/history
export async function getCustomerOrderHistory(req: Request, res: Response) {
  const customerId = req.query.customerId as string;
  const status = req.query.status as string || 'ACTIVE';

  if (!req.headers['x-api-key']) {
    return res.status(401).json({ error: 'Missing API Key' });
  }

  // Line 42 Flagged: Unsanitized input interpolated directly into SQL syntax
  const query = \`
    SELECT id, total_amount, currency, created_at, status
    FROM customer_orders
    WHERE customer_id = '\${customerId}'
      AND order_status = '\${status}'
    ORDER BY created_at DESC
  \`;

  const results = await db.raw(query);
  return res.json({ orders: results.rows });
}`,
    },
    vulnerableCode: `export async function getCustomerOrderHistory(req: Request, res: Response) {
  const customerId = req.query.customerId as string;
  const status = req.query.status as string || 'ACTIVE';

  // VULNERABLE: Direct string interpolation into raw query
  const query = \`
    SELECT id, total_amount, currency, created_at, status
    FROM customer_orders
    WHERE customer_id = '\${customerId}'
      AND order_status = '\${status}'
    ORDER BY created_at DESC
  \`;

  const results = await db.raw(query);
  return res.json({ orders: results.rows });
}`,
    patchedCode: `export async function getCustomerOrderHistory(req: Request, res: Response) {
  const customerId = typeof req.query.customerId === 'string' ? req.query.customerId.trim() : null;
  const status = typeof req.query.status === 'string' ? req.query.status.trim() : 'ACTIVE';

  if (!customerId || !/^[a-zA-Z0-9_-]{8,64}$/.test(customerId)) {
    return res.status(400).json({ error: 'Invalid customer identifier format' });
  }

  // SECURE: Parameterized prepared statement with strictly typed bindings
  const query = \`
    SELECT id, total_amount, currency, created_at, status
    FROM customer_orders
    WHERE customer_id = $1
      AND order_status = $2
    ORDER BY created_at DESC
  \`;

  const results = await db.query(query, [customerId, status]);
  return res.json({ orders: results.rows });
}`,
    patchExplanation: 'Replaces raw template literal interpolation with PostgreSQL parameterized placeholders ($1, $2) and passes sanitized arguments through the driver binding engine. Added strict regex validation to reject malicious hex or comment sequences before query dispatch.',
    formalInvariant: 'AST invariant holds: Taint flow graph edge between HTTP parameter and QueryTokenizer is severed. String concatenation node removed from QueryBuilder AST.',
    validationTests: [
      {
        name: "Exploit Vector: ' OR '1'='1' --",
        type: 'Exploit Simulation',
        status: 'passed',
        duration: '14ms',
        detail: 'Injected tautology string treated purely as literal parameter string; zero SQL syntax divergence.',
      },
      {
        name: 'Exploit Vector: Stacked Query Injection (;\x00 DROP TABLE)',
        type: 'Exploit Simulation',
        status: 'passed',
        duration: '18ms',
        detail: 'PostgreSQL driver rejects multiple statements in parameterized query mode.',
      },
      {
        name: 'Unit Regression: Standard Order Retrieval',
        type: 'Regression Unit Test',
        status: 'passed',
        duration: '9ms',
        detail: 'Expected 4 active orders returned matching customerId "cust_9921_alpha".',
      },
      {
        name: 'Boundary Test: Unicode & Hex Obfuscation',
        type: 'Boundary Check',
        status: 'passed',
        duration: '12ms',
        detail: 'Validation filter returns HTTP 400 without touching database pool.',
      },
    ],
  },
  {
    id: 'VULN-2026-7901',
    cwe: 'CWE-79',
    title: 'Reflected Cross-Site Scripting via Unescaped dangerouslySetInnerHTML',
    severity: 'High',
    cvss: 7.5,
    category: 'Cross-Site Scripting',
    repository: 'checkout-service-api',
    file: 'src/views/searchHighlight.tsx',
    line: 64,
    language: 'TypeScript',
    status: 'Open',
    confidence: 95,
    confidenceLevel: 'High',
    evidenceSource: 'DOM AST Sink Detector & Data Flow Graph',
    whyFlagged: 'Client-side query parameter passed directly to dangerouslySetInnerHTML without sanitization library (DOMPurify).',
    potentialImpact: {
      confidentiality: 'High',
      integrity: 'Medium',
      availability: 'None',
      summary: 'Session hijacking via document.cookie theft, CSRF token exfiltration, and malicious UI overlay manipulation.',
    },
    suggestedRemediation: 'Use safe React text nodes or sanitize markup with DOMPurify with strict HTML tag and attribute allowlists.',
    description: 'Search query terms extracted from the URL query string `?q=` are rendered into the DOM using `dangerouslySetInnerHTML` to support search keyword bolding. An attacker can construct a crafted phishing link containing `<script>` or `<img onerror=...>` tags.',
    attackVector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:H/I:L/A:N',
    taintedFlow: 'window.location.search (?q=) → searchTerms → highlightMarkup() → dangerouslySetInnerHTML (Sink)',
    surroundingContext: {
      startLine: 54,
      code: `export const SearchHighlightSnippet: React.FC<SearchProps> = ({ text, query }) => {
  if (!query) return <span>{text}</span>;

  // Unsanitized regex replacement generating raw markup
  const formattedHtml = text.replace(
    new RegExp(\`(\${query})\`, 'gi'),
    '<mark class="search-match">$1</mark>'
  );

  // Line 64 Flagged: Injected payload evaluated in browsing context
  return <div dangerouslySetInnerHTML={{ __html: formattedHtml }} />;
};`,
    },
    vulnerableCode: `export const SearchHighlightSnippet: React.FC<SearchProps> = ({ text, query }) => {
  // VULNERABLE: Direct unescaped markup injection
  const formattedHtml = text.replace(
    new RegExp(\`(\${query})\`, 'gi'),
    '<mark class="search-match">$1</mark>'
  );
  return <div dangerouslySetInnerHTML={{ __html: formattedHtml }} />;
};`,
    patchedCode: `import DOMPurify from 'dompurify';

export const SearchHighlightSnippet: React.FC<SearchProps> = ({ text, query }) => {
  // SECURE: Strict escape & sanitize before HTML injection
  const sanitizedQuery = DOMPurify.sanitize(query.replace(/[.*+?^$\\{}()|[\\]\\\\]/g, '\\\\$&'));
  if (!sanitizedQuery) return <span>{text}</span>;

  const parts = text.split(new RegExp(\`(\${sanitizedQuery})\`, 'gi'));
  return (
    <span>
      {parts.map((part, i) =>
        part.toLowerCase() === sanitizedQuery.toLowerCase() ? (
          <mark key={i} className="search-match font-semibold bg-cyan-400/20 text-cyan-200 px-1 rounded">
            {part}
          </mark>
        ) : (
          part
        )
      )}
    </span>
  );
};`,
    patchExplanation: 'Removes dangerouslySetInnerHTML entirely in favor of native React JSX virtual DOM nodes, inherently preventing script evaluation. Added regex character escaping.',
    formalInvariant: 'DOM Invariant: Zero raw HTML elements rendered through unchecked DOM bypasses.',
    validationTests: [
      {
        name: 'Exploit Simulation: <img src=x onerror=alert(1)>',
        type: 'Exploit Simulation',
        status: 'passed',
        duration: '10ms',
        detail: 'Rendered as literal string in Virtual DOM text node; script execution thwarted.',
      },
      {
        name: 'Unit Test: Regular text query highlighting',
        type: 'Regression Unit Test',
        status: 'passed',
        duration: '6ms',
        detail: 'Matched phrases correctly enclosed in <mark> tags without visual defect.',
      },
    ],
  },
  {
    id: 'VULN-2026-2201',
    cwe: 'CWE-22',
    title: 'Path Traversal via Unvalidated User File Parameter in Local Storage',
    severity: 'Critical',
    cvss: 9.1,
    category: 'Path Traversal',
    repository: 'auth-gateway-v2',
    file: 'pkg/storage/local_store.go',
    line: 73,
    language: 'Go',
    status: 'Patch Ready',
    confidence: 98,
    confidenceLevel: 'Deterministic',
    evidenceSource: 'Symbolic Path Reachability & File Sink Taint Analysis',
    whyFlagged: 'filepath.Join used with untrusted relative path segments without resolving canonical path boundaries.',
    potentialImpact: {
      confidentiality: 'High',
      integrity: 'Low',
      availability: 'None',
      summary: 'Arbitrary filesystem read across host environment, including /etc/shadow, container secrets, and cloud service account credentials.',
    },
    suggestedRemediation: 'Clean path with filepath.Clean, resolve symlinks, and assert filepath.HasPrefix against the root storage directory before opening.',
    description: 'The asset storage handler accepts a `filename` parameter and concatenates it directly with the base directory using `filepath.Join()`. Attackers using sequence `../../../../etc/passwd` can escape the base directory and read sensitive system files.',
    attackVector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N',
    taintedFlow: 'req.URL.Query().Get("filename") → filepath.Join(baseDir, filename) → os.Open(path) (Sink)',
    surroundingContext: {
      startLine: 62,
      code: `func (s *LocalStorage) RetrieveAsset(w http.ResponseWriter, r *http.Request) {
    fileName := r.URL.Query().Get("filename")
    if fileName == "" {
        http.Error(w, "missing filename parameter", http.StatusBadRequest)
        return
    }

    // Line 73 Flagged: Path traversal vulnerable Join
    targetPath := filepath.Join(s.BaseDir, fileName)
    data, err := os.ReadFile(targetPath)
    if err != nil {
        http.Error(w, "file not found", http.StatusNotFound)
        return
    }
    w.Write(data)
}`,
    },
    vulnerableCode: `func (s *LocalStorage) RetrieveAsset(w http.ResponseWriter, r *http.Request) {
    fileName := r.URL.Query().Get("filename")
    // VULNERABLE: Direct Join allows ../ directory traversal
    targetPath := filepath.Join(s.BaseDir, fileName)
    data, err := os.ReadFile(targetPath)
    if err != nil {
        http.Error(w, "file not found", http.StatusNotFound)
        return
    }
    w.Write(data)
}`,
    patchedCode: `func (s *LocalStorage) RetrieveAsset(w http.ResponseWriter, r *http.Request) {
    fileName := r.URL.Query().Get("filename")
    if fileName == "" {
        http.Error(w, "missing filename parameter", http.StatusBadRequest)
        return
    }

    // SECURE: Enforce clean base boundary containment
    cleanBase := filepath.Clean(s.BaseDir)
    targetPath := filepath.Clean(filepath.Join(cleanBase, fileName))

    rel, err := filepath.Rel(cleanBase, targetPath)
    if err != nil || strings.HasPrefix(rel, "..") || rel == "." {
        http.Error(w, "access denied: invalid path location", http.StatusForbidden)
        return
    }

    data, err := os.ReadFile(targetPath)
    if err != nil {
        http.Error(w, "file not found", http.StatusNotFound)
        return
    }
    w.Write(data)
}`,
    patchExplanation: 'Uses filepath.Rel after filepath.Clean to rigorously assert that the requested file path cannot traverse outside the designated base directory boundary.',
    formalInvariant: 'Path Invariant: targetPath is guaranteed to reside strictly within sub-tree of cleanBase.',
    validationTests: [
      {
        name: 'Exploit Simulation: filename=../../../../etc/passwd',
        type: 'Exploit Simulation',
        status: 'passed',
        duration: '11ms',
        detail: 'Rejected with HTTP 403 Forbidden; path traversal detected.',
      },
      {
        name: 'Exploit Simulation: Null byte %00 truncation attack',
        type: 'Exploit Simulation',
        status: 'passed',
        duration: '8ms',
        detail: 'Null byte rejected during filepath.Clean parsing.',
      },
      {
        name: 'Regression Test: Valid subfolder asset retrieval',
        type: 'Regression Unit Test',
        status: 'passed',
        duration: '14ms',
        detail: 'Successfully reads assets/logos/brand.svg.',
      },
    ],
  },
  {
    id: 'VULN-2026-7980',
    cwe: 'CWE-798',
    title: 'Hardcoded High-Entropy Production Secret in Cryptographic Key Exchange',
    severity: 'Critical',
    cvss: 9.4,
    category: 'Hardcoded Secrets',
    repository: 'payment-vault',
    file: 'src/config/vault_credentials.rs',
    line: 19,
    language: 'Rust',
    status: 'In Review',
    confidence: 100,
    confidenceLevel: 'Deterministic',
    evidenceSource: 'Shannon Entropy Analyzer & Secret Pattern Matcher',
    whyFlagged: 'High-entropy 256-bit hexadecimal string detected in source code constant (Entropy: 4.82 bits/byte).',
    potentialImpact: {
      confidentiality: 'High',
      integrity: 'High',
      availability: 'Medium',
      summary: 'Immediate compromise of customer PAN data encrypted at rest and token signing authority across all production vaults.',
    },
    suggestedRemediation: 'Migrate secret to AWS Secrets Manager / HashiCorp Vault and load dynamically via sealed environment variables.',
    description: 'A static production cryptographic master key was committed directly to the repository codebase. Anyone with read access to the Git repository or build artifacts can decrypt customer credit card tokens stored in the secure database vault.',
    attackVector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N',
    taintedFlow: 'Hardcoded Constant (Source) → VAULT_MASTER_KEY → aes_256_gcm::decrypt (Sink)',
    surroundingContext: {
      startLine: 10,
      code: `pub struct VaultConfig {
    pub key_id: String,
    pub region: String,
}

// Line 19 Flagged: Hardcoded 32-byte production AES key
const VAULT_MASTER_KEY: &[u8; 32] = b"f9a1b0284c17398e09f4812a57c9134b";

pub fn get_cipher_key() -> Result<[u8; 32], VaultError> {
    Ok(*VAULT_MASTER_KEY)
}`,
    },
    vulnerableCode: `// VULNERABLE: Static production key committed to repository
const VAULT_MASTER_KEY: &[u8; 32] = b"f9a1b0284c17398e09f4812a57c9134b";

pub fn get_cipher_key() -> Result<[u8; 32], VaultError> {
    Ok(*VAULT_MASTER_KEY)
}`,
    patchedCode: `use std::env;
use zeroize::Zeroizing;

pub fn get_cipher_key() -> Result<Zeroizing<[u8; 32]>, VaultError> {
    // SECURE: Load secret strictly from runtime KMS / secure enclave environment
    let raw_hex = env::var("VAULT_MASTER_KEY_SECRET")
        .map_err(|_| VaultError::MissingSecretEnv)?;

    let mut key_bytes = [0u8; 32];
    hex::decode_to_slice(&raw_hex, &mut key_bytes)
        .map_err(|_| VaultError::InvalidKeyFormat)?;

    Ok(Zeroizing::new(key_bytes))
}`,
    patchExplanation: 'Removes static constant from binary artifact, reads hex key strictly from runtime environment or KMS secret store, and wraps in Zeroizing memory envelope to clear RAM upon deallocation.',
    formalInvariant: 'Secret Invariant: Zero cryptographic key literals found in static binary AST or symbol table.',
    validationTests: [
      {
        name: 'Entropy Scan: Binary symbol table check',
        type: 'Exploit Simulation',
        status: 'passed',
        duration: '16ms',
        detail: 'Zero high-entropy strings detected in compiled binary text section.',
      },
      {
        name: 'Regression Test: Environment variable loading',
        type: 'Regression Unit Test',
        status: 'passed',
        duration: '9ms',
        detail: 'Correctly decodes 256-bit key from mock vault test provider.',
      },
    ],
  },
  {
    id: 'VULN-2026-5021',
    cwe: 'CWE-502',
    title: 'Insecure Deserialization of Python Pickle in Session Cache Consumer',
    severity: 'High',
    cvss: 8.8,
    category: 'Insecure Deserialization',
    repository: 'inventory-worker',
    file: 'worker/cache_consumer.py',
    line: 38,
    language: 'Python',
    status: 'Patch Ready',
    confidence: 97,
    confidenceLevel: 'High',
    evidenceSource: 'Unsafe Deserialization AST Rule & Object Graph Walker',
    whyFlagged: 'Invocation of pickle.loads on unauthenticated Redis message byte stream.',
    potentialImpact: {
      confidentiality: 'High',
      integrity: 'High',
      availability: 'High',
      summary: 'Remote Code Execution (RCE) inside the worker container using custom __reduce__ gadget chains.',
    },
    suggestedRemediation: 'Replace pickle deserialization with strict JSON format enforced by Pydantic / dataclass schemas.',
    description: 'Redis worker pops byte payloads from job queues and invokes `pickle.loads()` without cryptographically signed HMAC envelope, permitting remote code execution via `__reduce__` exploit payloads.',
    attackVector: 'CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H',
    taintedFlow: 'redis.rpop(queue) → pickle.loads(raw_bytes) (Sink)',
    surroundingContext: {
      startLine: 28,
      code: `import pickle
import redis
import logging

logger = logging.getLogger("worker")

# Line 38 Flagged: Arbitrary pickle execution
def process_cached_session(redis_client, queue_key):
    payload = redis_client.rpop(queue_key)
    if payload:
        session_data = pickle.loads(payload)
        return session_data
    return None`,
    },
    vulnerableCode: `def process_cached_session(redis_client, queue_key):
    # VULNERABLE: Direct deserialization of untrusted byte stream
    payload = redis_client.rpop(queue_key)
    if payload:
        session_data = pickle.loads(payload)
        return session_data
    return None`,
    patchedCode: `import json
from pydantic import BaseModel, ValidationError

class SessionModel(BaseModel):
    user_id: str
    session_id: str
    role: str
    expires_at: int

def process_cached_session(redis_client, queue_key):
    # SECURE: Safe JSON serialization with strict Pydantic schema validation
    payload = redis_client.rpop(queue_key)
    if not payload:
        return None
    try:
        raw_dict = json.loads(payload.decode('utf-8'))
        session = SessionModel(**raw_dict)
        return session.dict()
    except (json.JSONDecodeError, ValidationError) as e:
        logger.error(f"Malicious or corrupted session payload discarded: {e}")
        return None`,
    patchExplanation: 'Replaces dangerous arbitrary-object pickle deserialization with structured JSON parsing backed by strict Pydantic model validation.',
    formalInvariant: 'Execution invariant: Deserializer AST strictly maps to scalar and dictionary primitives; code execution primitives are unreachable.',
    validationTests: [
      {
        name: 'Exploit Simulation: Python __reduce__ RCE Payload (os.system)',
        type: 'Exploit Simulation',
        status: 'passed',
        duration: '15ms',
        detail: 'Payload rejected by json.loads with JSONDecodeError; zero code executed.',
      },
      {
        name: 'Regression Test: Valid JSON Session Payload',
        type: 'Regression Unit Test',
        status: 'passed',
        duration: '8ms',
        detail: 'Valid session instantiated with correct schema fields.',
      },
    ],
  },
  {
    id: 'VULN-2026-9182',
    cwe: 'CWE-918',
    title: 'Blind SSRF via Unrestricted Webhook Notification URL Dispatch',
    severity: 'Critical',
    cvss: 9.3,
    category: 'SSRF',
    repository: 'auth-gateway-v2',
    file: 'pkg/webhook/dispatcher.go',
    line: 88,
    language: 'Go',
    status: 'Patch Ready',
    confidence: 96,
    confidenceLevel: 'High',
    evidenceSource: 'AST Inter-procedural Egress Reachability Solver',
    whyFlagged: 'Outbound HTTP request client constructed without private IP or loopback filtration.',
    potentialImpact: {
      confidentiality: 'High',
      integrity: 'High',
      availability: 'None',
      summary: 'Cloud instance metadata service access (169.254.169.254) leading to temporary IAM role credential exfiltration.',
    },
    suggestedRemediation: 'Implement custom net.Dialer to resolve and filter IP ranges (RFC 1918, RFC 3927, loopback) prior to socket connection.',
    description: 'The webhook notification subsystem executes HTTP POST requests to user-supplied endpoints without verifying IP ownership or blocking RFC 1918 internal addresses and cloud metadata services (169.254.169.254).',
    attackVector: 'CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:C/C:H/I:H/A:N',
    taintedFlow: 'tenantConfig.WebhookURL → net/http.Client.Post (Sink)',
    surroundingContext: {
      startLine: 78,
      code: `package webhook

import (
    "bytes"
    "context"
    "net/http"
    "time"
)

// Line 88 Flagged: Webhook dispatches to any arbitrary destination
func DispatchWebhook(ctx context.Context, targetURL string, payload []byte) (*http.Response, error) {
    req, err := http.NewRequestWithContext(ctx, "POST", targetURL, bytes.NewReader(payload))
    if err != nil {
        return nil, err
    }
    req.Header.Set("Content-Type", "application/json")
    
    client := &http.Client{Timeout: 10 * time.Second}
    return client.Do(req)
}`,
    },
    vulnerableCode: `func DispatchWebhook(ctx context.Context, targetURL string, payload []byte) (*http.Response, error) {
    // VULNERABLE: Direct outbound request without IP restriction
    req, err := http.NewRequestWithContext(ctx, "POST", targetURL, bytes.NewReader(payload))
    if err != nil {
        return nil, err
    }
    req.Header.Set("Content-Type", "application/json")
    
    client := &http.Client{Timeout: 10 * time.Second}
    return client.Do(req)
}`,
    patchedCode: `func DispatchWebhook(ctx context.Context, targetURL string, payload []byte) (*http.Response, error) {
    parsed, err := url.Parse(targetURL)
    if err != nil || (parsed.Scheme != "https") {
        return nil, errors.New("webhook URL must strictly use HTTPS")
    }

    // SECURE: Custom DialContext enforcing private subnet and metadata blocking
    dialer := &net.Dialer{Timeout: 5 * time.Second}
    transport := &http.Transport{
        DialContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
            host, port, _ := net.SplitHostPort(addr)
            ips, err := net.LookupIP(host)
            if err != nil {
                return nil, err
            }
            for _, ip := range ips {
                if ip.IsPrivate() || ip.IsLoopback() || ip.IsLinkLocalUnicast() || ip.String() == "169.254.169.254" {
                    return nil, fmt.Errorf("SSRF guard: target IP %s belongs to restricted address space", ip.String())
                }
            }
            return dialer.DialContext(ctx, network, net.JoinHostPort(ips[0].String(), port))
        },
    }

    client := &http.Client{Transport: transport, Timeout: 8 * time.Second}
    req, _ := http.NewRequestWithContext(ctx, "POST", targetURL, bytes.NewReader(payload))
    req.Header.Set("Content-Type", "application/json")
    return client.Do(req)
}`,
    patchExplanation: 'Implements zero-trust egress filter on net.Dialer to resolve DNS ahead of TCP handshake and reject loopback, link-local, RFC-1918, and AWS/GCP/Azure instance metadata endpoints (169.254.169.254). Forces HTTPS.',
    formalInvariant: 'DNS re-binding invariant established: DialContext pins socket establishment to the verified non-internal IP returned during resolution.',
    validationTests: [
      {
        name: 'Exploit Simulation: AWS IMDSv1 Metadata Probe (169.254.169.254)',
        type: 'Exploit Simulation',
        status: 'passed',
        duration: '11ms',
        detail: 'DialContext aborted socket creation with SSRF guard alert.',
      },
      {
        name: 'Exploit Simulation: Localhost Loopback Probe (127.0.0.1:6379)',
        type: 'Exploit Simulation',
        status: 'passed',
        duration: '8ms',
        detail: 'Connection blocked before TCP SYN sent to redis daemon.',
      },
      {
        name: 'Regression Test: Valid Customer Webhook on Cloudflare CDN',
        type: 'Regression Unit Test',
        status: 'passed',
        duration: '34ms',
        detail: 'Public IP allowed; webhook successfully dispatches payload.',
      },
    ],
  },
  {
    id: 'VULN-2026-1321',
    cwe: 'CWE-1321',
    title: 'Deep Merge Prototype Pollution in Configuration Ingestion Service',
    severity: 'High',
    cvss: 8.6,
    category: 'Prototype Pollution',
    repository: 'checkout-service-api',
    file: 'src/utils/configMerge.ts',
    line: 27,
    language: 'TypeScript',
    status: 'Patch Ready',
    confidence: 94,
    confidenceLevel: 'High',
    evidenceSource: 'Static AST Recursive Object Cloner Validator',
    whyFlagged: 'Object keys recursively traversed without checking for __proto__, constructor, or prototype.',
    potentialImpact: {
      confidentiality: 'Medium',
      integrity: 'High',
      availability: 'Medium',
      summary: 'Global prototype pollution enabling property injection across all downstream Node.js modules.',
    },
    suggestedRemediation: 'Disallow dangerous prototype keys (__proto__, constructor, prototype) or use Object.create(null).',
    description: 'Recursive key copy without Object.prototype guard allows attackers supplying JSON payloads with `__proto__` or `constructor.prototype` to mutate the global object prototype, leading to remote code execution or authentication bypass in downstream helpers.',
    attackVector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:L',
    taintedFlow: 'req.body.customConfig → mergeDeep(target, source) (Sink)',
    surroundingContext: {
      startLine: 18,
      code: `// Deep Config Merger utility
// Handles configuration cascade from tenant overrides
export function mergeDeep(target: any, source: any): any {
  // Line 27 Flagged: Unchecked key recursion
  for (const key of Object.keys(source)) {
    if (source[key] instanceof Object && key in target) {
      Object.assign(source[key], mergeDeep(target[key], source[key]));
    }
  }
  Object.assign(target || {}, source);
  return target;
}`,
    },
    vulnerableCode: `export function mergeDeep(target: any, source: any): any {
  for (const key of Object.keys(source)) {
    if (source[key] instanceof Object && key in target) {
      Object.assign(source[key], mergeDeep(target[key], source[key]));
    }
  }
  Object.assign(target || {}, source);
  return target;
}`,
    patchedCode: `export function mergeDeep(target: Record<string, any>, source: Record<string, any>): Record<string, any> {
  const result = Array.isArray(target) ? [...target] : { ...target };

  for (const key of Object.keys(source)) {
    // SECURE: Disallow pollution keys explicitly
    if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
      continue;
    }

    if (
      source[key] &&
      typeof source[key] === 'object' &&
      !Array.isArray(source[key])
    ) {
      result[key] = mergeDeep(result[key] || {}, source[key]);
    } else {
      result[key] = source[key];
    }
  }
  return result;
}`,
    patchExplanation: 'Explicitly filters out dangerous prototype manipulation keys (`__proto__`, `constructor`, `prototype`) and ensures recursive copies clone clean non-prototype object instances.',
    formalInvariant: 'AST invariant holds: ({}).polluted remains strictly undefined across all nested merge permutations.',
    validationTests: [
      {
        name: 'Exploit Simulation: JSON {"__proto__": {"isAdmin": true}}',
        type: 'Exploit Simulation',
        status: 'passed',
        duration: '7ms',
        detail: '({}).isAdmin returns undefined; prototype tampering prevented.',
      },
      {
        name: 'Unit Test: Deep Nested Config Overwrite',
        type: 'Regression Unit Test',
        status: 'passed',
        duration: '5ms',
        detail: 'Legitimate deep properties merged correctly without data loss.',
      },
    ],
  },
  {
    id: 'VULN-2026-2870',
    cwe: 'CWE-287',
    title: 'JWT Algorithm Confusion ("none" and HMAC/RSA Mismatch)',
    severity: 'Critical',
    cvss: 9.1,
    category: 'Broken Auth',
    repository: 'auth-gateway-v2',
    file: 'pkg/auth/jwt_verifier.go',
    line: 54,
    language: 'Go',
    status: 'Open',
    confidence: 92,
    confidenceLevel: 'High',
    evidenceSource: 'Cryptographic Primitive Verifier & Key Signature Flow',
    whyFlagged: 'jwt.ParseWithClaims callback does not assert *jwt.SigningMethodRSA type on parsed token header.',
    potentialImpact: {
      confidentiality: 'High',
      integrity: 'High',
      availability: 'None',
      summary: 'Complete authentication bypass allowing forged administrative JWTs signed with public key or unsigned alg:none.',
    },
    suggestedRemediation: 'Explicitly verify that token.Method is *jwt.SigningMethodRSA before returning the public verification key.',
    description: 'Verifier relies on token header alg field without enforcing a server-pinned algorithm list. An attacker can sign a token using the server public key as an HMAC secret or supply "alg": "none" to forge arbitrary claims.',
    attackVector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N',
    taintedFlow: 'req.Header.Authorization → jwt.Parse(token, keyFunc) (Sink)',
    surroundingContext: {
      startLine: 45,
      code: `package auth

import (
    "errors"
    "fmt"
    "github.com/golang-jwt/jwt/v4"
)

// Line 54 Flagged: Algorithm confusion flaw
func ValidateToken(tokenStr string) (*Claims, error) {
    token, err := jwt.ParseWithClaims(tokenStr, &Claims{}, func(token *jwt.Token) (interface{}, error) {
        return publicKey, nil
    })
    if err != nil {
        return nil, err
    }
    return token.Claims.(*Claims), nil
}`,
    },
    vulnerableCode: `func ValidateToken(tokenStr string) (*Claims, error) {
    // VULNERABLE: KeyFunc trusts the header algorithm without pinning
    token, err := jwt.ParseWithClaims(tokenStr, &Claims{}, func(token *jwt.Token) (interface{}, error) {
        return publicKey, nil
    })
    return token.Claims.(*Claims), err
}`,
    patchedCode: `func ValidateToken(tokenStr string) (*Claims, error) {
    // SECURE: Explicitly assert that the signing method matches RS256 only
    token, err := jwt.ParseWithClaims(tokenStr, &Claims{}, func(token *jwt.Token) (interface{}, error) {
        if _, ok := token.Method.(*jwt.SigningMethodRSA); !ok {
            return nil, fmt.Errorf("unexpected signing algorithm: %v (expected RS256)", token.Header["alg"])
        }
        return publicKey, nil
    })
    if err != nil || !token.Valid {
        return nil, errors.New("invalid or forged token signature")
    }
    return token.Claims.(*Claims), nil
}`,
    patchExplanation: 'Adds a strict type assertion on token.Method to require *jwt.SigningMethodRSA, completely eliminating algorithm confusion attacks and alg:none bypasses.',
    formalInvariant: 'Cryptographic assertion: No asymmetric key can be fed into symmetric HMAC verification path.',
    validationTests: [
      {
        name: 'Exploit Simulation: Forge token with alg:none',
        type: 'Exploit Simulation',
        status: 'passed',
        duration: '9ms',
        detail: 'Token rejected with "unexpected signing algorithm: none".',
      },
      {
        name: 'Exploit Simulation: HMAC with RSA Public Key',
        type: 'Exploit Simulation',
        status: 'passed',
        duration: '11ms',
        detail: 'Token rejected with "unexpected signing algorithm: HS256".',
      },
    ],
  },
  {
    id: 'VULN-2026-2202',
    cwe: 'CWE-22',
    title: 'Directory Traversal in Ingress Dynamic Plugin Reloader',
    severity: 'Medium',
    cvss: 6.5,
    category: 'Path Traversal',
    repository: 'k8s-ingress-controller',
    file: 'pkg/ingress/route_loader.go',
    line: 112,
    language: 'Go',
    status: 'Verified Fixed',
    confidence: 91,
    confidenceLevel: 'High',
    evidenceSource: 'Filesystem Sanitization Validator',
    whyFlagged: 'Path concatenation in plugin loader without root jail verification.',
    potentialImpact: {
      confidentiality: 'Medium',
      integrity: 'None',
      availability: 'None',
      summary: 'Reading arbitrary manifest files within the container namespace.',
    },
    suggestedRemediation: 'Confine plugin relative paths to trusted config directory via chroot or path containment check.',
    description: 'Dynamic plugin loader accepted relative configuration path arguments that could refer to files outside the plugin directory when prefixed with multiple dot segments.',
    attackVector: 'CVSS:3.1/AV:L/AC:L/PR:H/UI:N/S:U/C:H/I:N/A:N',
    taintedFlow: 'manifest.PluginPath → os.Open() (Sink)',
    surroundingContext: {
      startLine: 104,
      code: `func LoadPluginConfig(pluginName string) ([]byte, error) {
    // Line 112: Relative route loader
    path := fmt.Sprintf("/etc/ingress/plugins/%s.json", pluginName)
    return os.ReadFile(path)
}`,
    },
    vulnerableCode: `func LoadPluginConfig(pluginName string) ([]byte, error) {
    path := fmt.Sprintf("/etc/ingress/plugins/%s.json", pluginName)
    return os.ReadFile(path)
}`,
    patchedCode: `func LoadPluginConfig(pluginName string) ([]byte, error) {
    if !pluginRegex.MatchString(pluginName) {
        return nil, errors.New("illegal characters in plugin identifier")
    }
    path := filepath.Clean(filepath.Join("/etc/ingress/plugins", pluginName + ".json"))
    return os.ReadFile(path)
}`,
    patchExplanation: 'Enforces strict alphanumeric name matching and clean path containment.',
    formalInvariant: 'AST verification passes: pluginName strictly sanitized.',
    validationTests: [
      {
        name: 'Unit test: Valid plugin manifest',
        type: 'Regression Unit Test',
        status: 'passed',
        duration: '4ms',
        detail: 'Plugin loaded successfully.',
      },
    ],
  },
  {
    id: 'VULN-2026-7902',
    cwe: 'CWE-79',
    title: 'Heuristic DOM XSS in Customer Portal Header Announcement',
    severity: 'Medium',
    cvss: 6.1,
    category: 'Cross-Site Scripting',
    repository: 'checkout-service-api',
    file: 'src/components/NotificationBanner.tsx',
    line: 31,
    language: 'TypeScript',
    status: 'Suppressed',
    confidence: 76,
    confidenceLevel: 'Heuristic',
    evidenceSource: 'Heuristic Pattern Matcher (Flagged for Review)',
    whyFlagged: 'Potential unescaped string rendering in notification slot detected by static regex.',
    potentialImpact: {
      confidentiality: 'Low',
      integrity: 'Low',
      availability: 'None',
      summary: 'Restricted script execution in legacy banner fallback.',
    },
    suggestedRemediation: 'Suppress if input is verified server-side, or wrap with React text escaping.',
    description: 'Heuristic flag on older banner component where broadcast message is interpolated into the banner DOM element.',
    attackVector: 'CVSS:3.1/AV:N/AC:H/PR:L/UI:R/S:U/C:L/I:L/A:N',
    taintedFlow: 'broadcastPayload.message → Banner.innerHTML (Sink)',
    surroundingContext: {
      startLine: 24,
      code: `export const NotificationBanner = ({ message }: { message: string }) => {
  // Line 31: Heuristic scanner flagged unescaped slot
  return <div className="banner" dangerouslySetInnerHTML={{ __html: message }} />;
};`,
    },
    vulnerableCode: `export const NotificationBanner = ({ message }: { message: string }) => {
  return <div className="banner" dangerouslySetInnerHTML={{ __html: message }} />;
};`,
    patchedCode: `export const NotificationBanner = ({ message }: { message: string }) => {
  return <div className="banner">{message}</div>;
};`,
    patchExplanation: 'Swapped innerHTML for pure text node rendering.',
    formalInvariant: 'AST invariant holds.',
    validationTests: [
      {
        name: 'Sanitization check',
        type: 'Boundary Check',
        status: 'passed',
        duration: '3ms',
        detail: 'Escapes HTML entities safely.',
      },
    ],
  },
];

export const MOCK_REPOSITORIES = [
  { id: 'repo-1', name: 'checkout-service-api', defaultBranch: 'main', language: 'TypeScript', openVulnerabilities: 7 },
  { id: 'repo-2', name: 'auth-gateway-v2', defaultBranch: 'release/2.4', language: 'Go', openVulnerabilities: 3 },
  { id: 'repo-3', name: 'payment-vault', defaultBranch: 'feat/token-exchange', language: 'Rust', openVulnerabilities: 1 },
  { id: 'repo-4', name: 'k8s-ingress-controller', defaultBranch: 'master', language: 'Go', openVulnerabilities: 9 },
  { id: 'repo-5', name: 'inventory-worker', defaultBranch: 'main', language: 'Python', openVulnerabilities: 4 },
];

import React, { useState } from 'react';
import {
  LayoutDashboard,
  ScanSearch,
  History,
  ShieldAlert,
  Wrench,
  FlaskConical,
  FileText,
  Settings,
  ChevronLeft,
  ChevronRight,
  ChevronsUpDown,
} from 'lucide-react';
import { BrandLogo } from './BrandLogo';

export type NavigationTab = 
  | 'overview' 
  | 'new-scan' 
  | 'scan-history' 
  | 'vulnerabilities' 
  | 'remediation' 
  | 'validation-lab' 
  | 'reports' 
  | 'settings';

interface SidebarProps {
  currentTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  criticalCount: number;
  totalFindings: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  collapsed,
  onToggleCollapse,
  criticalCount,
  totalFindings,
}) => {
  const [workspaceOpen, setWorkspaceOpen] = useState(false);
  const [selectedWorkspace, setSelectedWorkspace] = useState('Acme Corp / SecOps Core');

  const workspaces = [
    'Acme Corp / SecOps Core',
    'Acme Corp / Payment Infrastructure',
    'FinTech Microservices / Prod',
  ];

  const navItems = [
    {
      id: 'overview' as NavigationTab,
      label: 'Overview',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'new-scan' as NavigationTab,
      label: 'New Scan',
      icon: ScanSearch,
      badge: 'Scan',
      badgeColor: 'text-[#38BDF8] bg-[#38BDF8]/15 border-[#38BDF8]/30',
    },
    {
      id: 'scan-history' as NavigationTab,
      label: 'Scan History',
      icon: History,
      badge: '5 Scans',
    },
    {
      id: 'vulnerabilities' as NavigationTab,
      label: 'Vulnerability Findings',
      icon: ShieldAlert,
      badge: `${totalFindings}`,
      badgeColor: criticalCount > 0 ? 'text-[#F87171] bg-[#F87171]/15 border-[#F87171]/30' : undefined,
    },
    {
      id: 'remediation' as NavigationTab,
      label: 'AI Remediation Lab',
      icon: Wrench,
      badge: 'Patches',
      badgeColor: 'text-[#60A5FA] bg-[#2563EB]/20 border-[#3B82F6]/30',
    },
    {
      id: 'validation-lab' as NavigationTab,
      label: 'Validation Lab',
      icon: FlaskConical,
      badge: '83% pass',
      badgeColor: 'text-[#34D399] bg-[#34D399]/15 border-[#34D399]/30',
    },
    {
      id: 'reports' as NavigationTab,
      label: 'Reports',
      icon: FileText,
      badge: null,
    },
    {
      id: 'settings' as NavigationTab,
      label: 'Settings',
      icon: Settings,
      badge: null,
    },
  ];

  return (
    <aside
      className={`fixed lg:sticky top-0 h-screen z-30 flex flex-col justify-between transition-all duration-300 ease-in-out border-r border-white/10 bg-[#081224]/90 backdrop-blur-2xl ${
        collapsed ? 'w-[72px]' : 'w-[252px]'
      }`}
    >
      {/* Top Header & Logo */}
      <div className="flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-white/[0.08] h-[64px]">
          <div className="cursor-pointer" onClick={() => onSelectTab('overview')}>
            <BrandLogo collapsed={collapsed} size="md" />
          </div>
          <button
            onClick={onToggleCollapse}
            title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            className="hidden lg:flex items-center justify-center w-7 h-7 rounded-lg text-[#94A3B8] hover:text-[#38BDF8] hover:bg-white/[0.08] transition-colors btn-press"
          >
            {collapsed ? <ChevronRight size={15} /> : <ChevronLeft size={15} />}
          </button>
        </div>

        {/* Workspace Selector */}
        {!collapsed ? (
          <div className="p-3 border-b border-white/[0.06] relative">
            <span className="text-[10px] uppercase font-mono tracking-wider text-[#64748B] block px-1 mb-1 font-medium">
              Active Workspace
            </span>
            <button
              onClick={() => setWorkspaceOpen(!workspaceOpen)}
              className="w-full flex items-center justify-between px-3 py-2 rounded-xl bg-[#0D1C36] border border-white/10 hover:border-white/20 text-left text-xs font-medium text-slate-200 transition-colors btn-press shadow-sm"
            >
              <div className="flex items-center gap-2 truncate">
                <span className="w-2 h-2 rounded-full bg-[#38BDF8] shadow-[0_0_8px_#38BDF8] shrink-0" />
                <span className="truncate">{selectedWorkspace}</span>
              </div>
              <ChevronsUpDown size={13} className="text-[#64748B] shrink-0 ml-1" />
            </button>

            {workspaceOpen && (
              <div className="absolute left-3 right-3 top-[68px] z-50 bg-[#0E1E38] border border-white/15 rounded-2xl shadow-2xl py-1 text-xs backdrop-blur-2xl">
                {workspaces.map((ws) => (
                  <button
                    key={ws}
                    onClick={() => {
                      setSelectedWorkspace(ws);
                      setWorkspaceOpen(false);
                    }}
                    className={`w-full text-left px-3.5 py-2 hover:bg-white/[0.08] transition-colors flex items-center gap-2 ${
                      selectedWorkspace === ws ? 'text-[#38BDF8] font-semibold bg-white/[0.06]' : 'text-slate-300'
                    }`}
                  >
                    <span className={`w-1.5 h-1.5 rounded-full ${selectedWorkspace === ws ? 'bg-[#38BDF8]' : 'bg-slate-600'}`} />
                    <span className="truncate">{ws}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="py-3 flex justify-center border-b border-white/[0.06]">
            <div className="w-8 h-8 rounded-xl bg-[#0D1C36] border border-white/10 flex items-center justify-center text-[#38BDF8] text-xs font-mono font-bold" title={selectedWorkspace}>
              AC
            </div>
          </div>
        )}

        {/* Navigation Items */}
        <nav className="p-2 space-y-1 overflow-y-auto max-h-[calc(100vh-250px)]">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                title={collapsed ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all group relative btn-press ${
                  isActive
                    ? 'bg-[#122444] text-white border border-[#38BDF8]/30 shadow-[inset_0_1px_0_rgba(255,255,255,0.15),0_4px_16px_rgba(37,99,235,0.2)]'
                    : 'text-[#94A3B8] hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                {/* Reference Accent Indicator */}
                {isActive && (
                  <span className="absolute left-0 top-2 bottom-2 w-1 rounded-r-full bg-[#38BDF8] shadow-[0_0_10px_#38BDF8]" />
                )}

                <Icon
                  size={16}
                  className={`shrink-0 transition-colors ${
                    isActive
                      ? 'text-[#38BDF8]'
                      : 'text-[#64748B] group-hover:text-slate-200'
                  }`}
                />

                {!collapsed && (
                  <div className="flex items-center justify-between flex-1 truncate">
                    <span className="truncate">{item.label}</span>
                    {item.badge && (
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded-full border font-medium ${
                          item.badgeColor || 'text-[#94A3B8] bg-white/[0.06] border-white/10'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </div>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Section: Profile, Connection & Status */}
      <div className="p-3 border-t border-white/[0.08] flex flex-col gap-2.5">
        {/* Connection Status Label */}
        <div className={`px-2.5 py-1.5 rounded-xl bg-[#060D1A]/90 border border-white/[0.08] flex items-center ${collapsed ? 'justify-center' : 'justify-between'}`}>
          <div className="flex items-center gap-2 truncate">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#34D399] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#34D399]"></span>
            </span>
            {!collapsed && (
              <span className="text-[11px] font-mono text-[#94A3B8] truncate">
                Interactive Engine
              </span>
            )}
          </div>
          {!collapsed && (
            <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-[#34D399]/15 text-[#34D399] border border-[#34D399]/30">
              Active
            </span>
          )}
        </div>

        {/* User Card */}
        <div className={`flex items-center gap-2.5 p-1.5 rounded-xl hover:bg-white/[0.06] transition-colors ${collapsed ? 'justify-center' : ''}`}>
          <div className="relative w-8 h-8 rounded-full overflow-hidden border border-[#38BDF8]/40 shrink-0 shadow-[0_0_10px_rgba(56,189,248,0.2)]">
            <img
              src="/src/assets/images/security_engineer_avatar_1793477459287.jpg"
              alt="Prakhar Rathore"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
          {!collapsed && (
            <div className="flex flex-col min-w-0 flex-1">
              <span className="text-xs font-semibold text-white truncate">
                Prakhar Rathore
              </span>
              <span className="text-[10px] font-mono text-[#94A3B8] truncate">
                Staff Security Eng
              </span>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};

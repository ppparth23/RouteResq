import React, { useState } from 'react';
import {
  Search,
  Bell,
  CheckCircle2,
  AlertTriangle,
  Menu,
  RefreshCw,
  ShieldCheck,
} from 'lucide-react';
import { NavigationTab } from './Sidebar';

interface TopNavProps {
  currentTab: NavigationTab;
  onOpenCommandPalette: () => void;
  onOpenMobileMenu: () => void;
  onTriggerScanModal: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentTab,
  onOpenCommandPalette,
  onOpenMobileMenu,
  onTriggerScanModal,
}) => {
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'simulation' | 'checking' | 'disconnected'>('simulation');
  const [unreadNotifications, setUnreadNotifications] = useState([
    {
      id: 1,
      title: 'Critical SQL Injection (CWE-89) flagged in checkout-service-api',
      time: '12m ago',
      type: 'critical',
      read: false,
    },
    {
      id: 2,
      title: 'Neural-Symbolic patch passed all 4 regression invariants',
      time: '45m ago',
      type: 'success',
      read: false,
    },
    {
      id: 3,
      title: 'Scheduled daily AST taint analysis complete (14 repos)',
      time: '2h ago',
      type: 'info',
      read: false,
    },
  ]);

  const breadcrumbTitles: Record<NavigationTab, { section: string; title: string }> = {
    overview: { section: 'Intelligence', title: 'Overview Dashboard' },
    'new-scan': { section: 'Scanning', title: 'Start a Security Scan' },
    'scan-history': { section: 'Auditing', title: 'Scan History & Repositories' },
    vulnerabilities: { section: 'Analysis', title: 'Vulnerability Findings' },
    remediation: { section: 'Repair', title: 'AI Remediation Lab' },
    'validation-lab': { section: 'Verification', title: 'Validation Lab & Invariant Prover' },
    reports: { section: 'Compliance', title: 'Executive Reports & Audit Logs' },
    settings: { section: 'Configuration', title: 'Engine Rules & Integrations' },
  };

  const handleTestConnection = () => {
    setConnectionStatus('checking');
    setTimeout(() => {
      setConnectionStatus('simulation');
    }, 900);
  };

  const markAllRead = () => {
    setUnreadNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const activeBreadcrumb = breadcrumbTitles[currentTab] || { section: 'Platform', title: 'VULNEX AI' };

  return (
    <header className="sticky top-0 z-20 h-[64px] border-b border-white/10 bg-[#070E1B]/85 backdrop-blur-2xl px-4 lg:px-8 flex items-center justify-between gap-4">
      {/* Left: Mobile Menu Trigger + Breadcrumb */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onOpenMobileMenu}
          className="lg:hidden p-2 rounded-xl text-[#94A3B8] hover:text-white hover:bg-white/[0.08] transition-colors btn-press"
          aria-label="Open mobile menu"
        >
          <Menu size={18} />
        </button>

        <div className="flex items-center gap-2 text-xs truncate">
          <span className="text-[#64748B] font-mono hidden sm:inline">VULNEX</span>
          <span className="text-[#64748B] hidden sm:inline">/</span>
          <span className="text-[#94A3B8] hidden md:inline">{activeBreadcrumb.section}</span>
          <span className="text-[#64748B] hidden md:inline">/</span>
          <span className="font-semibold text-white truncate">{activeBreadcrumb.title}</span>
        </div>
      </div>

      {/* Center / Search bar trigger */}
      <div className="flex-1 max-w-md mx-2 hidden sm:block">
        <button
          onClick={onOpenCommandPalette}
          className="w-full flex items-center justify-between px-3.5 py-1.5 rounded-full bg-[#0D1C36] border border-white/10 hover:border-[#38BDF8]/40 hover:shadow-[0_0_15px_rgba(56,189,248,0.15)] text-xs text-[#94A3B8] transition-all group btn-press"
        >
          <div className="flex items-center gap-2 truncate">
            <Search size={14} className="text-[#64748B] group-hover:text-[#38BDF8] transition-colors" />
            <span className="truncate">Search CVEs, files, AST flows, or commands...</span>
          </div>
          <kbd className="hidden md:inline-flex items-center gap-0.5 px-2 py-0.5 text-[10px] font-mono text-[#94A3B8] bg-white/[0.08] border border-white/10 rounded-full">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Environment Badge */}
        <div className="hidden xl:flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0D1C36] border border-white/10 text-[11px] font-mono text-[#94A3B8]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#38BDF8] shadow-[0_0_8px_#38BDF8]" />
          <span>Staging · Prod Mirror</span>
        </div>

        {/* Backend / Demo Engine Status Indicator */}
        <button
          onClick={handleTestConnection}
          title="Click to probe engine status"
          className="flex items-center gap-2 px-3 py-1 rounded-full bg-[#0D1C36] border border-white/10 hover:border-white/20 text-xs transition-colors btn-press"
        >
          {connectionStatus === 'simulation' && (
            <>
              <span className="w-2 h-2 rounded-full bg-[#34D399] shadow-[0_0_8px_#34D399]" />
              <span className="font-mono text-[11px] text-slate-200 hidden md:inline">Simulation Engine</span>
            </>
          )}
          {connectionStatus === 'checking' && (
            <>
              <RefreshCw size={12} className="animate-spin text-[#FBBF24]" />
              <span className="font-mono text-[11px] text-[#FBBF24]">Probing...</span>
            </>
          )}
          {connectionStatus === 'disconnected' && (
            <>
              <span className="w-2 h-2 rounded-full bg-[#F87171]" />
              <span className="font-mono text-[11px] text-[#F87171]">Disconnected</span>
            </>
          )}
        </button>

        {/* Start Scan Primary Action Button - Reference Image Style White Pill */}
        <button
          onClick={onTriggerScanModal}
          className="hidden sm:inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold text-[#0B1528] bg-white hover:bg-slate-100 transition-all shadow-[0_4px_16px_rgba(255,255,255,0.22)] cursor-pointer btn-press"
        >
          <span>+</span>
          <span>New Scan</span>
        </button>

        {/* Notification Bell */}
        <div className="relative">
          <button
            onClick={() => setNotificationsOpen(!notificationsOpen)}
            className="relative p-2 rounded-full text-[#94A3B8] hover:text-white hover:bg-white/[0.08] transition-colors btn-press"
            aria-label="Security notifications"
          >
            <Bell size={17} />
            {unreadNotifications.some((n) => !n.read) && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#F87171] ring-2 ring-[#070E1B]" />
            )}
          </button>

          {/* Notifications Dropdown */}
          {notificationsOpen && (
            <div className="absolute right-0 top-12 w-80 sm:w-96 rounded-2xl bg-[#0D1C36]/95 border border-white/15 shadow-2xl z-50 p-4 backdrop-blur-2xl animate-fade-in">
              <div className="flex items-center justify-between pb-2.5 border-b border-white/[0.08] mb-2.5">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-white">Security Alerts</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/[0.06] text-[#94A3B8] border border-white/10">
                    {unreadNotifications.filter((n) => !n.read).length} new
                  </span>
                </div>
                <button
                  onClick={markAllRead}
                  className="text-[11px] text-[#38BDF8] hover:underline"
                >
                  Mark all read
                </button>
              </div>

              <div className="space-y-2 max-h-72 overflow-y-auto">
                {unreadNotifications.map((notif) => (
                  <div
                    key={notif.id}
                    className={`p-3 rounded-xl border text-xs transition-colors ${
                      notif.read
                        ? 'bg-[#081224]/60 border-white/[0.06] text-[#94A3B8]'
                        : 'bg-[#122444] border-white/10 text-slate-100 shadow-sm'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2">
                        {notif.type === 'critical' ? (
                          <AlertTriangle size={14} className="text-[#F87171] shrink-0 mt-0.5" />
                        ) : notif.type === 'success' ? (
                          <CheckCircle2 size={14} className="text-[#34D399] shrink-0 mt-0.5" />
                        ) : (
                          <ShieldCheck size={14} className="text-[#38BDF8] shrink-0 mt-0.5" />
                        )}
                        <p className="text-xs leading-snug">{notif.title}</p>
                      </div>
                    </div>
                    <div className="mt-1.5 flex items-center justify-between text-[10px] font-mono text-[#64748B]">
                      <span>{notif.time}</span>
                      <span className="text-[#38BDF8] hover:underline cursor-pointer">Inspect</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

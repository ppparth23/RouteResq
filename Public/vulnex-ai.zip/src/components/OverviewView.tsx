import React from 'react';
import {
  ShieldAlert,
  Flame,
  CheckCircle2,
  TrendingDown,
  ArrowRight,
  GitBranch,
  Calendar,
  ChevronRight,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  Play,
  FileCheck2,
  Cpu,
} from 'lucide-react';
import {
  MOCK_SUMMARY,
  MOCK_SEVERITY_BREAKDOWN,
  MOCK_RECENT_SCANS,
  MOCK_SECURITY_ACTIVITIES,
  MOCK_CWE_DISTRIBUTION,
  ScanRecord,
} from '../data/mockData';
import { NavigationTab } from './Sidebar';

interface OverviewViewProps {
  onNavigate: (tab: NavigationTab) => void;
  onSelectScan: (scan: ScanRecord) => void;
  onTriggerScanModal: () => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  onNavigate,
  onSelectScan,
  onTriggerScanModal,
}) => {
  const totalFindings = MOCK_SUMMARY.totalFindings;
  const criticalFindings = MOCK_SUMMARY.criticalFindings;
  const fixesValidated = MOCK_SUMMARY.fixesValidated;
  const validationPassRate = MOCK_SUMMARY.validationPassRate;

  // Percentage calculations for severity bar
  const totalSeverityCount =
    MOCK_SEVERITY_BREAKDOWN.Critical +
    MOCK_SEVERITY_BREAKDOWN.High +
    MOCK_SEVERITY_BREAKDOWN.Medium +
    MOCK_SEVERITY_BREAKDOWN.Low;

  const critPct = (MOCK_SEVERITY_BREAKDOWN.Critical / totalSeverityCount) * 100;
  const highPct = (MOCK_SEVERITY_BREAKDOWN.High / totalSeverityCount) * 100;
  const medPct = (MOCK_SEVERITY_BREAKDOWN.Medium / totalSeverityCount) * 100;
  const lowPct = (MOCK_SEVERITY_BREAKDOWN.Low / totalSeverityCount) * 100;

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      {/* 1. HERO SECTION - Styled after the Reference Image with Cobalt Spotlight */}
      <section className="relative rounded-3xl glass-panel p-6 sm:p-8 lg:p-10 overflow-hidden border border-white/15">
        {/* Luminous Cobalt Spotlight from Reference Image */}
        <div className="absolute -right-10 -top-10 w-[520px] h-[520px] bg-gradient-to-br from-[#2563EB]/40 via-[#38BDF8]/20 to-transparent rounded-full blur-3xl pointer-events-none" />
        <div className="absolute left-1/3 -bottom-24 w-80 h-80 bg-[#1D4ED8]/25 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Editorial Headline & Actions */}
          <div className="lg:col-span-8 max-w-2xl">
            {/* Eyebrow & Status label */}
            <div className="flex flex-wrap items-center gap-2.5 mb-4">
              <span className="text-[11px] font-mono tracking-widest uppercase text-[#38BDF8] font-bold">
                SECURITY INTELLIGENCE PLATFORM
              </span>
              <span className="text-[#64748B]">·</span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0E1E38] border border-white/10 text-[10px] font-mono text-[#94A3B8]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#34D399] shadow-[0_0_6px_#34D399]" />
                AI SECURITY WORKSPACE
              </span>
              <span className="text-[10px] font-mono text-[#FBBF24] bg-[#FBBF24]/15 border border-[#FBBF24]/30 px-2 py-0.5 rounded-full font-medium">
                DEMO DATA
              </span>
            </div>

            {/* Main Heading matching Reference Typography */}
            <h1 className="font-display text-3xl sm:text-4xl lg:text-[3.25rem] font-extrabold text-white tracking-tight leading-[1.12] mb-4">
              Your code. <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-[#93C5FD] to-[#38BDF8]">
                Under the microscope.
              </span>
            </h1>

            {/* Supporting Text */}
            <p className="text-sm sm:text-base text-[#94A3B8] leading-relaxed mb-8 max-w-xl">
              Detect vulnerabilities, understand the attack surface, and generate
              verifiable security fixes from one workspace.
            </p>

            {/* CTAs - Pure White Pill CTA matching "Explore our services" from Reference */}
            <div className="flex flex-wrap items-center gap-3.5">
              <button
                onClick={onTriggerScanModal}
                className="btn-primary-pill inline-flex items-center gap-2 px-6 py-3 text-xs sm:text-sm font-bold text-[#0B1528] cursor-pointer"
              >
                <Play size={14} className="fill-current" />
                <span>+ Start New Scan</span>
              </button>

              <button
                onClick={() => onNavigate('scan-history')}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-full text-xs sm:text-sm font-semibold text-white bg-[#0D1C36] hover:bg-[#122547] border border-white/15 transition-all cursor-pointer btn-press shadow-sm"
              >
                <span>View Scan History</span>
                <ChevronRight size={14} className="text-[#94A3B8]" />
              </button>
            </div>
          </div>

          {/* Right Column: Reference Atmospheric Visual Lockup */}
          <div className="lg:col-span-4 hidden lg:flex flex-col items-center justify-center relative">
            <div className="relative w-64 h-64 rounded-3xl bg-gradient-to-b from-[#102446]/80 to-[#0A162B]/90 border border-white/15 shadow-[0_20px_50px_rgba(37,99,235,0.25)] p-5 flex flex-col justify-between backdrop-blur-xl">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-[#38BDF8] uppercase tracking-wider font-semibold">
                  AST Pipeline
                </span>
                <span className="w-2 h-2 rounded-full bg-[#34D399] shadow-[0_0_8px_#34D399]" />
              </div>

              {/* 3D Geometric Pillar Concept Visual */}
              <div className="relative h-28 flex items-end justify-center gap-2 py-2">
                <div className="w-6 h-20 rounded-t-lg bg-gradient-to-t from-[#1D4ED8] to-[#38BDF8] shadow-[0_0_15px_rgba(56,189,248,0.3)] animate-pulse" />
                <div className="w-7 h-26 rounded-t-lg bg-gradient-to-t from-[#1E40AF] to-[#60A5FA] shadow-[0_0_20px_rgba(37,99,235,0.4)]" />
                <div className="w-6 h-16 rounded-t-lg bg-gradient-to-t from-[#1D4ED8] to-[#38BDF8] shadow-[0_0_12px_rgba(56,189,248,0.25)]" />
              </div>

              <div className="text-center border-t border-white/10 pt-2.5">
                <span className="text-xs font-semibold text-white block">
                  Neural-Symbolic Verifier
                </span>
                <span className="text-[10px] font-mono text-[#94A3B8]">
                  Zero False-Positive Engine
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. FOUR SUMMARY METRICS CARDS - Styled after the 4 Reference Feature Cards */}
      <section>
        <div className="flex items-center justify-between mb-3.5 px-1">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono uppercase tracking-wider text-[#94A3B8] font-semibold">
              Platform Finding Metrics
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#FBBF24]/15 text-[#FBBF24] border border-[#FBBF24]/30 font-medium">
              DEMO DATA
            </span>
          </div>
          <span className="text-[11px] font-mono text-[#64748B]">
            Auto-synced with Git hooks
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Total Findings */}
          <div
            onClick={() => onNavigate('vulnerabilities')}
            className="group cursor-pointer rounded-2xl glass-panel p-5 border border-white/15 glass-card-interactive flex flex-col justify-between"
          >
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-mono uppercase tracking-wider text-[#94A3B8] block font-semibold">
                  Total Findings
                </span>
                <span className="text-3xl font-display font-extrabold text-white mt-1.5 tabular-nums block tracking-tight">
                  {totalFindings}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#38BDF8]/15 border border-[#38BDF8]/30 text-[#38BDF8] shadow-[0_0_15px_rgba(56,189,248,0.2)]">
                <ShieldAlert size={18} />
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-white/[0.08] flex items-center justify-between text-[11px] font-mono text-[#64748B]">
              <span className="flex items-center gap-1 text-[#34D399]">
                <TrendingDown size={13} />
                -4 from last week
              </span>
              <span className="text-[#38BDF8] group-hover:translate-x-0.5 transition-transform font-medium">
                Explore →
              </span>
            </div>
          </div>

          {/* Card 2: Critical Findings */}
          <div
            onClick={() => onNavigate('vulnerabilities')}
            className="group cursor-pointer rounded-2xl glass-panel p-5 border border-white/15 glass-card-interactive flex flex-col justify-between"
          >
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-mono uppercase tracking-wider text-[#94A3B8] block font-semibold">
                  Critical Findings
                </span>
                <span className="text-3xl font-display font-extrabold text-[#F87171] mt-1.5 tabular-nums block tracking-tight">
                  {criticalFindings}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#F87171]/15 border border-[#F87171]/30 text-[#F87171] shadow-[0_0_15px_rgba(248,113,113,0.2)]">
                <Flame size={18} />
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-white/[0.08] flex items-center justify-between text-[11px] font-mono text-[#64748B]">
              <span className="text-[#F87171]">Immediate attention</span>
              <span className="text-[#F87171] group-hover:translate-x-0.5 transition-transform font-medium">
                Patch →
              </span>
            </div>
          </div>

          {/* Card 3: Fixes Validated */}
          <div
            onClick={() => onNavigate('remediation')}
            className="group cursor-pointer rounded-2xl glass-panel p-5 border border-white/15 glass-card-interactive flex flex-col justify-between"
          >
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-mono uppercase tracking-wider text-[#94A3B8] block font-semibold">
                  Fixes Validated
                </span>
                <span className="text-3xl font-display font-extrabold text-[#60A5FA] mt-1.5 tabular-nums block tracking-tight">
                  {fixesValidated}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#2563EB]/20 border border-[#3B82F6]/30 text-[#60A5FA] shadow-[0_0_15px_rgba(37,99,235,0.25)]">
                <FileCheck2 size={18} />
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-white/[0.08] flex items-center justify-between text-[11px] font-mono text-[#64748B]">
              <span className="text-slate-200">AST invariant proof</span>
              <span className="text-[#60A5FA] group-hover:translate-x-0.5 transition-transform font-medium">
                Diffs →
              </span>
            </div>
          </div>

          {/* Card 4: Validation Pass Rate */}
          <div
            onClick={() => onNavigate('validation-lab')}
            className="group cursor-pointer rounded-2xl glass-panel p-5 border border-white/15 glass-card-interactive flex flex-col justify-between"
          >
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-mono uppercase tracking-wider text-[#94A3B8] block font-semibold">
                  Validation Pass Rate
                </span>
                <span className="text-3xl font-display font-extrabold text-[#34D399] mt-1.5 tabular-nums block tracking-tight">
                  {validationPassRate}%
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#34D399]/15 border border-[#34D399]/30 text-[#34D399] shadow-[0_0_15px_rgba(52,211,153,0.2)]">
                <Cpu size={18} />
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-white/[0.08] flex items-center justify-between text-[11px] font-mono text-[#64748B]">
              <span className="text-[#34D399]">Exploit harness passed</span>
              <span className="text-[#34D399] group-hover:translate-x-0.5 transition-transform font-medium">
                Test Lab →
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* 3. TWO SECTIONS: RECENT SCANS (LEFT) + SECURITY POSTURE (RIGHT) */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Section: RECENT SCANS (8 cols) */}
        <div className="lg:col-span-8 rounded-3xl glass-panel p-6 sm:p-7 border border-white/15 space-y-4">
          <div className="flex items-center justify-between pb-3.5 border-b border-white/[0.08]">
            <div>
              <h2 className="text-lg font-display font-bold text-white tracking-tight">
                Recent Scans
              </h2>
              <p className="text-xs text-[#94A3B8] mt-0.5">
                Automated static & dynamic AST taint scans across connected repositories.
              </p>
            </div>
            <button
              onClick={() => onNavigate('scan-history')}
              className="text-xs font-mono text-[#38BDF8] hover:underline flex items-center gap-1 btn-press"
            >
              <span>All Scans</span>
              <ChevronRight size={13} />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/[0.08] text-[10px] font-mono uppercase tracking-wider text-[#94A3B8]">
                  <th className="py-2.5 px-3">Repository</th>
                  <th className="py-2.5 px-3">Language</th>
                  <th className="py-2.5 px-3">Scan Date</th>
                  <th className="py-2.5 px-3 text-center">Findings</th>
                  <th className="py-2.5 px-3">Highest Severity</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.06] text-xs font-sans">
                {MOCK_RECENT_SCANS.map((scan) => (
                  <tr
                    key={scan.id}
                    className="hover:bg-white/[0.04] transition-colors group cursor-pointer"
                    onClick={() => {
                      onSelectScan(scan);
                      onNavigate('scan-history');
                    }}
                  >
                    <td className="py-3.5 px-3">
                      <div className="flex flex-col">
                        <span className="font-semibold text-white group-hover:text-[#38BDF8] transition-colors truncate max-w-[170px]">
                          {scan.repoName}
                        </span>
                        <span className="text-[10px] font-mono text-[#94A3B8] flex items-center gap-1">
                          <GitBranch size={10} className="text-[#38BDF8]" />
                          {scan.branch} · {scan.commitHash}
                        </span>
                      </div>
                    </td>

                    <td className="py-3.5 px-3">
                      <span className="font-mono text-xs text-[#94A3B8]">
                        {scan.language}
                      </span>
                    </td>

                    <td className="py-3.5 px-3">
                      <span className="font-mono text-[11px] text-[#94A3B8]">
                        {scan.timestamp}
                      </span>
                    </td>

                    <td className="py-3.5 px-3 text-center">
                      <span className="font-mono font-bold text-white tabular-nums">
                        {scan.findingsCount}
                      </span>
                    </td>

                    <td className="py-3.5 px-3">
                      <span
                        className={`inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                          scan.highestSeverity === 'Critical'
                            ? 'text-[#F87171] bg-[#F87171]/15 border border-[#F87171]/30'
                            : scan.highestSeverity === 'High'
                            ? 'text-[#FBBF24] bg-[#FBBF24]/15 border border-[#FBBF24]/30'
                            : 'text-[#34D399] bg-[#34D399]/15 border border-[#34D399]/30'
                        }`}
                      >
                        {scan.highestSeverity}
                      </span>
                    </td>

                    <td className="py-3.5 px-3">
                      <span className="inline-flex items-center gap-1.5 text-[11px] font-mono text-[#34D399]">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#34D399] shadow-[0_0_6px_#34D399]" />
                        {scan.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-3 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectScan(scan);
                          onNavigate('scan-history');
                        }}
                        className="text-xs font-mono text-[#38BDF8] hover:text-white px-3 py-1 rounded-full bg-[#38BDF8]/15 hover:bg-[#38BDF8]/25 border border-[#38BDF8]/30 transition-colors btn-press"
                      >
                        Details
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Section: SECURITY POSTURE (4 cols) */}
        <div className="lg:col-span-4 rounded-3xl glass-panel p-6 sm:p-7 border border-white/15 space-y-5">
          <div className="pb-3.5 border-b border-white/[0.08] flex items-center justify-between">
            <h2 className="text-lg font-display font-bold text-white tracking-tight">
              Security Posture
            </h2>
            <span className="text-[10px] font-mono uppercase px-2.5 py-0.5 rounded-full bg-white/[0.08] text-[#94A3B8] border border-white/10">
              Risk Index 74/100
            </span>
          </div>

          {/* Segmented Horizontal Bar */}
          <div>
            <div className="flex items-center justify-between text-xs font-mono text-[#94A3B8] mb-2.5">
              <span>Severity Breakdown</span>
              <span className="tabular-nums font-semibold text-white">24 Total</span>
            </div>
            <div className="h-3 w-full rounded-full bg-[#060D1A] overflow-hidden flex p-0.5 border border-white/10 shadow-inner">
              <div
                style={{ width: `${critPct}%` }}
                className="h-full bg-[#F87171] rounded-l-full shadow-[0_0_8px_#F87171]"
                title={`Critical: ${MOCK_SEVERITY_BREAKDOWN.Critical}`}
              />
              <div
                style={{ width: `${highPct}%` }}
                className="h-full bg-[#FBBF24]"
                title={`High: ${MOCK_SEVERITY_BREAKDOWN.High}`}
              />
              <div
                style={{ width: `${medPct}%` }}
                className="h-full bg-[#60A5FA]"
                title={`Medium: ${MOCK_SEVERITY_BREAKDOWN.Medium}`}
              />
              <div
                style={{ width: `${lowPct}%` }}
                className="h-full bg-[#34D399] rounded-r-full"
                title={`Low: ${MOCK_SEVERITY_BREAKDOWN.Low}`}
              />
            </div>

            {/* Severity Legend */}
            <div className="grid grid-cols-2 gap-2 mt-3 font-mono text-xs">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#F87171]" />
                <span className="text-[#94A3B8]">Critical:</span>
                <span className="font-bold text-white tabular-nums">
                  {MOCK_SEVERITY_BREAKDOWN.Critical}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#FBBF24]" />
                <span className="text-[#94A3B8]">High:</span>
                <span className="font-bold text-white tabular-nums">
                  {MOCK_SEVERITY_BREAKDOWN.High}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#60A5FA]" />
                <span className="text-[#94A3B8]">Medium:</span>
                <span className="font-bold text-white tabular-nums">
                  {MOCK_SEVERITY_BREAKDOWN.Medium}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#34D399]" />
                <span className="text-[#94A3B8]">Low:</span>
                <span className="font-bold text-white tabular-nums">
                  {MOCK_SEVERITY_BREAKDOWN.Low}
                </span>
              </div>
            </div>
          </div>

          {/* Short summary explaining demo findings */}
          <div className="p-4 rounded-2xl bg-[#0D1C36]/90 border border-white/10 text-xs text-[#94A3B8] leading-relaxed shadow-sm">
            <p className="font-semibold text-white mb-1.5 flex items-center gap-1.5">
              <ShieldCheck size={15} className="text-[#38BDF8]" />
              Threat Intel Summary
            </p>
            Current findings are concentrated in raw query interpolations (CWE-89) and unvalidated outbound HTTP webhooks (CWE-918). 
            AI patch synthesis is complete for 12 instances, with 83% passing full exploit simulation.
          </div>

          {/* Top CWE Categories */}
          <div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-[#94A3B8] block mb-2 font-semibold">
              Top Weakness Categories
            </span>
            <div className="space-y-2">
              {MOCK_CWE_DISTRIBUTION.slice(0, 3).map((item) => (
                <div key={item.cwe} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 truncate">
                    <span className="font-mono text-[10px] text-[#38BDF8] px-2 py-0.5 rounded-full bg-[#38BDF8]/15 font-semibold">
                      {item.cwe}
                    </span>
                    <span className="text-slate-200 truncate">{item.name}</span>
                  </div>
                  <span className="font-mono text-[#94A3B8] tabular-nums font-semibold">
                    {item.count}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => onNavigate('reports')}
            className="w-full py-2.5 px-4 rounded-full bg-[#0D1C36] hover:bg-[#122547] border border-white/15 text-xs font-mono text-white flex items-center justify-center gap-2 transition-colors btn-press shadow-sm"
          >
            <span>Full Threat Surface Report</span>
            <ArrowRight size={13} className="text-[#38BDF8]" />
          </button>
        </div>
      </section>

      {/* 4. BOTTOM SECTION: RECENT SECURITY ACTIVITY - Speech/Event cards from reference style */}
      <section className="rounded-3xl glass-panel p-6 sm:p-7 border border-white/15 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-3.5 border-b border-white/[0.08]">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-display font-bold text-white tracking-tight">
              Recent Security Activity
            </h2>
            <span className="text-[10px] font-mono text-[#FBBF24] bg-[#FBBF24]/15 border border-[#FBBF24]/30 px-2 py-0.5 rounded-full font-medium">
              SAMPLE ACTIVITY
            </span>
          </div>
          <span className="text-[11px] font-mono text-[#64748B]">
            Chronological audit feed
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {MOCK_SECURITY_ACTIVITIES.map((activity) => (
            <div
              key={activity.id}
              className="p-4 rounded-2xl bg-[#0D1C36]/90 border border-white/10 hover:border-white/20 transition-all flex items-start justify-between gap-3.5 shadow-sm"
            >
              <div className="flex items-start gap-3.5 min-w-0">
                <div className="p-2.5 rounded-xl bg-[#122444] border border-white/15 text-slate-200 mt-0.5 shrink-0 shadow-[0_0_12px_rgba(37,99,235,0.2)]">
                  {activity.type === 'scan_completed' && <Play size={14} className="text-[#38BDF8]" />}
                  {activity.type === 'vulnerability_found' && <AlertTriangle size={14} className="text-[#F87171]" />}
                  {activity.type === 'validation_failed' && <Flame size={14} className="text-[#FBBF24]" />}
                  {activity.type === 'validation_passed' && <CheckCircle2 size={14} className="text-[#34D399]" />}
                  {activity.type === 'patch_generated' && <Sparkles size={14} className="text-[#60A5FA]" />}
                </div>

                <div className="min-w-0">
                  <p className="text-xs font-semibold text-white truncate">
                    {activity.title}
                  </p>
                  <p className="text-[11px] font-mono text-[#94A3B8] truncate mt-0.5">
                    {activity.target}
                  </p>
                </div>
              </div>

              <span className="text-[10px] font-mono text-[#64748B] shrink-0 tabular-nums">
                {activity.timestamp}
              </span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

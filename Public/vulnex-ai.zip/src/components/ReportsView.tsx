import React, { useState } from 'react';
import {
  Download,
  CheckCircle2,
  Printer,
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const [downloadFormat, setDownloadFormat] = useState<string | null>(null);

  const handleExport = (format: string) => {
    setDownloadFormat(format);
    setTimeout(() => setDownloadFormat(null), 2500);
  };

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2.5 mb-1.5">
            <h1 className="text-2xl font-display font-bold text-white tracking-tight">
              Compliance & Executive Security Reports
            </h1>
            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#F59E0B]/10 text-[#FBBF24] border border-[#F59E0B]/20 font-medium">
              DEMO DATA
            </span>
          </div>
          <p className="text-xs text-slate-300 mt-1">
            Formal compliance readiness for OWASP Top 10, CWE Top 25, and SOC 2 Type II audit requirements.
          </p>
        </div>

        {/* Export Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleExport('Markdown')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-[#0A162B] hover:bg-white/10 border border-white/10 text-xs font-mono text-slate-200 transition-colors btn-press"
          >
            <Download size={14} className="text-slate-400" />
            <span>{downloadFormat === 'Markdown' ? 'Exported .md' : 'Export Markdown'}</span>
          </button>

          <button
            onClick={() => handleExport('JSON')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-[#0A162B] hover:bg-white/10 border border-white/10 text-xs font-mono text-slate-200 transition-colors btn-press"
          >
            <Download size={14} className="text-slate-400" />
            <span>{downloadFormat === 'JSON' ? 'Exported .json' : 'Export JSON'}</span>
          </button>

          <button
            onClick={() => handleExport('PDF')}
            className="btn-primary-pill text-xs font-bold text-[#070E1B] flex items-center gap-1.5 py-2 px-5"
          >
            <Printer size={14} />
            <span>{downloadFormat === 'PDF' ? 'Generating PDF...' : 'Executive PDF'}</span>
          </button>
        </div>
      </div>

      {/* Compliance Frameworks Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* OWASP Top 10 */}
        <div className="rounded-2xl glass-card p-5 border border-white/10 space-y-3 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono uppercase text-[#38BDF8] font-bold tracking-wider">
              OWASP Top 10 (2026)
            </span>
            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/25 font-bold">
              87% COMPLIANT
            </span>
          </div>
          <h3 className="text-lg font-display font-bold text-white tracking-tight">
            A03: Injection & A10: SSRF
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            All SQLi instances contain synthesized AST parameterized replacements. 1 SSRF vector currently under peer validation.
          </p>
        </div>

        {/* CWE Top 25 */}
        <div className="rounded-2xl glass-card p-5 border border-white/10 space-y-3 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono uppercase text-[#A5B4FC] font-bold tracking-wider">
              CWE Top 25 Mitigations
            </span>
            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-[#818CF8]/15 text-[#A5B4FC] border border-[#818CF8]/25 font-bold">
              84% COVERAGE
            </span>
          </div>
          <h3 className="text-lg font-display font-bold text-white tracking-tight">
            CWE-89, CWE-918, CWE-1321
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Formal proofs generated for 18 out of 21 tracked weakness patterns with SMT invariant guarantees.
          </p>
        </div>

        {/* SOC 2 Type II */}
        <div className="rounded-2xl glass-card p-5 border border-white/10 space-y-3 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono uppercase text-[#10B981] font-bold tracking-wider">
              SOC 2 Type II Controls
            </span>
            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/25 font-bold">
              AUDIT READY
            </span>
          </div>
          <h3 className="text-lg font-display font-bold text-white tracking-tight">
            CC7.1 & CC7.2 Evidence
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Continuous CI/CD pipeline scanning active across 14 monitored repositories with cryptographic commit hash proofs.
          </p>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="rounded-2xl glass-card p-6 border border-white/10 space-y-4 shadow-xl">
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <h2 className="text-base font-display font-bold text-white tracking-tight">
            Formal Proofs & Verification Ledger
          </h2>
          <span className="text-xs font-mono text-slate-400">
            Cryptographic audit chain
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-sans">
            <thead>
              <tr className="border-b border-white/10 text-[10px] font-mono uppercase tracking-wider text-slate-400">
                <th className="py-2.5 px-3">Rule / Invariant ID</th>
                <th className="py-2.5 px-3">CWE ID</th>
                <th className="py-2.5 px-3">Target Component</th>
                <th className="py-2.5 px-3">Prover Method</th>
                <th className="py-2.5 px-3">Verification Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-mono text-xs">
              <tr className="hover:bg-white/[0.03] transition-colors">
                <td className="py-3 px-3 text-[#38BDF8] font-bold">INV-2026-SQLI-01</td>
                <td className="py-3 px-3 text-slate-200">CWE-89</td>
                <td className="py-3 px-3 text-slate-400">orderController.ts:42</td>
                <td className="py-3 px-3 text-slate-300">SMT AST Taint Severance</td>
                <td className="py-3 px-3 text-[#10B981] flex items-center gap-1.5 font-semibold">
                  <CheckCircle2 size={13} />
                  <span>Proved (0.014s)</span>
                </td>
              </tr>
              <tr className="hover:bg-white/[0.03] transition-colors">
                <td className="py-3 px-3 text-[#38BDF8] font-bold">INV-2026-SSRF-04</td>
                <td className="py-3 px-3 text-slate-200">CWE-918</td>
                <td className="py-3 px-3 text-slate-400">webhook/dispatcher.go:88</td>
                <td className="py-3 px-3 text-slate-300">DNS Socket Pinning Guard</td>
                <td className="py-3 px-3 text-[#10B981] flex items-center gap-1.5 font-semibold">
                  <CheckCircle2 size={13} />
                  <span>Proved (0.021s)</span>
                </td>
              </tr>
              <tr className="hover:bg-white/[0.03] transition-colors">
                <td className="py-3 px-3 text-[#38BDF8] font-bold">INV-2026-PROTO-09</td>
                <td className="py-3 px-3 text-slate-200">CWE-1321</td>
                <td className="py-3 px-3 text-slate-400">utils/configMerge.ts:27</td>
                <td className="py-3 px-3 text-slate-300">Prototype Key Filtering Proof</td>
                <td className="py-3 px-3 text-[#10B981] flex items-center gap-1.5 font-semibold">
                  <CheckCircle2 size={13} />
                  <span>Proved (0.009s)</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

import React from 'react';

interface BrandLogoProps {
  collapsed?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ collapsed = false, size = 'md' }) => {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-8 h-8',
    lg: 'w-9 h-9',
  };

  return (
    <div className="flex items-center gap-3 select-none">
      {/* Precision Geometric Shield + Sapphire Scanning Symbol */}
      <div className={`relative ${iconSizes[size]} shrink-0 flex items-center justify-center rounded-xl bg-gradient-to-b from-[#122444] to-[#0A162B] border border-white/15 shadow-[0_0_20px_rgba(37,99,235,0.25)]`}>
        <svg
          viewBox="0 0 32 32"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-5 h-5 text-[#38BDF8]"
        >
          {/* Outer Shield Geometry */}
          <path
            d="M16 3L6 7V15C6 21.6 10.3 27.7 16 29C21.7 27.7 26 21.6 26 15V7L16 3Z"
            stroke="currentColor"
            strokeWidth="1.75"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-[#38BDF8]"
          />
          {/* Inner Core Scanning Reticle */}
          <circle
            cx="16"
            cy="15"
            r="4.5"
            stroke="#60A5FA"
            strokeWidth="1.5"
            strokeDasharray="3 2"
          />
          {/* Center Sensor Point */}
          <circle cx="16" cy="15" r="1.5" fill="#38BDF8" />
          {/* Precision Crosshair Ticks */}
          <line x1="16" y1="7.5" x2="16" y2="9.5" stroke="#38BDF8" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="16" y1="20.5" x2="16" y2="22.5" stroke="#38BDF8" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="8.5" y1="15" x2="10.5" y2="15" stroke="#38BDF8" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="21.5" y1="15" x2="23.5" y2="15" stroke="#38BDF8" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      </div>

      {!collapsed && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="font-display font-extrabold text-base tracking-wide text-white">
              VULNEX
            </span>
            <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-[#38BDF8]/15 text-[#38BDF8] border border-[#38BDF8]/30">
              AI
            </span>
          </div>
          <span className="text-[10px] uppercase font-mono tracking-widest text-[#94A3B8]">
            SecOps Engine
          </span>
        </div>
      )}
    </div>
  );
};

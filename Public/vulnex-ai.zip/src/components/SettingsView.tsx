import React, { useState } from 'react';
import {
  Sliders,
  Bell,
  Save,
  CheckCircle2,
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const [taintDepth, setTaintDepth] = useState('10');
  const [autoPatchCritical, setAutoPatchCritical] = useState(true);
  const [enforceSMT, setEnforceSMT] = useState(true);
  const [webhookUrl, setWebhookUrl] = useState('https://hooks.slack.com/services/T00/B00/secops-alerts');
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fade-in pb-12 max-w-4xl">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <h1 className="text-2xl font-display font-bold text-white tracking-tight">
            Engine Rules & Platform Configuration
          </h1>
          <p className="text-xs text-slate-300 mt-1">
            Configure AST traversal limits, SMT formal verification depth, and continuous pipeline automation.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="btn-primary-pill text-xs font-bold text-[#070E1B] flex items-center gap-1.5 py-2 px-5"
        >
          {saved ? <CheckCircle2 size={14} /> : <Save size={14} />}
          <span>{saved ? 'Settings Saved' : 'Save Configuration'}</span>
        </button>
      </div>

      {/* Section 1: AST & SMT Solver Settings */}
      <div className="rounded-2xl glass-card p-6 border border-white/10 space-y-4 shadow-lg">
        <h2 className="text-sm font-semibold text-white flex items-center gap-2 tracking-tight">
          <Sliders size={16} className="text-[#38BDF8]" />
          AST Taint Analysis & Symbolic Solver
        </h2>

        <div className="space-y-4 text-xs">
          <div>
            <label className="text-slate-200 font-semibold block mb-1">
              Inter-procedural Taint Tracking Depth
            </label>
            <p className="text-slate-400 mb-2 text-[11px]">
              Specifies the maximum call stack hops traversed from HTTP user parameter sources to sensitive database/file/network sinks.
            </p>
            <select
              value={taintDepth}
              onChange={(e) => setTaintDepth(e.target.value)}
              className="px-3.5 py-2 rounded-xl bg-[#0A162B] border border-white/10 text-slate-100 font-mono text-xs outline-none focus:border-[#38BDF8] transition-colors"
            >
              <option value="5">5 stack frames (Fast triage)</option>
              <option value="10">10 stack frames (Standard Enterprise)</option>
              <option value="25">25 stack frames (Deep Auditing)</option>
            </select>
          </div>

          <div className="pt-2 border-t border-white/10 flex items-center justify-between">
            <div>
              <span className="text-slate-200 font-semibold block">
                SMT Exploit Reachability Invariant Verification
              </span>
              <span className="text-slate-400 text-[11px]">
                Require mathematical satisfiability proof via Z3 theorem prover before flagging exploit paths.
              </span>
            </div>
            <input
              type="checkbox"
              checked={enforceSMT}
              onChange={(e) => setEnforceSMT(e.target.checked)}
              className="w-4 h-4 accent-[#38BDF8] cursor-pointer"
            />
          </div>

          <div className="pt-2 border-t border-white/10 flex items-center justify-between">
            <div>
              <span className="text-slate-200 font-semibold block">
                Automatic Neural-Symbolic Patch Synthesis
              </span>
              <span className="text-slate-400 text-[11px]">
                Immediately synthesize AST verified code repairs for Critical and High severity findings.
              </span>
            </div>
            <input
              type="checkbox"
              checked={autoPatchCritical}
              onChange={(e) => setAutoPatchCritical(e.target.checked)}
              className="w-4 h-4 accent-[#38BDF8] cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Section 2: Integrations & Webhooks */}
      <div className="rounded-2xl glass-card p-6 border border-white/10 space-y-4 shadow-lg">
        <h2 className="text-sm font-semibold text-white flex items-center gap-2 tracking-tight">
          <Bell size={16} className="text-[#818CF8]" />
          CI/CD Webhooks & Alert Routing
        </h2>

        <div className="space-y-4 text-xs">
          <div>
            <label className="text-slate-200 font-semibold block mb-1">
              SecOps Incident Webhook URL
            </label>
            <input
              type="text"
              value={webhookUrl}
              onChange={(e) => setWebhookUrl(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A162B] border border-white/10 text-slate-100 font-mono text-xs outline-none focus:border-[#38BDF8] transition-colors"
            />
          </div>

          <div className="p-3.5 rounded-xl bg-[#0A162B]/80 border border-white/10 flex items-center justify-between">
            <div>
              <span className="text-slate-200 font-semibold block">GitHub / GitLab Action Status</span>
              <span className="text-slate-400 text-[11px]">Pull Request check runs active on 14 repositories.</span>
            </div>
            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/25 font-bold">
              CONNECTED
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

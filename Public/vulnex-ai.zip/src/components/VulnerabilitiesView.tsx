import React, { useState, useMemo } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Search,
  Filter,
  ArrowRight,
  ChevronRight,
  Code2,
  GitBranch,
  Wrench,
  FlaskConical,
  X,
  Copy,
  Check,
  Download,
  RotateCcw,
  SlidersHorizontal,
  Table,
  LayoutGrid,
  AlertTriangle,
  Info,
  ExternalLink,
  Lock,
  Layers,
  FileCode2,
  Cpu,
  Sparkles,
  RefreshCw,
  Terminal,
  Activity,
  CheckCircle2,
} from 'lucide-react';
import {
  MOCK_VULNERABILITIES,
  MOCK_REPOSITORIES,
  Vulnerability,
  VulnerabilityCategory,
  RemediationStatus,
} from '../data/mockData';
import { NavigationTab } from './Sidebar';

interface VulnerabilitiesViewProps {
  onNavigate: (tab: NavigationTab) => void;
  onSelectVulnerability: (vulnId: string) => void;
  selectedVulnId: string;
}

export const VulnerabilitiesView: React.FC<VulnerabilitiesViewProps> = ({
  onNavigate,
  onSelectVulnerability,
  selectedVulnId,
}) => {
  // Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRepo, setSelectedRepo] = useState<string>('all');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [filePathFilter, setFilePathFilter] = useState('');
  const [sortBy, setSortBy] = useState<'severity-desc' | 'severity-asc' | 'confidence-desc' | 'file-asc' | 'status'>('severity-desc');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('cards');

  // Detail Drawer State
  const [selectedFinding, setSelectedFinding] = useState<Vulnerability | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [showFullContext, setShowFullContext] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'code' | 'remediation'>('overview');

  // Interaction feedback states
  const [copiedCode, setCopiedCode] = useState(false);
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [simulatedError, setSimulatedError] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Severity Weight Map for Sorting
  const severityWeight: Record<string, number> = {
    Critical: 4,
    High: 3,
    Medium: 2,
    Low: 1,
  };

  // All distinct categories from findings
  const categories: VulnerabilityCategory[] = [
    'Injection',
    'Cross-Site Scripting',
    'Path Traversal',
    'Hardcoded Secrets',
    'Insecure Deserialization',
    'SSRF',
    'Broken Auth',
    'Prototype Pollution',
  ];

  // Distinct languages
  const languages = ['TypeScript', 'Go', 'Python', 'Rust'];

  // Statuses
  const statuses: RemediationStatus[] = [
    'Open',
    'Patch Ready',
    'In Review',
    'Verified Fixed',
    'Suppressed',
  ];

  // Check if any filter is active
  const isFiltered = useMemo(() => {
    return (
      searchQuery.trim() !== '' ||
      selectedRepo !== 'all' ||
      selectedSeverity !== 'All' ||
      selectedCategory !== 'All' ||
      selectedLanguage !== 'All' ||
      selectedStatus !== 'All' ||
      filePathFilter.trim() !== ''
    );
  }, [searchQuery, selectedRepo, selectedSeverity, selectedCategory, selectedLanguage, selectedStatus, filePathFilter]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedRepo('all');
    setSelectedSeverity('All');
    setSelectedCategory('All');
    setSelectedLanguage('All');
    setSelectedStatus('All');
    setFilePathFilter('');
    setSortBy('severity-desc');
    showToast('Filters reset to default');
  };

  // Filtered and Sorted Findings
  const filteredFindings = useMemo(() => {
    let result = MOCK_VULNERABILITIES.filter((vuln) => {
      // Search match
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesQuery =
          vuln.title.toLowerCase().includes(query) ||
          vuln.cwe.toLowerCase().includes(query) ||
          vuln.file.toLowerCase().includes(query) ||
          vuln.repository.toLowerCase().includes(query) ||
          vuln.description.toLowerCase().includes(query);
        if (!matchesQuery) return false;
      }

      // Repo filter
      if (selectedRepo !== 'all' && vuln.repository !== selectedRepo) {
        return false;
      }

      // Severity filter
      if (selectedSeverity !== 'All' && vuln.severity !== selectedSeverity) {
        return false;
      }

      // Category filter
      if (selectedCategory !== 'All' && vuln.category !== selectedCategory) {
        return false;
      }

      // Language filter
      if (selectedLanguage !== 'All' && vuln.language !== selectedLanguage) {
        return false;
      }

      // Status filter
      if (selectedStatus !== 'All' && vuln.status !== selectedStatus) {
        return false;
      }

      // File path filter
      if (filePathFilter.trim() && !vuln.file.toLowerCase().includes(filePathFilter.toLowerCase())) {
        return false;
      }

      return true;
    });

    // Sorting
    result.sort((a, b) => {
      if (sortBy === 'severity-desc') {
        return (severityWeight[b.severity] || 0) - (severityWeight[a.severity] || 0) || b.cvss - a.cvss;
      }
      if (sortBy === 'severity-asc') {
        return (severityWeight[a.severity] || 0) - (severityWeight[b.severity] || 0) || a.cvss - b.cvss;
      }
      if (sortBy === 'confidence-desc') {
        return b.confidence - a.confidence;
      }
      if (sortBy === 'file-asc') {
        return a.file.localeCompare(b.file);
      }
      if (sortBy === 'status') {
        return a.status.localeCompare(b.status);
      }
      return 0;
    });

    return result;
  }, [
    searchQuery,
    selectedRepo,
    selectedSeverity,
    selectedCategory,
    selectedLanguage,
    selectedStatus,
    filePathFilter,
    sortBy,
  ]);

  // Summary Metrics for the current repository scope
  const scopedFindings = useMemo(() => {
    if (selectedRepo === 'all') return MOCK_VULNERABILITIES;
    return MOCK_VULNERABILITIES.filter((v) => v.repository === selectedRepo);
  }, [selectedRepo]);

  const criticalCount = useMemo(
    () => scopedFindings.filter((v) => v.severity === 'Critical').length,
    [scopedFindings]
  );
  const highCount = useMemo(
    () => scopedFindings.filter((v) => v.severity === 'High').length,
    [scopedFindings]
  );
  const patchReadyCount = useMemo(
    () => scopedFindings.filter((v) => v.status === 'Patch Ready').length,
    [scopedFindings]
  );

  const handleOpenDetail = (vuln: Vulnerability) => {
    setSelectedFinding(vuln);
    setShowFullContext(false);
    setActiveTab('overview');
    setDrawerOpen(true);
  };

  const handleOpenRemediation = (vulnId: string) => {
    onSelectVulnerability(vulnId);
    setDrawerOpen(false);
    onNavigate('remediation');
  };

  const handleCopyCode = (codeText: string) => {
    navigator.clipboard?.writeText(codeText);
    setCopiedCode(true);
    showToast('Source snippet copied to clipboard');
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleSimulateRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      showToast('Static AST Taint graph refreshed');
    }, 700);
  };

  const handleExport = (format: 'sarif' | 'json' | 'csv') => {
    const filename = `vulnex-scan-SCN-2026-9021.${format}`;
    let content = '';

    if (format === 'sarif') {
      const sarifData = {
        $schema: 'https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json',
        version: '2.1.0',
        runs: [
          {
            tool: {
              driver: {
                name: 'VULNEX AI Neural-Symbolic Taint Engine',
                version: '2.4.0-preview',
                rules: filteredFindings.map((f) => ({
                  id: f.cwe,
                  name: f.title,
                  shortDescription: { text: f.whyFlagged },
                  defaultConfiguration: { level: f.severity === 'Critical' ? 'error' : 'warning' },
                })),
              },
            },
            results: filteredFindings.map((f) => ({
              ruleId: f.cwe,
              level: f.severity === 'Critical' ? 'error' : 'warning',
              message: { text: f.description },
              locations: [
                {
                  physicalLocation: {
                    artifactLocation: { uri: f.file },
                    region: { startLine: f.line },
                  },
                },
              ],
            })),
          },
        ],
      };
      content = JSON.stringify(sarifData, null, 2);
    } else if (format === 'json') {
      content = JSON.stringify(filteredFindings, null, 2);
    } else {
      // CSV
      const headers = ['ID', 'CWE', 'Severity', 'CVSS', 'Category', 'Repository', 'File', 'Line', 'Status', 'Confidence'];
      const rows = filteredFindings.map((f) =>
        [f.id, f.cwe, f.severity, f.cvss, f.category, f.repository, f.file, f.line, f.status, `${f.confidence}%`].join(',')
      );
      content = [headers.join(','), ...rows].join('\n');
    }

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setExportModalOpen(false);
    showToast(`Exported ${filteredFindings.length} findings to ${filename}`);
  };

  return (
    <div className="space-y-6 animate-fade-in pb-16">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-[#0D2040] border border-[#38BDF8]/40 text-slate-100 text-xs font-mono shadow-[0_10px_30px_rgba(0,0,0,0.8),0_0_20px_rgba(56,189,248,0.2)] animate-fade-in">
          <CheckCircle2 size={14} className="text-[#38BDF8]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. PAGE HEADER & AUDIT STRIP */}
      <div className="rounded-3xl glass-card p-6 border border-white/10 space-y-5 shadow-xl relative overflow-hidden">
        {/* Ambient Top Glow */}
        <div className="absolute top-0 right-1/4 w-96 h-32 bg-[#2563EB]/15 blur-3xl rounded-full pointer-events-none" />

        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2.5">
              <h1 className="text-2xl sm:text-3xl font-display font-bold text-white tracking-tight">
                Vulnerability Findings
              </h1>

              {/* Demo Badge */}
              <span className="text-[10px] font-mono font-semibold px-2.5 py-0.5 rounded-full bg-[#F59E0B]/10 text-[#FBBF24] border border-[#F59E0B]/30 tracking-wide uppercase">
                DEMO RESULTS · SIMULATED RUNTIME
              </span>

              {/* Status indicator */}
              <span className="inline-flex items-center gap-1.5 text-xs font-mono px-3 py-1 rounded-full bg-[#10B981]/10 text-[#34D399] border border-[#10B981]/25">
                <span className="w-1.5 h-1.5 rounded-full bg-[#34D399] animate-pulse" />
                AST Taint + Symbolic Analysis Complete
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
              Explore detected source code vulnerabilities, deterministic taint propagation chains, and validated neural-symbolic repair candidates. All findings include verified AST sinks and formal invariant proof obligations.
            </p>
          </div>

          {/* Quick Actions: Refresh & Export */}
          <div className="flex items-center gap-2.5 shrink-0 self-start xl:self-center">
            <button
              onClick={handleSimulateRefresh}
              disabled={isRefreshing}
              title="Re-run static graph check"
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-full bg-[#0A162B] hover:bg-[#122444] border border-white/10 text-xs font-mono text-slate-200 transition-all btn-press disabled:opacity-50"
            >
              <RefreshCw size={13} className={isRefreshing ? 'animate-spin text-[#38BDF8]' : 'text-slate-400'} />
              <span>{isRefreshing ? 'Analyzing AST...' : 'Sync Graph'}</span>
            </button>

            <button
              onClick={() => setExportModalOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#122444] hover:bg-[#1A335E] border border-[#38BDF8]/30 text-xs font-mono text-[#38BDF8] font-bold transition-all shadow-md btn-press"
            >
              <Download size={13} />
              <span>Export Report</span>
            </button>
          </div>
        </div>

        {/* Audit Meta Bar (Repository, Scan ID, Status, Timestamp, Stats) */}
        <div className="pt-4 border-t border-white/10 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-xs">
          {/* Target Repository Selector */}
          <div className="space-y-1 col-span-2 sm:col-span-1">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Repository Scope</span>
            <select
              value={selectedRepo}
              onChange={(e) => setSelectedRepo(e.target.value)}
              className="w-full bg-[#070E1B] border border-white/15 rounded-xl px-2.5 py-1.5 text-xs text-slate-100 font-mono outline-none focus:border-[#38BDF8] transition-colors"
            >
              <option value="all">All Repositories (14 protected)</option>
              {MOCK_REPOSITORIES.map((repo) => (
                <option key={repo.id} value={repo.name}>
                  {repo.name} ({repo.language})
                </option>
              ))}
            </select>
          </div>

          {/* Scan Identifier */}
          <div className="space-y-1">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Scan Identifier</span>
            <div className="flex items-center gap-1.5 text-slate-200 font-semibold py-1.5">
              <span className="text-[#38BDF8]">SCN-2026-9021</span>
              <span className="text-[10px] text-slate-400">· HEAD</span>
            </div>
          </div>

          {/* Timestamp */}
          <div className="space-y-1">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Scan Timestamp</span>
            <div className="text-slate-200 py-1.5">Today, 11:42 UTC</div>
          </div>

          {/* Total Findings */}
          <div className="space-y-1">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Total Findings</span>
            <div className="flex items-center gap-1.5 py-1.5">
              <span className="text-sm font-bold text-white tabular-nums">{scopedFindings.length}</span>
              <span className="text-[11px] text-slate-400">flagged</span>
            </div>
          </div>

          {/* Critical Severity Count */}
          <div className="space-y-1">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Critical Risk</span>
            <div className="flex items-center gap-1.5 py-1.5">
              <span className="text-sm font-bold text-[#F87171] tabular-nums">{criticalCount}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#F87171]/10 text-[#F87171] border border-[#F87171]/20">
                P0 Blockers
              </span>
            </div>
          </div>

          {/* High Severity Count */}
          <div className="space-y-1">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">High Severity</span>
            <div className="flex items-center gap-1.5 py-1.5">
              <span className="text-sm font-bold text-[#FBBF24] tabular-nums">{highCount}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#FBBF24]/10 text-[#FBBF24] border border-[#FBBF24]/20">
                Patch Ready: {patchReadyCount}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. FINDINGS FILTERS TOOLBAR */}
      <div className="rounded-3xl glass-card p-5 border border-white/10 space-y-4 shadow-lg">
        {/* Main Search & Mode Bar */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search size={15} className="absolute left-3.5 top-3.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search findings by title, CWE ID (e.g. CWE-89), file path, or keyword..."
              className="w-full pl-10 pr-10 py-2.5 rounded-full bg-[#070E1B] border border-white/15 text-xs text-slate-100 placeholder-slate-500 outline-none focus:border-[#38BDF8] transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-3 text-slate-400 hover:text-white"
              >
                <X size={14} />
              </button>
            )}
          </div>

          {/* File path quick filter */}
          <div className="relative md:w-56">
            <FileCode2 size={14} className="absolute left-3.5 top-3 text-slate-400" />
            <input
              type="text"
              value={filePathFilter}
              onChange={(e) => setFilePathFilter(e.target.value)}
              placeholder="Filter file path..."
              className="w-full pl-9 pr-3 py-2.5 rounded-full bg-[#070E1B] border border-white/15 text-xs text-slate-100 placeholder-slate-500 outline-none focus:border-[#38BDF8] transition-colors font-mono"
            />
          </div>

          {/* Sort Control */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-slate-400 shrink-0">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-[#070E1B] border border-white/15 rounded-full px-3 py-2 text-xs font-mono text-slate-200 outline-none focus:border-[#38BDF8]"
            >
              <option value="severity-desc">Severity: High to Low</option>
              <option value="severity-asc">Severity: Low to High</option>
              <option value="confidence-desc">Confidence: Highest First</option>
              <option value="file-asc">File Path: A to Z</option>
              <option value="status">Status</option>
            </select>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center gap-1 p-1 rounded-full bg-[#070E1B] border border-white/10 shrink-0">
            <button
              onClick={() => setViewMode('cards')}
              className={`p-1.5 rounded-full transition-all ${
                viewMode === 'cards'
                  ? 'bg-[#122444] text-[#38BDF8] shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Card View"
            >
              <LayoutGrid size={15} />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-full transition-all ${
                viewMode === 'table'
                  ? 'bg-[#122444] text-[#38BDF8] shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
              title="Table View"
            >
              <Table size={15} />
            </button>
          </div>
        </div>

        {/* Multi-attribute Filter Row */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-white/5 text-xs font-mono">
          {/* Severity Pills */}
          <div className="flex items-center gap-1">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider mr-1">Severity:</span>
            {['All', 'Critical', 'High', 'Medium', 'Low'].map((sev) => {
              const active = selectedSeverity === sev;
              return (
                <button
                  key={sev}
                  onClick={() => setSelectedSeverity(sev)}
                  className={`px-3 py-1 rounded-full transition-all text-xs font-mono btn-press ${
                    active
                      ? sev === 'Critical'
                        ? 'bg-[#F87171]/20 text-[#F87171] border border-[#F87171]/40 font-bold'
                        : sev === 'High'
                        ? 'bg-[#FBBF24]/20 text-[#FBBF24] border border-[#FBBF24]/40 font-bold'
                        : 'bg-[#122444] text-[#38BDF8] border border-[#38BDF8]/40 font-bold'
                      : 'bg-[#070E1B] text-slate-400 hover:text-slate-200 border border-white/10'
                  }`}
                >
                  {sev}
                </button>
              );
            })}
          </div>

          <div className="h-4 w-[1px] bg-white/10 mx-1 hidden sm:block" />

          {/* Category Dropdown */}
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider">Category:</span>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-[#070E1B] border border-white/15 rounded-full px-3 py-1 text-xs text-slate-200 outline-none focus:border-[#38BDF8]"
            >
              <option value="All">All Categories</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Language Dropdown */}
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider">Language:</span>
            <select
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="bg-[#070E1B] border border-white/15 rounded-full px-3 py-1 text-xs text-slate-200 outline-none focus:border-[#38BDF8]"
            >
              <option value="All">All Languages</option>
              {languages.map((lang) => (
                <option key={lang} value={lang}>
                  {lang}
                </option>
              ))}
            </select>
          </div>

          {/* Remediation Status Dropdown */}
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider">Status:</span>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="bg-[#070E1B] border border-white/15 rounded-full px-3 py-1 text-xs text-slate-200 outline-none focus:border-[#38BDF8]"
            >
              <option value="All">All Statuses</option>
              {statuses.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>

          {/* Reset Filters CTA */}
          {isFiltered && (
            <button
              onClick={handleResetFilters}
              className="ml-auto inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F87171]/10 hover:bg-[#F87171]/20 border border-[#F87171]/30 text-[#F87171] text-xs font-mono transition-colors btn-press"
            >
              <RotateCcw size={12} />
              <span>Reset Filters</span>
            </button>
          )}
        </div>

        {/* Results Counter strip */}
        <div className="flex items-center justify-between text-xs font-mono text-slate-400 pt-1">
          <div>
            Showing <span className="text-white font-bold">{filteredFindings.length}</span> of{' '}
            <span className="text-slate-300">{MOCK_VULNERABILITIES.length}</span> verified findings
            {isFiltered && <span className="text-[#38BDF8] ml-2">(Filtered view)</span>}
          </div>

          {/* Honest scanner limitation disclaimer */}
          <span className="text-[11px] text-slate-400 hidden md:inline">
            * Static analysis covers supported taint propagation patterns. Custom runtime plugins require dynamic fuzzing.
          </span>
        </div>
      </div>

      {/* 3. FINDINGS LIST OR TABLE VIEW */}
      {viewMode === 'cards' ? (
        /* CARDS VIEW */
        <div className="space-y-4">
          {filteredFindings.map((vuln) => {
            const isCritical = vuln.severity === 'Critical';
            const isHigh = vuln.severity === 'High';
            const isSelected = selectedVulnId === vuln.id;

            return (
              <div
                key={vuln.id}
                className={`rounded-2xl glass-card p-5 border transition-all space-y-4 group shadow-lg ${
                  isSelected
                    ? 'border-[#38BDF8] bg-[#0A1A33]/90 ring-1 ring-[#38BDF8]/40'
                    : 'border-white/10 hover:border-white/20'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                  <div className="space-y-2 flex-1 min-w-0">
                    {/* Badges Strip */}
                    <div className="flex flex-wrap items-center gap-2">
                      {/* Severity Badge */}
                      <span
                        className={`inline-flex items-center gap-1.5 text-xs font-mono px-2.5 py-0.5 rounded-full font-bold ${
                          isCritical
                            ? 'text-[#F87171] bg-[#F87171]/15 border border-[#F87171]/30 shadow-sm'
                            : isHigh
                            ? 'text-[#FBBF24] bg-[#FBBF24]/15 border border-[#FBBF24]/30'
                            : 'text-[#818CF8] bg-[#818CF8]/15 border border-[#818CF8]/30'
                        }`}
                      >
                        <ShieldAlert size={12} />
                        <span>{vuln.severity}</span>
                      </span>

                      {/* CWE Identifier */}
                      <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-slate-200 font-semibold">
                        {vuln.cwe}
                      </span>

                      {/* Category Badge */}
                      <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-[#122444] border border-[#38BDF8]/20 text-[#38BDF8]">
                        {vuln.category}
                      </span>

                      {/* CVSS Score */}
                      <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-slate-300">
                        CVSS {vuln.cvss}
                      </span>

                      {/* Confidence Level */}
                      <span className="text-[11px] font-mono px-2.5 py-0.5 rounded-full bg-[#10B981]/10 text-[#34D399] border border-[#10B981]/25">
                        {vuln.confidence}% · {vuln.confidenceLevel}
                      </span>

                      {/* Remediation Status */}
                      <span
                        className={`text-[11px] font-mono px-2.5 py-0.5 rounded-full font-medium border ${
                          vuln.status === 'Patch Ready'
                            ? 'bg-[#38BDF8]/10 text-[#38BDF8] border-[#38BDF8]/30'
                            : vuln.status === 'Verified Fixed'
                            ? 'bg-[#10B981]/10 text-[#34D399] border-[#10B981]/30'
                            : vuln.status === 'Suppressed'
                            ? 'bg-slate-800 text-slate-400 border-slate-700'
                            : 'bg-amber-500/10 text-amber-300 border-amber-500/20'
                        }`}
                      >
                        {vuln.status}
                      </span>
                    </div>

                    {/* Title */}
                    <h2
                      onClick={() => handleOpenDetail(vuln)}
                      className="text-base sm:text-lg font-semibold text-white group-hover:text-[#38BDF8] transition-colors cursor-pointer tracking-tight"
                    >
                      {vuln.title}
                    </h2>

                    {/* Affected File & Location */}
                    <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-slate-400">
                      <span className="text-slate-200 font-medium">{vuln.repository}</span>
                      <span>›</span>
                      <span className="text-[#38BDF8] bg-[#070E1B] px-2 py-0.5 rounded-md border border-white/10">
                        {vuln.file}:{vuln.line}
                      </span>
                      <span>·</span>
                      <span className="text-slate-300">{vuln.language}</span>
                      <span>·</span>
                      <span className="text-slate-400 truncate max-w-sm">Source: {vuln.evidenceSource}</span>
                    </div>

                    {/* Description preview */}
                    <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                      {vuln.description}
                    </p>
                  </div>

                  {/* Actions Right */}
                  <div className="flex items-center gap-2.5 shrink-0 self-start lg:self-center">
                    <button
                      onClick={() => handleOpenDetail(vuln)}
                      className="px-4 py-2 rounded-full bg-[#0A162B] hover:bg-[#122444] border border-white/15 text-xs font-mono text-slate-200 hover:text-white transition-colors btn-press"
                    >
                      Inspect Evidence
                    </button>

                    <button
                      onClick={() => handleOpenRemediation(vuln.id)}
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 text-[#070E1B] text-xs font-mono font-bold transition-all shadow-md btn-press"
                    >
                      <Wrench size={13} />
                      <span>Generate Secure Fix</span>
                    </button>
                  </div>
                </div>

                {/* Taint Data Flow Strip */}
                <div className="p-3 rounded-2xl bg-[#060D1A] border border-white/10 font-mono text-xs flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2 text-slate-300 truncate max-w-2xl">
                    <span className="text-slate-400 shrink-0 font-medium text-[11px] uppercase tracking-wider">
                      AST Taint Flow:
                    </span>
                    <span className="text-[#38BDF8] truncate font-medium">{vuln.taintedFlow}</span>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-[11px] text-[#34D399] font-medium flex items-center gap-1">
                      <CheckCircle2 size={12} />
                      {vuln.validationTests.filter((t) => t.status === 'passed').length} Invariant Tests Passing
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* DENSE TABLE VIEW */
        <div className="rounded-3xl glass-card border border-white/10 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead className="bg-[#070E1B] border-b border-white/10 text-slate-400 uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3.5 px-4 font-semibold">Severity</th>
                  <th className="py-3.5 px-4 font-semibold">Finding Title & CWE</th>
                  <th className="py-3.5 px-4 font-semibold">Affected File & Line</th>
                  <th className="py-3.5 px-4 font-semibold">Category / Lang</th>
                  <th className="py-3.5 px-4 font-semibold">Evidence Confidence</th>
                  <th className="py-3.5 px-4 font-semibold">Status</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredFindings.map((vuln) => {
                  const isCritical = vuln.severity === 'Critical';
                  const isHigh = vuln.severity === 'High';

                  return (
                    <tr
                      key={vuln.id}
                      className="hover:bg-white/[0.02] transition-colors group cursor-pointer"
                      onClick={() => handleOpenDetail(vuln)}
                    >
                      {/* Severity */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold text-[11px] ${
                            isCritical
                              ? 'text-[#F87171] bg-[#F87171]/15 border border-[#F87171]/30'
                              : isHigh
                              ? 'text-[#FBBF24] bg-[#FBBF24]/15 border border-[#FBBF24]/30'
                              : 'text-[#818CF8] bg-[#818CF8]/15 border border-[#818CF8]/30'
                          }`}
                        >
                          <ShieldAlert size={11} />
                          {vuln.severity}
                        </span>
                      </td>

                      {/* Finding Title & CWE */}
                      <td className="py-3.5 px-4 max-w-sm">
                        <div className="font-sans font-semibold text-white group-hover:text-[#38BDF8] transition-colors truncate">
                          {vuln.title}
                        </div>
                        <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-400">
                          <span className="text-[#38BDF8] font-semibold">{vuln.cwe}</span>
                          <span>·</span>
                          <span>CVSS {vuln.cvss}</span>
                        </div>
                      </td>

                      {/* File & Line */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="text-slate-200 truncate max-w-xs">{vuln.file}</div>
                        <div className="text-slate-400 text-[11px]">Line {vuln.line} ({vuln.repository})</div>
                      </td>

                      {/* Category & Language */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="text-slate-200">{vuln.category}</div>
                        <div className="text-slate-400 text-[11px]">{vuln.language}</div>
                      </td>

                      {/* Confidence */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <div className="w-12 h-1.5 rounded-full bg-slate-800 overflow-hidden">
                            <div
                              className="h-full bg-[#10B981] rounded-full"
                              style={{ width: `${vuln.confidence}%` }}
                            />
                          </div>
                          <span className="text-slate-200 text-[11px]">{vuln.confidence}%</span>
                        </div>
                        <div className="text-[10px] text-slate-400">{vuln.confidenceLevel}</div>
                      </td>

                      {/* Remediation Status */}
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span
                          className={`text-[10px] px-2.5 py-0.5 rounded-full border ${
                            vuln.status === 'Patch Ready'
                              ? 'bg-[#38BDF8]/10 text-[#38BDF8] border-[#38BDF8]/30'
                              : vuln.status === 'Verified Fixed'
                              ? 'bg-[#10B981]/10 text-[#34D399] border-[#10B981]/30'
                              : vuln.status === 'Suppressed'
                              ? 'bg-slate-800 text-slate-400 border-slate-700'
                              : 'bg-amber-500/10 text-amber-300 border-amber-500/20'
                          }`}
                        >
                          {vuln.status}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleOpenDetail(vuln)}
                            className="p-1.5 rounded-full hover:bg-white/10 text-slate-300 hover:text-white"
                            title="Inspect Finding Details"
                          >
                            <ChevronRight size={15} />
                          </button>
                          <button
                            onClick={() => handleOpenRemediation(vuln.id)}
                            className="px-3 py-1 rounded-full bg-white hover:bg-slate-100 text-[#070E1B] font-bold text-[11px] btn-press"
                          >
                            Fix
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. EMPTY STATE */}
      {filteredFindings.length === 0 && (
        <div className="py-16 text-center rounded-3xl glass-card border border-white/10 space-y-4 shadow-xl">
          <div className="w-14 h-14 mx-auto rounded-full bg-[#122444] border border-[#38BDF8]/30 flex items-center justify-center text-[#38BDF8]">
            <ShieldCheck size={28} />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-display font-bold text-white tracking-tight">
              No Vulnerability Findings Matched
            </h3>
            <p className="text-xs text-slate-300 max-w-md mx-auto">
              No security weaknesses match your current combination of severity, category, language, or search queries.
            </p>
          </div>
          <button
            onClick={handleResetFilters}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white text-[#070E1B] text-xs font-mono font-bold hover:bg-slate-100 transition-all btn-press shadow-md"
          >
            <RotateCcw size={13} />
            <span>Reset All Filters</span>
          </button>
        </div>
      )}

      {/* 5. SLIDE-OVER / DETAILED FINDING INSPECTOR DRAWER */}
      {drawerOpen && selectedFinding && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/80 backdrop-blur-xl animate-fade-in">
          <div
            className="w-full max-w-3xl h-full bg-[#081224] border-l border-white/15 shadow-[0_0_80px_rgba(0,0,0,0.9)] flex flex-col overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Drawer Header */}
            <div className="p-6 border-b border-white/10 bg-[#0A162B] shrink-0 space-y-3">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={`text-xs font-mono px-2.5 py-0.5 rounded-full font-bold ${
                        selectedFinding.severity === 'Critical'
                          ? 'text-[#F87171] bg-[#F87171]/15 border border-[#F87171]/30'
                          : 'text-[#FBBF24] bg-[#FBBF24]/15 border border-[#FBBF24]/30'
                      }`}
                    >
                      {selectedFinding.severity}
                    </span>

                    <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-slate-200 font-semibold">
                      {selectedFinding.cwe}
                    </span>

                    <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-[#38BDF8]/10 text-[#38BDF8] border border-[#38BDF8]/30 font-semibold">
                      CVSS {selectedFinding.cvss}
                    </span>

                    <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-[#10B981]/10 text-[#34D399] border border-[#10B981]/25">
                      {selectedFinding.confidence}% · {selectedFinding.confidenceLevel}
                    </span>
                  </div>

                  <h2 className="text-xl font-display font-bold text-white tracking-tight">
                    {selectedFinding.title}
                  </h2>

                  <div className="text-xs font-mono text-slate-400">
                    Location: <span className="text-slate-200">{selectedFinding.repository}</span> ›{' '}
                    <span className="text-[#38BDF8]">{selectedFinding.file}:{selectedFinding.line}</span>
                  </div>
                </div>

                <button
                  onClick={() => setDrawerOpen(false)}
                  className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors btn-press"
                  title="Close Inspector"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Drawer Tab Switcher */}
              <div className="flex items-center gap-2 pt-2 border-t border-white/10 font-mono text-xs">
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`px-3 py-1.5 rounded-full transition-all btn-press ${
                    activeTab === 'overview'
                      ? 'bg-[#122444] text-[#38BDF8] font-bold border border-[#38BDF8]/40'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Evidence & Taint Graph
                </button>
                <button
                  onClick={() => setActiveTab('code')}
                  className={`px-3 py-1.5 rounded-full transition-all btn-press ${
                    activeTab === 'code'
                      ? 'bg-[#122444] text-[#38BDF8] font-bold border border-[#38BDF8]/40'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Source Code View
                </button>
                <button
                  onClick={() => setActiveTab('remediation')}
                  className={`px-3 py-1.5 rounded-full transition-all btn-press ${
                    activeTab === 'remediation'
                      ? 'bg-[#122444] text-[#38BDF8] font-bold border border-[#38BDF8]/40'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  AI Repair Strategy
                </button>
              </div>
            </div>

            {/* Drawer Body Scroll */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  {/* Confirmed Evidence vs AI Interpretation Banner */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
                    <div className="p-3.5 rounded-2xl bg-[#0A162B] border border-white/10 space-y-1">
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold flex items-center gap-1.5 text-[#38BDF8]">
                        <Cpu size={12} />
                        <span>Confirmed Scanner Evidence</span>
                      </div>
                      <div className="text-slate-200 text-xs">
                        Source: {selectedFinding.evidenceSource}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {selectedFinding.confidence}% confidence · Deterministic static AST flow
                      </div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-[#122444]/60 border border-[#38BDF8]/25 space-y-1">
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold flex items-center gap-1.5 text-[#60A5FA]">
                        <Sparkles size={12} />
                        <span>AI Remediation Interpretation</span>
                      </div>
                      <div className="text-slate-200 text-xs">
                        Neural-Symbolic AST Invariant Prover
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Verified against {selectedFinding.validationTests.length} regression suites
                      </div>
                    </div>
                  </div>

                  {/* Why Flagged */}
                  <div className="space-y-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block font-semibold">
                      Why Flagged by Scanner
                    </span>
                    <div className="p-4 rounded-2xl bg-[#0A162B] border border-white/10 text-xs text-slate-200 font-mono leading-relaxed">
                      {selectedFinding.whyFlagged}
                    </div>
                  </div>

                  {/* Inter-procedural Taint Propagation Trace */}
                  <div className="space-y-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block font-semibold">
                      Inter-procedural AST Taint Propagation Flow
                    </span>
                    <div className="p-4 rounded-2xl bg-[#060D1A] border border-[#38BDF8]/30 font-mono text-xs space-y-2">
                      <div className="text-slate-400 text-[11px]">Trace:</div>
                      <div className="text-[#38BDF8] font-semibold text-xs leading-relaxed">
                        {selectedFinding.taintedFlow}
                      </div>
                    </div>
                  </div>

                  {/* Potential Impact & CIA Triad */}
                  <div className="space-y-3">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block font-semibold">
                      Potential Impact & CIA Triad Rating
                    </span>
                    <div className="p-4 rounded-2xl bg-[#0A162B] border border-white/10 space-y-3">
                      <div className="grid grid-cols-3 gap-2 text-center font-mono text-xs">
                        <div className="p-2 rounded-xl bg-[#070E1B] border border-white/10">
                          <span className="text-[10px] text-slate-400 block">Confidentiality</span>
                          <span
                            className={`font-bold ${
                              selectedFinding.potentialImpact.confidentiality === 'High'
                                ? 'text-[#F87171]'
                                : selectedFinding.potentialImpact.confidentiality === 'Medium'
                                ? 'text-[#FBBF24]'
                                : 'text-slate-300'
                            }`}
                          >
                            {selectedFinding.potentialImpact.confidentiality}
                          </span>
                        </div>
                        <div className="p-2 rounded-xl bg-[#070E1B] border border-white/10">
                          <span className="text-[10px] text-slate-400 block">Integrity</span>
                          <span
                            className={`font-bold ${
                              selectedFinding.potentialImpact.integrity === 'High'
                                ? 'text-[#F87171]'
                                : selectedFinding.potentialImpact.integrity === 'Medium'
                                ? 'text-[#FBBF24]'
                                : 'text-slate-300'
                            }`}
                          >
                            {selectedFinding.potentialImpact.integrity}
                          </span>
                        </div>
                        <div className="p-2 rounded-xl bg-[#070E1B] border border-white/10">
                          <span className="text-[10px] text-slate-400 block">Availability</span>
                          <span
                            className={`font-bold ${
                              selectedFinding.potentialImpact.availability === 'High'
                                ? 'text-[#F87171]'
                                : selectedFinding.potentialImpact.availability === 'Medium'
                                ? 'text-[#FBBF24]'
                                : 'text-slate-300'
                            }`}
                          >
                            {selectedFinding.potentialImpact.availability}
                          </span>
                        </div>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        {selectedFinding.potentialImpact.summary}
                      </p>
                    </div>
                  </div>

                  {/* Vulnerability Description */}
                  <div className="space-y-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block font-semibold">
                      Full Risk Explanation
                    </span>
                    <div className="p-4 rounded-2xl bg-[#0A162B] border border-white/10 text-xs text-slate-300 leading-relaxed">
                      {selectedFinding.description}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'code' && (
                <div className="space-y-4">
                  {/* Code Viewer Controls */}
                  <div className="flex items-center justify-between font-mono text-xs">
                    <div className="text-slate-400">
                      File:{' '}
                      <span className="text-slate-200">
                        {selectedFinding.file} (Line {selectedFinding.line})
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {selectedFinding.surroundingContext && (
                        <button
                          onClick={() => setShowFullContext(!showFullContext)}
                          className="px-3 py-1 rounded-full bg-[#0A162B] hover:bg-[#122444] border border-white/10 text-slate-300 hover:text-white transition-colors"
                        >
                          {showFullContext ? 'Show Focused Snippet' : 'Toggle Enclosing Context (±15 lines)'}
                        </button>
                      )}

                      <button
                        onClick={() =>
                          handleCopyCode(
                            showFullContext && selectedFinding.surroundingContext
                              ? selectedFinding.surroundingContext.code
                              : selectedFinding.vulnerableCode
                          )
                        }
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#122444] hover:bg-[#1A335E] border border-white/15 text-[#38BDF8] transition-colors"
                      >
                        {copiedCode ? <Check size={12} /> : <Copy size={12} />}
                        <span>{copiedCode ? 'Copied!' : 'Copy Code'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Syntax Highlighted Monospace Code Panel with Line Numbers */}
                  <div className="rounded-2xl bg-[#050B16] border border-white/15 p-4 font-mono text-xs overflow-x-auto shadow-inner space-y-1">
                    {(() => {
                      const codeToRender =
                        showFullContext && selectedFinding.surroundingContext
                          ? selectedFinding.surroundingContext.code
                          : selectedFinding.vulnerableCode;

                      const startLine =
                        showFullContext && selectedFinding.surroundingContext
                          ? selectedFinding.surroundingContext.startLine
                          : selectedFinding.line - 2;

                      const lines = codeToRender.split('\n');

                      return lines.map((lineText, idx) => {
                        const currentLineNum = startLine + idx;
                        const isFlaggedLine = currentLineNum === selectedFinding.line;

                        return (
                          <div
                            key={idx}
                            className={`flex items-start gap-4 px-2 py-0.5 rounded ${
                              isFlaggedLine
                                ? 'bg-[#F87171]/15 text-[#FCA5A5] border-l-2 border-[#F87171]'
                                : 'text-slate-300 hover:bg-white/[0.02]'
                            }`}
                          >
                            <span className="w-8 shrink-0 text-right select-none text-slate-500 text-[11px]">
                              {currentLineNum}
                            </span>
                            <pre className="flex-1 font-mono leading-relaxed whitespace-pre overflow-x-auto">
                              {lineText}
                            </pre>
                            {isFlaggedLine && (
                              <span className="shrink-0 text-[10px] font-bold text-[#F87171] uppercase select-none">
                                ← Flagged Sink
                              </span>
                            )}
                          </div>
                        );
                      });
                    })()}
                  </div>
                </div>
              )}

              {activeTab === 'remediation' && (
                <div className="space-y-6">
                  {/* Suggested Remediation Narrative */}
                  <div className="space-y-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block font-semibold">
                      Suggested Fix Strategy
                    </span>
                    <div className="p-4 rounded-2xl bg-[#0A162B] border border-white/10 text-xs text-slate-200 leading-relaxed">
                      {selectedFinding.suggestedRemediation}
                    </div>
                  </div>

                  {/* Formal Invariant Requirement */}
                  <div className="space-y-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block font-semibold">
                      Formal Mathematical AST Invariant
                    </span>
                    <div className="p-4 rounded-2xl bg-[#060D1A] border border-[#38BDF8]/20 font-mono text-xs text-[#38BDF8]">
                      {selectedFinding.formalInvariant}
                    </div>
                  </div>

                  {/* Proposed Patch Preview */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block font-semibold">
                        Synthesized Patch Preview
                      </span>
                      <span className="text-[11px] font-mono text-[#34D399]">
                        Verified Invariants: {selectedFinding.validationTests.length}/{selectedFinding.validationTests.length}
                      </span>
                    </div>

                    <div className="bg-[#04151C]/90 rounded-2xl border border-[#34D399]/30 p-4 font-mono text-xs overflow-x-auto text-[#6EE7B7]">
                      <pre>{selectedFinding.patchedCode}</pre>
                    </div>
                  </div>

                  {/* Test Suites */}
                  <div className="space-y-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block font-semibold">
                      Automated Verification Harness
                    </span>
                    <div className="space-y-2">
                      {selectedFinding.validationTests.map((test, i) => (
                        <div
                          key={i}
                          className="p-3 rounded-xl bg-[#070E1B] border border-white/10 text-xs font-mono flex items-center justify-between gap-3"
                        >
                          <div className="flex items-center gap-2">
                            <CheckCircle2 size={14} className="text-[#34D399] shrink-0" />
                            <div>
                              <div className="text-slate-200 font-semibold">{test.name}</div>
                              <div className="text-[10px] text-slate-400">{test.detail}</div>
                            </div>
                          </div>
                          <span className="text-[11px] text-[#34D399] shrink-0">{test.duration}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Drawer Footer Buttons */}
            <div className="p-5 border-t border-white/10 bg-[#0A162B] flex items-center justify-between gap-4 shrink-0">
              <button
                onClick={() => setDrawerOpen(false)}
                className="px-4 py-2 rounded-full bg-[#070E1B] hover:bg-white/10 border border-white/10 text-xs font-mono text-slate-300 transition-colors btn-press"
              >
                Close Inspector
              </button>

              <button
                onClick={() => handleOpenRemediation(selectedFinding.id)}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-white hover:bg-slate-100 text-[#070E1B] text-xs font-mono font-bold transition-all shadow-lg shadow-white/10 btn-press"
              >
                <Wrench size={14} />
                <span>Open in AI Remediation Workbench</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. EXPORT REPORT MODAL */}
      {exportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl animate-fade-in">
          <div
            className="w-full max-w-lg rounded-3xl bg-[#081224] border border-white/15 p-6 shadow-2xl space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <h3 className="text-lg font-display font-bold text-white tracking-tight">
                  Export Security Findings
                </h3>
                <p className="text-xs text-slate-300">
                  Select a standardized compliance format for report generation.
                </p>
              </div>
              <button
                onClick={() => setExportModalOpen(false)}
                className="p-1 rounded-full text-slate-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3 font-mono text-xs">
              {/* SARIF 2.1.0 */}
              <div
                onClick={() => handleExport('sarif')}
                className="p-4 rounded-2xl bg-[#0A162B] hover:bg-[#122444] border border-white/10 hover:border-[#38BDF8]/40 transition-all cursor-pointer group flex items-start justify-between"
              >
                <div className="space-y-1">
                  <div className="font-bold text-white group-hover:text-[#38BDF8] flex items-center gap-1.5">
                    <span>OASIS SARIF 2.1.0</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#38BDF8]/10 text-[#38BDF8] border border-[#38BDF8]/30">
                      Standard
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Static Analysis Results Interchange Format for GitHub Code Scanning, GitLab SAST, and CI/CD pipelines.
                  </p>
                </div>
                <Download size={16} className="text-slate-400 group-hover:text-[#38BDF8] shrink-0 mt-1" />
              </div>

              {/* JSON Format */}
              <div
                onClick={() => handleExport('json')}
                className="p-4 rounded-2xl bg-[#0A162B] hover:bg-[#122444] border border-white/10 hover:border-[#38BDF8]/40 transition-all cursor-pointer group flex items-start justify-between"
              >
                <div className="space-y-1">
                  <div className="font-bold text-white group-hover:text-[#38BDF8]">
                    Raw JSON AST Payload
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Complete machine-readable payload containing taint sources, sinks, AST invariants, and CVSS vectors.
                  </p>
                </div>
                <Download size={16} className="text-slate-400 group-hover:text-[#38BDF8] shrink-0 mt-1" />
              </div>

              {/* CSV Summary */}
              <div
                onClick={() => handleExport('csv')}
                className="p-4 rounded-2xl bg-[#0A162B] hover:bg-[#122444] border border-white/10 hover:border-[#38BDF8]/40 transition-all cursor-pointer group flex items-start justify-between"
              >
                <div className="space-y-1">
                  <div className="font-bold text-white group-hover:text-[#38BDF8]">
                    Executive CSV Audit Sheet
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Spreadsheet-ready summary for compliance officers, SOC2 auditors, and executive security reviews.
                  </p>
                </div>
                <Download size={16} className="text-slate-400 group-hover:text-[#38BDF8] shrink-0 mt-1" />
              </div>
            </div>

            <div className="pt-2 text-right">
              <button
                onClick={() => setExportModalOpen(false)}
                className="px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 text-xs font-mono text-slate-300"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import { ArrowRight, Menu, X } from 'lucide-react';
import { QuantixLogo } from './QuantixLogo';

interface NavbarProps {
  onContactClick?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onContactClick }) => {
  const [activeItem, setActiveItem] = useState('Home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'About', href: '#about' },
    { label: 'Feature', href: '#features' },
    { label: 'Pricing', href: '#pricing' },
    { label: 'Integration', href: '#integration' },
    { label: 'Blog', href: '#blog' },
  ];

  return (
    <header className="relative z-50 w-full pt-5 px-4 sm:px-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between gap-4">
        {/* Left: Logo */}
        <a href="#home" className="shrink-0">
          <QuantixLogo size="md" />
        </a>

        {/* Center: Floating Translucent Pill Navigation */}
        <nav className="hidden md:flex items-center bg-[#130B24]/80 backdrop-blur-xl border border-white/10 rounded-full px-1.5 py-1.5 shadow-[0_4px_24px_rgba(0,0,0,0.5)]">
          {navLinks.map((link) => {
            const isActive = activeItem === link.label;
            return (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setActiveItem(link.label)}
                className={`text-xs font-medium px-4 py-1.5 rounded-full transition-all duration-200 ${
                  isActive
                    ? 'bg-[#7C3AED] text-white shadow-[0_0_12px_rgba(124,58,237,0.5)]'
                    : 'text-[#C4B5FD]/75 hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                {link.label}
              </a>
            );
          })}
        </nav>

        {/* Right: Contact Button */}
        <div className="hidden md:flex items-center">
          <button
            onClick={onContactClick}
            className="btn-purple-primary flex items-center gap-1.5 px-5 py-2 rounded-full text-xs font-semibold text-white tracking-wide shadow-[0_0_18px_rgba(124,58,237,0.45)] cursor-pointer"
          >
            <span>Contact</span>
            <ArrowRight size={13} className="stroke-[2.5]" />
          </button>
        </div>

        {/* Mobile Menu Trigger */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 rounded-full bg-[#130B24]/80 border border-white/10 text-white"
          aria-label="Toggle Navigation Menu"
        >
          {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden mt-3 p-4 rounded-2xl bg-[#0F0820]/95 backdrop-blur-2xl border border-white/10 shadow-2xl animate-fade-in space-y-3">
          <div className="flex flex-col space-y-1">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => {
                  setActiveItem(link.label);
                  setMobileMenuOpen(false);
                }}
                className={`text-sm px-4 py-2 rounded-xl transition-colors ${
                  activeItem === link.label
                    ? 'bg-[#7C3AED] text-white font-semibold'
                    : 'text-slate-300 hover:bg-white/5'
                }`}
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="pt-2 border-t border-white/10">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                if (onContactClick) onContactClick();
              }}
              className="btn-purple-primary w-full flex items-center justify-center gap-2 py-2.5 rounded-full text-sm font-semibold text-white"
            >
              <span>Contact</span>
              <ArrowRight size={15} />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

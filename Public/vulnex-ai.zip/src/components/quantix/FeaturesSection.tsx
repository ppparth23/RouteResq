import React from 'react';
import { ArrowRight, Bot, Mic } from 'lucide-react';

interface FeaturesSectionProps {
  onExploreFeatures?: () => void;
}

export const FeaturesSection: React.FC<FeaturesSectionProps> = ({ onExploreFeatures }) => {
  return (
    <section id="features" className="relative z-10 max-w-5xl mx-auto px-4 mt-28 sm:mt-36 pb-24 text-center">
      {/* 1. Header Section */}
      <div className="flex flex-col items-center max-w-2xl mx-auto mb-14">
        {/* Features decorative badge line */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-px bg-gradient-to-r from-transparent to-purple-400" />
          <span className="text-xs font-semibold text-[#C4B5FD] tracking-wider uppercase">
            Features
          </span>
          <div className="w-8 h-px bg-gradient-to-l from-transparent to-purple-400" />
        </div>

        {/* Heading */}
        <h2 className="text-2xl sm:text-4xl md:text-[2.6rem] font-bold text-white tracking-tight leading-[1.2]">
          Accelerate your setup using <br className="hidden sm:inline" />
          streamlined low-code processes.
        </h2>

        {/* Supporting Text */}
        <p className="mt-3.5 text-xs sm:text-sm text-[#9D96B8] leading-relaxed max-w-xl">
          All the tools you need to optimize operations, enhance productivity, and grow confidently.
          Fueled by AI for intelligent expansion.
        </p>
      </div>

      {/* 2. Feature Cards Grid */}
      <div className="space-y-5 text-left">
        {/* ROW 1: 3 Equal-Width Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Card 1: Quantix AI Solutions */}
          <div className="quantix-card rounded-2xl sm:rounded-3xl p-6 flex flex-col justify-between overflow-hidden relative group">
            {/* Diagonal sheen reflection */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/[0.04] to-transparent pointer-events-none" />

            {/* Illustration: Circuit lines + Central Quantix logo */}
            <div className="h-44 sm:h-48 relative flex items-center justify-center mb-6">
              {/* Purple radial glow */}
              <div className="absolute w-28 h-28 bg-[#8B5CF6]/25 rounded-full blur-2xl" />

              {/* Circuit SVG Graphic */}
              <svg className="w-full h-full max-w-[220px]" viewBox="0 0 220 180" fill="none">
                {/* Circuit lines */}
                <path d="M 110 90 L 110 20 M 100 30 L 100 15 M 120 30 L 120 15" stroke="#7C3AED" strokeWidth="1.5" strokeOpacity="0.7" />
                <path d="M 110 90 L 110 160 M 100 150 L 100 165 M 120 150 L 120 165" stroke="#7C3AED" strokeWidth="1.5" strokeOpacity="0.7" />
                <path d="M 110 90 L 30 90" stroke="#7C3AED" strokeWidth="1.5" strokeOpacity="0.7" />
                <circle cx="30" cy="90" r="3" fill="#A855F7" />
                <path d="M 110 90 L 190 90" stroke="#7C3AED" strokeWidth="1.5" strokeOpacity="0.7" />
                <circle cx="190" cy="90" r="3" fill="#A855F7" />

                {/* Corner circuit tracks */}
                <path d="M 50 40 L 70 40 L 85 55" stroke="#7C3AED" strokeWidth="1.2" strokeOpacity="0.4" />
                <path d="M 170 40 L 150 40 L 135 55" stroke="#7C3AED" strokeWidth="1.2" strokeOpacity="0.4" />
                <path d="M 50 140 L 70 140 L 85 125" stroke="#7C3AED" strokeWidth="1.2" strokeOpacity="0.4" />
                <path d="M 170 140 L 150 140 L 135 125" stroke="#7C3AED" strokeWidth="1.2" strokeOpacity="0.4" />

                {/* Central chip body */}
                <rect x="85" y="65" width="50" height="50" rx="14" fill="#14092A" stroke="#A855F7" strokeWidth="1.5" className="shadow-[0_0_15px_rgba(168,85,247,0.5)]" />
              </svg>

              {/* Central Logo in Chip */}
              <div className="absolute w-8 h-8 rounded-full bg-[#7C3AED] flex items-center justify-center shadow-[0_0_12px_rgba(168,85,247,0.8)]">
                <svg viewBox="0 0 24 24" fill="none" className="w-4 h-4 text-white">
                  <ellipse cx="8.5" cy="8.5" rx="3" ry="3.5" transform="rotate(-30 8.5 8.5)" fill="currentColor" />
                  <ellipse cx="15.5" cy="8.5" rx="3" ry="3.5" transform="rotate(30 15.5 8.5)" fill="currentColor" />
                  <ellipse cx="8.5" cy="15.5" rx="3" ry="3.5" transform="rotate(30 8.5 15.5)" fill="currentColor" />
                  <ellipse cx="15.5" cy="15.5" rx="3" ry="3.5" transform="rotate(-30 15.5 15.5)" fill="currentColor" />
                </svg>
              </div>
            </div>

            {/* Content */}
            <div className="relative z-10">
              <h3 className="text-base sm:text-lg font-bold text-white tracking-tight mb-1.5">
                Quantix AI Solutions
              </h3>
              <p className="text-xs text-[#9D96B8] leading-relaxed">
                AI-powered task management for streamlined and effective workflows.
              </p>
            </div>
          </div>

          {/* Card 2: Custom Support Solutions */}
          <div className="quantix-card rounded-2xl sm:rounded-3xl p-6 flex flex-col justify-between overflow-hidden relative group">
            {/* Diagonal sheen reflection */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/[0.04] to-transparent pointer-events-none" />

            {/* Illustration: Robot avatar + 3 orbiting user avatars */}
            <div className="h-44 sm:h-48 relative flex items-center justify-center mb-6">
              {/* Radial glow */}
              <div className="absolute w-32 h-32 bg-[#8B5CF6]/25 rounded-full blur-2xl" />

              {/* Orbital rings */}
              <div className="absolute w-36 h-36 rounded-full border border-purple-500/20" />
              <div className="absolute w-24 h-24 rounded-full border border-purple-500/30" />

              {/* Central Glowing AI Robot Badge */}
              <div className="relative z-10 w-12 h-12 rounded-full bg-gradient-to-br from-[#8B5CF6] to-[#6D28D9] flex items-center justify-center text-white shadow-[0_0_20px_rgba(139,92,246,0.8)] border border-purple-300/40">
                <Bot size={22} className="stroke-[2.2]" />
              </div>

              {/* Orbiting Avatar 1 (Top) */}
              <div className="absolute top-4 left-1/2 -translate-x-1/2 w-7 h-7 rounded-full overflow-hidden border border-purple-400/60 shadow-[0_0_10px_rgba(168,85,247,0.5)]">
                <img
                  src="/src/assets/images/security_engineer_avatar_1793477459287.jpg"
                  alt="User 1"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Orbiting Avatar 2 (Bottom-Left) */}
              <div className="absolute bottom-5 left-8 w-6 h-6 rounded-full overflow-hidden border border-purple-400/60 shadow-[0_0_10px_rgba(168,85,247,0.5)]">
                <img
                  src="/src/assets/images/security_engineer_avatar_1793477459287.jpg"
                  alt="User 2"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Orbiting Avatar 3 (Right) */}
              <div className="absolute top-1/2 -translate-y-1/2 right-7 w-6 h-6 rounded-full overflow-hidden border border-purple-400/60 shadow-[0_0_10px_rgba(168,85,247,0.5)]">
                <img
                  src="/src/assets/images/security_engineer_avatar_1793477459287.jpg"
                  alt="User 3"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Content */}
            <div className="relative z-10">
              <h3 className="text-base sm:text-lg font-bold text-white tracking-tight mb-1.5">
                Custom Support Solutions
              </h3>
              <p className="text-xs text-[#9D96B8] leading-relaxed">
                Many tasks are now automated, allowing your users to work more effectively.
              </p>
            </div>
          </div>

          {/* Card 3: Data Integration Made Easy */}
          <div className="quantix-card rounded-2xl sm:rounded-3xl p-6 flex flex-col justify-between overflow-hidden relative group">
            {/* Diagonal sheen reflection */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/[0.04] to-transparent pointer-events-none" />

            {/* Illustration: Jagged line chart with glowing peak dot */}
            <div className="h-44 sm:h-48 relative flex items-end justify-center mb-6 px-2">
              {/* Radial glow */}
              <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-32 h-24 bg-[#8B5CF6]/25 rounded-full blur-2xl" />

              <svg className="w-full h-36 overflow-visible" viewBox="0 0 200 120" fill="none">
                <defs>
                  <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#8B5CF6" stopOpacity="0.45" />
                    <stop offset="100%" stopColor="#1E0B38" stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                {/* Background area fill */}
                <path
                  d="M 10 110 L 10 90 L 30 90 L 45 75 L 55 85 L 75 70 L 90 95 L 105 50 L 115 65 L 130 25 L 145 45 L 160 35 L 180 50 L 195 55 L 195 110 Z"
                  fill="url(#areaGrad)"
                />

                {/* Jagged stroke line */}
                <path
                  d="M 10 90 L 30 90 L 45 75 L 55 85 L 75 70 L 90 95 L 105 50 L 115 65 L 130 25 L 145 45 L 160 35 L 180 50 L 195 55"
                  stroke="#A855F7"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />

                {/* Peak glowing beacon indicator */}
                <line x1="130" y1="25" x2="130" y2="110" stroke="#A855F7" strokeWidth="1" strokeDasharray="3 3" strokeOpacity="0.5" />
                <circle cx="130" cy="25" r="4.5" fill="#FFFFFF" className="shadow-[0_0_12px_#FFFFFF]" />
                <circle cx="130" cy="25" r="8" stroke="#A855F7" strokeWidth="1.5" strokeOpacity="0.8" />
              </svg>
            </div>

            {/* Content */}
            <div className="relative z-10">
              <h3 className="text-base sm:text-lg font-bold text-white tracking-tight mb-1.5">
                Data Integration Made Easy
              </h3>
              <p className="text-xs text-[#9D96B8] leading-relaxed">
                Easily connect your credit cards, loans, investments, and bank accounts.
              </p>
            </div>
          </div>
        </div>

        {/* ROW 2: 2 Wider Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Card 4: Intelligent Automation (Mic + Waveform) */}
          <div className="quantix-card rounded-2xl sm:rounded-3xl p-6 flex flex-col justify-between overflow-hidden relative group">
            {/* Diagonal sheen reflection */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/[0.04] to-transparent pointer-events-none" />

            {/* Illustration: Glowing Mic + Horizontal Audio Waveform */}
            <div className="h-44 sm:h-52 relative flex items-center justify-center mb-6">
              {/* Radial glow */}
              <div className="absolute w-40 h-32 bg-[#8B5CF6]/30 rounded-full blur-3xl" />

              {/* Waveform Bars Left */}
              <div className="flex items-center gap-1.5 mr-5">
                {[12, 18, 28, 16, 38, 22, 48, 30, 20, 10].map((h, i) => (
                  <div
                    key={i}
                    style={{ height: `${h}px` }}
                    className="w-[2.5px] rounded-full bg-gradient-to-t from-purple-800 to-purple-400 opacity-60"
                  />
                ))}
              </div>

              {/* Center Mic Glowing Orb */}
              <div className="relative z-10 w-14 h-14 rounded-full bg-gradient-to-br from-[#8B5CF6] via-[#7C3AED] to-[#5B21B6] flex items-center justify-center text-white shadow-[0_0_28px_rgba(168,85,247,0.8)] border border-purple-300/40">
                <Mic size={24} className="stroke-[2.2]" />
              </div>

              {/* Waveform Bars Right */}
              <div className="flex items-center gap-1.5 ml-5">
                {[10, 20, 30, 48, 22, 38, 16, 28, 18, 12].map((h, i) => (
                  <div
                    key={i}
                    style={{ height: `${h}px` }}
                    className="w-[2.5px] rounded-full bg-gradient-to-t from-purple-800 to-purple-400 opacity-60"
                  />
                ))}
              </div>
            </div>

            {/* Content */}
            <div className="relative z-10">
              <h3 className="text-base sm:text-lg font-bold text-white tracking-tight mb-1.5">
                Intelligent Automation
              </h3>
              <p className="text-xs text-[#9D96B8] leading-relaxed max-w-md">
                Harnessing AI to create workflows that simplify tasks and boost productivity.
              </p>
            </div>
          </div>

          {/* Card 5: Data Visualization (Monthly Bar Chart with Highlighted October) */}
          <div className="quantix-card rounded-2xl sm:rounded-3xl p-6 flex flex-col justify-between overflow-hidden relative group">
            {/* Diagonal sheen reflection */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/[0.04] to-transparent pointer-events-none" />

            {/* Illustration: 7 Monthly Bars */}
            <div className="h-44 sm:h-52 relative flex items-end justify-center mb-6 pb-2">
              {/* Radial glow */}
              <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-44 h-28 bg-[#8B5CF6]/25 rounded-full blur-3xl" />

              <div className="w-full max-w-sm flex items-end justify-between gap-2.5 h-36">
                {[
                  { month: 'June', h: 35 },
                  { month: 'July', h: 48 },
                  { month: 'August', h: 40 },
                  { month: 'September', h: 55 },
                  { month: 'October', h: 90, highlighted: true, tooltip: '+$3.41 USD' },
                  { month: 'November', h: 60 },
                  { month: 'December', h: 45 },
                ].map((item, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center justify-end h-full relative">
                    {/* Tooltip on October */}
                    {item.highlighted && (
                      <div className="absolute -top-7 flex flex-col items-center z-10">
                        <span className="px-2 py-0.5 rounded-full bg-[#1A0C33] border border-purple-400/40 text-[9px] font-mono text-white shadow-[0_0_10px_rgba(168,85,247,0.5)] whitespace-nowrap">
                          {item.tooltip}
                        </span>
                        <div className="w-1.5 h-1.5 rounded-full bg-white ring-2 ring-[#A855F7] mt-0.5" />
                      </div>
                    )}

                    {/* Bar */}
                    <div
                      style={{ height: `${item.h}%` }}
                      className={`w-full rounded-full transition-all ${
                        item.highlighted
                          ? 'bg-gradient-to-t from-[#7C3AED] via-[#8B5CF6] to-[#A855F7] shadow-[0_0_20px_rgba(168,85,247,0.7)]'
                          : 'bg-[#1C1033]/80'
                      }`}
                    />

                    {/* Month Label */}
                    <span className="text-[9px] text-[#7E7796] font-mono mt-2 truncate w-full text-center">
                      {item.month}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Content */}
            <div className="relative z-10">
              <h3 className="text-base sm:text-lg font-bold text-white tracking-tight mb-1.5">
                Data Visualization
              </h3>
              <p className="text-xs text-[#9D96B8] leading-relaxed max-w-md">
                Effortlessly visualize and organize complex datasets for clearer insights and quicker decisions.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Bottom CTA Button */}
      <div className="mt-14 flex justify-center">
        <button
          onClick={onExploreFeatures}
          className="btn-purple-primary flex items-center gap-2 px-7 py-3 rounded-full text-xs sm:text-sm font-semibold text-white tracking-wide shadow-[0_0_24px_rgba(124,58,237,0.5)] cursor-pointer"
        >
          <span>Explore Features</span>
          <ArrowRight size={14} className="stroke-[2.5]" />
        </button>
      </div>
    </section>
  );
};

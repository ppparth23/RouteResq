import React from 'react';

export const TrustedBrands: React.FC = () => {
  return (
    <section className="relative z-10 max-w-5xl mx-auto px-4 mt-20 sm:mt-28 text-center">
      {/* Subtitle */}
      <h3 className="text-xs sm:text-sm font-medium text-[#9D96B8] tracking-tight mb-8">
        Trusted by 10,000+ Teams Worldwide
      </h3>

      {/* Row of 6 Partner Logos */}
      <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10 md:gap-14 opacity-60 hover:opacity-85 transition-opacity">
        {/* Logo 1: Logoipsum with circle */}
        <div className="flex items-center gap-2 text-white">
          <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2.5" />
            <circle cx="12" cy="12" r="4" fill="currentColor" />
          </svg>
          <span className="font-bold text-sm tracking-tight">Logoipsum</span>
        </div>

        {/* Logo 2: Logoipsum with 4-petal */}
        <div className="flex items-center gap-2 text-white">
          <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
            <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" fill="currentColor" />
          </svg>
          <span className="font-bold text-sm tracking-tight">Logoipsum</span>
        </div>

        {/* Logo 3: IPSUM bold uppercase */}
        <div className="flex items-center gap-1.5 text-white">
          <span className="font-black text-base tracking-widest uppercase">IPSUM</span>
        </div>

        {/* Logo 4: logo ipsum with globe/grid */}
        <div className="flex items-center gap-2 text-white">
          <span className="font-bold text-sm">logo</span>
          <svg className="w-4 h-4 fill-none stroke-current" strokeWidth="2" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="9" />
            <line x1="3" y1="12" x2="21" y2="12" />
            <path d="M12 3a15 15 0 0 1 0 18" />
            <path d="M12 3a15 15 0 0 0 0 18" />
          </svg>
          <span className="font-bold text-sm">ipsum</span>
        </div>

        {/* Logo 5: LOQO / LOGO stylized */}
        <div className="flex items-center text-white">
          <span className="font-black text-base tracking-wider uppercase font-mono">LOQO</span>
        </div>

        {/* Logo 6: Logoipsum with hexagon */}
        <div className="flex items-center gap-2 text-white">
          <svg className="w-5 h-5 fill-none stroke-current" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M12 2L20 7V17L12 22L4 17V7L12 2Z" />
            <circle cx="12" cy="12" r="3" fill="currentColor" />
          </svg>
          <span className="font-bold text-sm tracking-tight">Logoipsum</span>
        </div>
      </div>
    </section>
  );
};

import React from 'react';
import { ArrowRight, Percent } from 'lucide-react';

interface HeroSectionProps {
  onStartTrial?: () => void;
  onBookDemo?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onStartTrial,
  onBookDemo,
}) => {
  return (
    <section id="home" className="relative pt-12 sm:pt-16 md:pt-20 pb-8 px-4 text-center overflow-hidden">
      {/* 1. Curved Glowing Purple Arc Over the Headline */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1200px] h-[550px] pointer-events-none select-none z-0">
        {/* Soft violet radial illumination */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[280px] bg-[#8B5CF6]/20 rounded-full blur-[100px]" />
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[350px] h-[180px] bg-[#A855F7]/30 rounded-full blur-[70px]" />

        {/* Perspective curved grid lines inside the dome */}
        <svg
          viewBox="0 0 1200 550"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full opacity-35"
        >
          {/* Curved latitude arcs */}
          <path d="M 100 480 C 350 160, 850 160, 1100 480" stroke="#A855F7" strokeWidth="1" strokeOpacity="0.3" strokeDasharray="4 4" />
          <path d="M 180 480 C 400 240, 800 240, 1020 480" stroke="#A855F7" strokeWidth="1" strokeOpacity="0.25" strokeDasharray="3 3" />
          <path d="M 280 480 C 450 320, 750 320, 920 480" stroke="#A855F7" strokeWidth="1" strokeOpacity="0.2" strokeDasharray="3 3" />
          {/* Vertical longitude rays */}
          <line x1="600" y1="120" x2="600" y2="480" stroke="#A855F7" strokeWidth="1" strokeOpacity="0.3" />
          <line x1="500" y1="135" x2="420" y2="480" stroke="#A855F7" strokeWidth="1" strokeOpacity="0.2" />
          <line x1="700" y1="135" x2="780" y2="480" stroke="#A855F7" strokeWidth="1" strokeOpacity="0.2" />
          <line x1="400" y1="170" x2="260" y2="480" stroke="#A855F7" strokeWidth="1" strokeOpacity="0.15" />
          <line x1="800" y1="170" x2="940" y2="480" stroke="#A855F7" strokeWidth="1" strokeOpacity="0.15" />
        </svg>

        {/* The prominent luminous glowing purple arch line */}
        <svg
          viewBox="0 0 1200 550"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="absolute inset-0 w-full h-full"
        >
          <defs>
            <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="8" result="blur1" />
              <feGaussianBlur stdDeviation="24" result="blur2" />
              <feMerge>
                <feMergeNode in="blur2" />
                <feMergeNode in="blur1" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
            <linearGradient id="archGradient" x1="0%" y1="100%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#8B5CF6" stopOpacity="0.05" />
              <stop offset="25%" stopColor="#A855F7" stopOpacity="0.8" />
              <stop offset="50%" stopColor="#FFFFFF" stopOpacity="1" />
              <stop offset="75%" stopColor="#A855F7" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#8B5CF6" stopOpacity="0.05" />
            </linearGradient>
          </defs>

          {/* Glowing Arch Path */}
          <path
            d="M 50 500 C 320 90, 880 90, 1150 500"
            stroke="url(#archGradient)"
            strokeWidth="2.5"
            filter="url(#glow)"
            className="opacity-95"
          />
        </svg>
      </div>

      {/* 2. Hero Content Container */}
      <div className="relative z-10 max-w-4xl mx-auto flex flex-col items-center">
        {/* Pill Badge: Optimize Your Workflow */}
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#180E2E]/80 border border-purple-400/30 text-xs text-[#E9D5FF] shadow-[0_0_20px_rgba(168,85,247,0.2)] mb-6 backdrop-blur-md">
          <span className="w-4 h-4 rounded-full bg-[#7C3AED]/40 flex items-center justify-center text-[10px] text-purple-200">
            %
          </span>
          <span className="font-medium tracking-tight text-slate-200">
            Optimize Your Workflow
          </span>
        </div>

        {/* Main Heading */}
        <h1 className="font-bold text-3xl sm:text-5xl md:text-6xl text-white tracking-tight leading-[1.12] max-w-3xl">
          Elevate Your Business Using <br className="hidden sm:inline" />
          AI-Driven Automation
        </h1>

        {/* Supporting Paragraph */}
        <p className="mt-4 text-xs sm:text-sm md:text-base text-[#9D96B8] max-w-xl leading-relaxed">
          An innovative software platform that simplifies your tasks, enhances efficiency,
          and helps your business grow seamlessly.
        </p>

        {/* Action Buttons */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3.5">
          <button
            onClick={onStartTrial}
            className="btn-purple-primary flex items-center gap-2 px-6 py-2.5 rounded-full text-xs sm:text-sm font-semibold text-white cursor-pointer"
          >
            <span>Start Free Trial</span>
            <ArrowRight size={14} className="stroke-[2.5]" />
          </button>

          <button
            onClick={onBookDemo}
            className="flex items-center gap-2 px-6 py-2.5 rounded-full text-xs sm:text-sm font-semibold text-white bg-[#130B24]/70 hover:bg-[#1C1033] border border-purple-400/25 hover:border-purple-400/40 transition-all backdrop-blur-md cursor-pointer"
          >
            <span>Book a Demo</span>
            <ArrowRight size={14} className="stroke-[2.5] text-[#C4B5FD]" />
          </button>
        </div>
      </div>
    </section>
  );
};

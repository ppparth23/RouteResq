import React from 'react';

interface QuantixLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const QuantixLogo: React.FC<QuantixLogoProps> = ({ className = '', size = 'md' }) => {
  const iconDimensions = {
    sm: 'w-6 h-6',
    md: 'w-7 h-7',
    lg: 'w-8 h-8',
  };

  const textDimensions = {
    sm: 'text-base',
    md: 'text-lg',
    lg: 'text-xl',
  };

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Purple circular icon with 4-petal white clover symbol matching reference */}
      <div
        className={`${iconDimensions[size]} rounded-full bg-[#7C3AED] flex items-center justify-center shrink-0 shadow-[0_0_12px_rgba(124,58,237,0.6)]`}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-4 h-4 text-white"
        >
          {/* Four rounded petals meeting in the center */}
          <ellipse cx="8.5" cy="8.5" rx="3" ry="3.5" transform="rotate(-30 8.5 8.5)" fill="currentColor" />
          <ellipse cx="15.5" cy="8.5" rx="3" ry="3.5" transform="rotate(30 15.5 8.5)" fill="currentColor" />
          <ellipse cx="8.5" cy="15.5" rx="3" ry="3.5" transform="rotate(30 8.5 15.5)" fill="currentColor" />
          <ellipse cx="15.5" cy="15.5" rx="3" ry="3.5" transform="rotate(-30 15.5 15.5)" fill="currentColor" />
        </svg>
      </div>
      <span className={`font-bold tracking-tight text-white ${textDimensions[size]}`}>
        Quantix
      </span>
    </div>
  );
};

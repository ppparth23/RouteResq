import React, { useState } from 'react';
import {
  Search,
  Bell,
  Hexagon,
  Home,
  CreditCard,
  BarChart3,
  ArrowRight,
  Wifi,
} from 'lucide-react';

export const DashboardPreview: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState('All');
  const [hoveredBarIndex, setHoveredBarIndex] = useState(4); // Default 5th bar active

  const filterTabs = ['All', 'Withdrawal', 'Savings', 'Deposit'];

  const chartBars = [
    { height: 42, label: 'Mon' },
    { height: 60, label: 'Tue' },
    { height: 35, label: 'Wed' },
    { height: 50, label: 'Thu' },
    { height: 86, label: 'Fri', isHighlighted: true, tooltip: '+$32.45' },
    { height: 58, label: 'Sat' },
    { height: 38, label: 'Sun' },
  ];

  return (
    <section className="relative z-10 max-w-5xl mx-auto px-4 mt-8 sm:mt-12">
      {/* Intense purple ambient glow radiating behind dashboard */}
      <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-4/5 h-36 bg-[#8B5CF6]/30 rounded-full blur-[90px] pointer-events-none" />

      {/* Main Dashboard Window Card */}
      <div className="quantix-dashboard-panel rounded-2xl sm:rounded-3xl p-3 sm:p-5 border border-purple-500/30 overflow-hidden relative">
        {/* Subtle top edge specular highlight */}
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-purple-300/40 to-transparent pointer-events-none" />

        {/* 1. Dashboard Top Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 mb-4 border-b border-white/[0.08]">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-[#7C3AED] flex items-center justify-center shrink-0">
              <svg viewBox="0 0 24 24" fill="none" className="w-3 h-3 text-white">
                <ellipse cx="8.5" cy="8.5" rx="3" ry="3.5" transform="rotate(-30 8.5 8.5)" fill="currentColor" />
                <ellipse cx="15.5" cy="8.5" rx="3" ry="3.5" transform="rotate(30 15.5 8.5)" fill="currentColor" />
                <ellipse cx="8.5" cy="15.5" rx="3" ry="3.5" transform="rotate(30 8.5 15.5)" fill="currentColor" />
                <ellipse cx="15.5" cy="15.5" rx="3" ry="3.5" transform="rotate(-30 15.5 15.5)" fill="currentColor" />
              </svg>
            </div>
            <span className="font-semibold text-xs sm:text-sm text-white tracking-tight">
              Quantix
            </span>
          </div>

          {/* Search bar */}
          <div className="relative flex-1 max-w-xs mx-2 hidden sm:block">
            <Search size={13} className="absolute left-3 top-2.5 text-[#9D96B8]" />
            <input
              type="text"
              readOnly
              value=""
              placeholder="Search bar"
              className="w-full pl-8 pr-3 py-1.5 rounded-full bg-[#180E2E]/80 border border-white/10 text-xs text-white placeholder-[#7B7494] outline-none"
            />
          </div>

          {/* Right User Lockup */}
          <div className="flex items-center gap-3">
            <button className="text-[#9D96B8] hover:text-white transition-colors" aria-label="Notifications">
              <Bell size={15} />
            </button>
            <button className="text-[#9D96B8] hover:text-white transition-colors" aria-label="Settings">
              <Hexagon size={15} />
            </button>

            <div className="flex items-center gap-2 pl-2 border-l border-white/10">
              <span className="text-xs font-medium text-slate-200">Hi Devid!</span>
              <div className="w-7 h-7 rounded-full overflow-hidden border border-purple-400/40 bg-purple-900/50">
                <img
                  src="/src/assets/images/security_engineer_avatar_1793477459287.jpg"
                  alt="Devid"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>

        {/* 2. Dashboard Body Grid */}
        <div className="flex gap-4">
          {/* Left Icon Rail */}
          <div className="hidden sm:flex flex-col items-center gap-3 pt-2 pr-3 border-r border-white/[0.06] shrink-0">
            <button className="w-8 h-8 rounded-lg bg-[#7C3AED] flex items-center justify-center text-white shadow-[0_0_12px_rgba(124,58,237,0.5)]">
              <Home size={15} />
            </button>
            <button className="w-8 h-8 rounded-lg flex items-center justify-center text-[#7B7494] hover:text-white hover:bg-white/5 transition-colors">
              <CreditCard size={15} />
            </button>
            <button className="w-8 h-8 rounded-lg flex items-center justify-center text-[#7B7494] hover:text-white hover:bg-white/5 transition-colors">
              <BarChart3 size={15} />
            </button>
          </div>

          {/* Main Dashboard Area */}
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* Left 7 cols: My Dashboard + Bar Chart */}
            <div className="lg:col-span-7 space-y-4">
              {/* Title & Filter Tabs */}
              <div className="space-y-3">
                <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                  My Dashboard
                </h2>

                <div className="flex flex-wrap items-center gap-2">
                  {filterTabs.map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setActiveFilter(tab)}
                      className={`text-xs px-3.5 py-1 rounded-full transition-all cursor-pointer ${
                        activeFilter === tab
                          ? 'bg-[#7C3AED] text-white font-medium shadow-[0_0_10px_rgba(124,58,237,0.5)]'
                          : 'bg-[#150C28]/80 text-[#9D96B8] hover:text-white border border-white/[0.06]'
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
              </div>

              {/* Revenue Flow Chart Sub-card */}
              <div className="rounded-xl bg-[#120924]/80 border border-white/[0.08] p-4 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-200">Revenue Flow</span>
                  <a href="#view-all" className="text-[11px] text-[#A855F7] hover:underline flex items-center gap-0.5">
                    <span>View all</span>
                    <ArrowRight size={11} />
                  </a>
                </div>

                {/* Y-axis and Bars Grid */}
                <div className="flex items-end gap-3 pt-6 pb-2">
                  {/* Y-axis scale */}
                  <div className="flex flex-col justify-between h-36 text-[10px] text-[#6E6788] font-mono select-none pr-1">
                    <span>3.0k$</span>
                    <span>2.5k$</span>
                    <span>2.0k$</span>
                    <span>1.5k$</span>
                    <span>1.0k$</span>
                    <span>0.0$</span>
                  </div>

                  {/* 7 Vertical Bar Columns */}
                  <div className="flex-1 flex items-end justify-between gap-1.5 sm:gap-2.5 h-36 border-b border-white/[0.06] pb-1 px-1">
                    {chartBars.map((bar, idx) => {
                      const isHighlighted = idx === hoveredBarIndex;

                      return (
                        <div
                          key={idx}
                          onMouseEnter={() => setHoveredBarIndex(idx)}
                          className="flex-1 flex flex-col items-center justify-end h-full relative group cursor-pointer"
                        >
                          {/* Tooltip on Highlighted Bar */}
                          {isHighlighted && (
                            <div className="absolute -top-7 z-20 flex flex-col items-center animate-fade-in pointer-events-none">
                              <span className="px-2 py-0.5 rounded-full bg-[#180C30] border border-[#A855F7]/40 text-[10px] font-mono font-bold text-white shadow-[0_0_10px_rgba(168,85,247,0.4)] whitespace-nowrap">
                                {bar.tooltip || '+$28.00'}
                              </span>
                              <div className="w-1.5 h-1.5 rounded-full bg-white ring-2 ring-[#A855F7] mt-0.5" />
                            </div>
                          )}

                          {/* The Vertical Bar */}
                          <div
                            style={{ height: `${bar.height}%` }}
                            className={`w-full max-w-[28px] rounded-full transition-all duration-300 ${
                              isHighlighted
                                ? 'bg-gradient-to-t from-[#7C3AED] via-[#8B5CF6] to-[#A855F7] shadow-[0_0_16px_rgba(168,85,247,0.7)]'
                                : 'bg-[#1F133A]/80 hover:bg-[#2B1B4F]'
                            }`}
                          />
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>

            {/* Right 5 cols: Financial Card + Transactions */}
            <div className="lg:col-span-5 space-y-4">
              <div className="rounded-xl bg-[#120924]/80 border border-white/[0.08] p-4 space-y-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-200">Revenue Flow</span>
                  <a href="#view-all" className="text-[11px] text-[#A855F7] hover:underline flex items-center gap-0.5">
                    <span>View all</span>
                    <ArrowRight size={11} />
                  </a>
                </div>

                {/* Big balance figure */}
                <div>
                  <span className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                    $456000
                  </span>
                </div>

                {/* Illuminated Purple Payment Card */}
                <div className="relative rounded-xl p-4 overflow-hidden border border-purple-400/30 bg-gradient-to-br from-[#2D1656] via-[#1A0B36] to-[#120626] shadow-[0_8px_24px_rgba(124,58,237,0.25)]">
                  {/* Glowing light sheen diagonal */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-purple-400/10 to-transparent pointer-events-none" />

                  <div className="relative z-10 flex flex-col justify-between h-20">
                    <div className="flex items-center justify-end">
                      <Wifi size={16} className="text-purple-300 rotate-90" />
                    </div>

                    <div>
                      <div className="font-mono text-xs text-purple-100 tracking-widest">
                        4500 1212 0202 1894
                      </div>
                      <div className="text-[10px] font-mono text-purple-300/80 mt-0.5">
                        06/24
                      </div>
                    </div>
                  </div>
                </div>

                {/* Transactions Section */}
                <div className="pt-2 border-t border-white/[0.06] space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-300">Transactions</span>
                    <a href="#view-all" className="text-[11px] text-[#A855F7] hover:underline flex items-center gap-0.5">
                      <span>View all</span>
                      <ArrowRight size={11} />
                    </a>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-purple-700/60 overflow-hidden border border-purple-400/30">
                        <img
                          src="/src/assets/images/security_engineer_avatar_1793477459287.jpg"
                          alt="herislody"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <span className="text-[#9D96B8] font-mono text-[11px]">@herislody</span>
                    </div>

                    <span className="font-semibold text-white font-mono text-xs">
                      -$1400
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

import React, { useState } from 'react';
import {
  GitBranch,
  Calendar,
  Clock,
  ArrowRight,
  Download,
  Search,
} from 'lucide-react';
import { MOCK_RECENT_SCANS, ScanRecord } from '../data/mockData';
import { NavigationTab } from './Sidebar';

interface ScanHistoryViewProps {
  onNavigate: (tab: NavigationTab) => void;
  onSelectScan: (scan: ScanRecord) => void;
  selectedScan: ScanRecord | null;
  onTriggerScanModal: () => void;
}

export const ScanHistoryView: React.FC<ScanHistoryViewProps> = ({
  onNavigate,
  onSelectScan,
  onTriggerScanModal,
}) => {
  const [filterLang, setFilterLang] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [downloadedId, setDownloadedId] = useState<string | null>(null);

  const filteredScans = MOCK_RECENT_SCANS.filter((scan) => {
    const matchesSearch =
      scan.repoName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scan.branch.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scan.commitHash.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesLang = filterLang === 'All' || scan.language === filterLang;

    return matchesSearch && matchesLang;
  });

  const handleDownloadSarif = (scanId: string) => {
    setDownloadedId(scanId);
    setTimeout(() => setDownloadedId(null), 2000);
  };

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2.5 mb-1.5">
            <h1 className="text-2xl font-display font-bold text-white tracking-tight">
              Scan History & Audit Records
            </h1>
            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#F59E0B]/10 text-[#FBBF24] border border-[#F59E0B]/20 font-medium">
              DEMO DATA
            </span>
          </div>
          <p className="text-xs text-slate-300 mt-1">
            Historical archive of all AST static scans, commit revisions, and discovered vulnerability differentials.
          </p>
        </div>

        <button
          onClick={onTriggerScanModal}
          className="btn-primary-pill text-xs font-bold text-[#070E1B] flex items-center gap-1.5 py-2 px-5"
        >
          <span>+ Start New Scan</span>
        </button>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search size={14} className="absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search repository, branch, or commit hash..."
            className="w-full pl-9 pr-4 py-2.5 rounded-full bg-[#0A162B] border border-white/10 text-xs text-slate-100 placeholder-slate-500 outline-none focus:border-[#38BDF8] transition-colors"
          />
        </div>

        {/* Language Tabs */}
        <div className="flex items-center gap-1 p-1 rounded-full bg-[#0A162B] border border-white/10 text-xs font-mono">
          {['All', 'TypeScript', 'Go', 'Rust', 'Python'].map((lang) => (
            <button
              key={lang}
              onClick={() => setFilterLang(lang)}
              className={`px-3.5 py-1.5 rounded-full transition-all whitespace-nowrap btn-press ${
                filterLang === lang
                  ? 'bg-[#122444] text-[#38BDF8] font-bold border border-[#38BDF8]/40 shadow-sm shadow-[#2563EB]/15'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {lang}
            </button>
          ))}
        </div>
      </div>

      {/* Scans List */}
      <div className="space-y-3.5">
        {filteredScans.map((scan) => (
          <div
            key={scan.id}
            className="rounded-2xl glass-card p-5 border border-white/10 hover:border-white/20 transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-4 shadow-lg"
          >
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-mono text-slate-400 font-semibold">
                  {scan.id}
                </span>
                <span className="text-base font-semibold text-white tracking-tight">
                  {scan.repoName}
                </span>
                <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-slate-300">
                  {scan.language}
                </span>
                <span
                  className={`text-xs font-mono px-2.5 py-0.5 rounded-full font-bold ${
                    scan.highestSeverity === 'Critical'
                      ? 'text-[#F87171] bg-[#F87171]/10 border border-[#F87171]/25'
                      : 'text-[#FBBF24] bg-[#FBBF24]/10 border border-[#FBBF24]/25'
                  }`}
                >
                  Highest: {scan.highestSeverity}
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400">
                <span className="flex items-center gap-1.5 text-slate-200">
                  <GitBranch size={13} className="text-[#38BDF8]" />
                  {scan.branch} · {scan.commitHash}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar size={13} />
                  {scan.timestamp}
                </span>
                <span className="flex items-center gap-1">
                  <Clock size={13} />
                  Duration: {scan.duration}
                </span>
                <span className="tabular-nums">
                  {scan.linesScanned.toLocaleString()} Lines of Code Analyzed
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => handleDownloadSarif(scan.id)}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#0A162B] hover:bg-white/10 border border-white/10 text-xs font-mono text-slate-200 transition-colors btn-press"
              >
                <Download size={13} className="text-slate-400" />
                <span>{downloadedId === scan.id ? 'Exported SARIF' : 'SARIF Export'}</span>
              </button>

              <button
                onClick={() => {
                  onSelectScan(scan);
                  onNavigate('vulnerabilities');
                }}
                className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-[#122444] hover:bg-[#1A325E] border border-[#38BDF8]/30 text-xs font-mono font-semibold text-[#38BDF8] transition-colors btn-press shadow-sm"
              >
                <span>View {scan.findingsCount} Findings</span>
                <ArrowRight size={13} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

import React, { useState, useEffect, useRef } from 'react';
import {
  ScanSearch,
  GitBranch,
  FileCode,
  UploadCloud,
  FileText,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Terminal,
  Cpu,
  ArrowRight,
  Flame,
  Check,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  ShieldCheck,
  Code2,
  Sliders,
  Sparkles,
  Info,
  Trash2,
  RefreshCw,
} from 'lucide-react';
import { MOCK_REPOSITORIES, Vulnerability, MOCK_VULNERABILITIES } from '../data/mockData';
import { NavigationTab } from './Sidebar';

interface NewScanViewProps {
  onNavigate: (tab: NavigationTab) => void;
  onSelectVulnerability: (vulnId: string) => void;
}

type ScanMode = 'repository' | 'source_code' | 'scan_report';
type ScanProfile = 'quick' | 'standard' | 'deep';
type ProgressState = 'idle' | 'validating' | 'submitting' | 'scanning' | 'completed' | 'failed';

const SAMPLE_VULNERABLE_SNIPPETS = {
  sqli: {
    language: 'TypeScript',
    filename: 'orderController.ts',
    name: 'CWE-89: SQL Injection',
    code: `export async function getCustomerOrderHistory(req: Request, res: Response) {
  const customerId = req.query.customerId as string;
  const status = req.query.status as string || 'ACTIVE';

  // VULNERABLE: Direct string interpolation into raw query without parameterized bindings
  const query = \`
    SELECT id, total_amount, currency, created_at, status
    FROM customer_orders
    WHERE customer_id = '\${customerId}'
      AND order_status = '\${status}'
    ORDER BY created_at DESC
  \`;

  const results = await db.raw(query);
  return res.json({ orders: results.rows });
}`,
  },
  ssrf: {
    language: 'Go',
    filename: 'dispatcher.go',
    name: 'CWE-918: Blind SSRF',
    code: `package webhook

import (
    "bytes"
    "context"
    "net/http"
    "time"
)

func DispatchWebhook(ctx context.Context, targetURL string, payload []byte) (*http.Response, error) {
    // VULNERABLE: Direct outbound request without IP restriction or private IP blocking
    req, err := http.NewRequestWithContext(ctx, "POST", targetURL, bytes.NewReader(payload))
    if err != nil {
        return nil, err
    }
    req.Header.Set("Content-Type", "application/json")

    client := &http.Client{Timeout: 10 * time.Second}
    return client.Do(req)
}`,
  },
  proto: {
    language: 'TypeScript',
    filename: 'configMerge.ts',
    name: 'CWE-1321: Prototype Pollution',
    code: `export function mergeDeep(target: any, source: any): any {
  // VULNERABLE: Missing __proto__, constructor, and prototype keys filter
  for (const key of Object.keys(source)) {
    if (source[key] instanceof Object && key in target) {
      Object.assign(source[key], mergeDeep(target[key], source[key]));
    }
  }
  Object.assign(target || {}, source);
  return target;
}`,
  },
  deserial: {
    language: 'Python',
    filename: 'cache_consumer.py',
    name: 'CWE-502: Insecure Deserialization',
    code: `import pickle
import redis

def process_cached_session(redis_client, queue_key):
    # VULNERABLE: Direct pickle deserialization of untrusted redis queue payload
    payload = redis_client.rpop(queue_key)
    if payload:
        session_data = pickle.loads(payload)
        return session_data
    return None`,
  },
};

const SAMPLE_SARIF_REPORT = JSON.stringify(
  {
    $schema: 'https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json',
    version: '2.1.0',
    runs: [
      {
        tool: {
          driver: {
            name: 'VULNEX-AST-Engine',
            version: '2.4.0',
            rules: [
              { id: 'CWE-89', name: 'SQL Injection', defaultConfiguration: { level: 'error' } },
              { id: 'CWE-918', name: 'Server-Side Request Forgery', defaultConfiguration: { level: 'error' } },
            ],
          },
        },
        results: [
          {
            ruleId: 'CWE-89',
            message: { text: 'Tainted input reaches SQL query sink without parameterized bindings.' },
            locations: [{ physicalLocation: { artifactLocation: { uri: 'src/controllers/orderController.ts' }, region: { startLine: 42 } } }],
          },
          {
            ruleId: 'CWE-918',
            message: { text: 'Unvalidated webhook outbound URL permits access to internal metadata IP.' },
            locations: [{ physicalLocation: { artifactLocation: { uri: 'pkg/webhook/dispatcher.go' }, region: { startLine: 88 } } }],
          },
        ],
      },
    ],
  },
  null,
  2
);

export const NewScanView: React.FC<NewScanViewProps> = ({
  onNavigate,
  onSelectVulnerability,
}) => {
  // Mode selection
  const [scanMode, setScanMode] = useState<ScanMode>('repository');

  // Repository Mode State
  const [repoUrl, setRepoUrl] = useState('https://github.com/acme-secops/checkout-service-api');
  const [branch, setBranch] = useState('main');
  const [repoLanguage, setRepoLanguage] = useState('TypeScript / JavaScript');
  const [repoUrlError, setRepoUrlError] = useState<string | null>(null);

  // Source Code Mode State
  const [codeLanguage, setCodeLanguage] = useState('TypeScript');
  const [codeFilename, setCodeFilename] = useState('orderController.ts');
  const [sourceCode, setSourceCode] = useState(SAMPLE_VULNERABLE_SNIPPETS.sqli.code);
  const [codeError, setCodeError] = useState<string | null>(null);

  // Scan Report Mode State
  const [reportFileName, setReportFileName] = useState<string>('sarif_report_sample.json');
  const [reportContent, setReportContent] = useState<string>(SAMPLE_SARIF_REPORT);
  const [reportError, setReportError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Scan Profile
  const [scanProfile, setScanProfile] = useState<ScanProfile>('standard');

  // Collapsible Advanced Options
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [severityThreshold, setSeverityThreshold] = useState('All');
  const [includeDependencies, setIncludeDependencies] = useState(true);
  const [includeSecrets, setIncludeSecrets] = useState(true);
  const [includeIaC, setIncludeIaC] = useState(false);
  const [categoryInjection, setCategoryInjection] = useState(true);
  const [categoryNetwork, setCategoryNetwork] = useState(true);
  const [categoryAuth, setCategoryAuth] = useState(true);

  // Execution & Progress State
  const [progressState, setProgressState] = useState<ProgressState>('idle');
  const [scanPhase, setScanPhase] = useState<number>(0);
  const [scanProgress, setScanProgress] = useState(0);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([]);
  const [discoveredFindings, setDiscoveredFindings] = useState<Vulnerability[]>([]);
  const [generalError, setGeneralError] = useState<string | null>(null);

  const phases = [
    { id: 1, title: 'AST Parsing & Syntax Tree Generation', desc: 'Parsing source files into semantic syntax trees' },
    { id: 2, title: 'Inter-procedural Taint Flow Tracking', desc: 'Tracing user-controlled sources to sensitive sinks' },
    { id: 3, title: 'SMT Exploit Reachability Solver', desc: 'Proving path satisfiability and constraint divergence' },
    { id: 4, title: 'Neural-Symbolic Patch Synthesis', desc: 'Constructing formal invariant code transformations' },
  ];

  // Helper validation for Git URLs
  const validateRepoUrl = (url: string): boolean => {
    const trimmed = url.trim();
    if (!trimmed) {
      setRepoUrlError('Repository URL is required.');
      return false;
    }
    // Accept HTTPS / Git protocol standard formats
    const gitUrlRegex = /^(https:\/\/|git@|http:\/\/)([a-zA-Z0-9._-]+)(:[0-9]+)?[\/:]([a-zA-Z0-9._-]+)\/([a-zA-Z0-9._-]+?)(\.git)?(\/)?$/;
    if (!gitUrlRegex.test(trimmed)) {
      setRepoUrlError('Please enter a valid Git URL (e.g. https://github.com/org/repo or git@github.com:org/repo.git).');
      return false;
    }
    setRepoUrlError(null);
    return true;
  };

  const handleRepoUrlChange = (value: string) => {
    setRepoUrl(value);
    if (repoUrlError) {
      validateRepoUrl(value);
    }
  };

  // Quick repository selector presets
  const handleSelectPresetRepo = (presetUrl: string, lang: string) => {
    setRepoUrl(presetUrl);
    setRepoLanguage(lang);
    setRepoUrlError(null);
  };

  // Example Vulnerable Code Loader
  const handleLoadSnippet = (key: keyof typeof SAMPLE_VULNERABLE_SNIPPETS) => {
    const snippet = SAMPLE_VULNERABLE_SNIPPETS[key];
    setSourceCode(snippet.code);
    setCodeLanguage(snippet.language);
    setCodeFilename(snippet.filename);
    setCodeError(null);
  };

  // File Upload for Scan Report Mode
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.json') && !file.name.endsWith('.sarif')) {
      setReportError('Unsupported file format. Please select a .json or .sarif report file.');
      return;
    }

    setReportError(null);
    setReportFileName(file.name);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        JSON.parse(text); // validate JSON syntax
        setReportContent(text);
      } catch (err) {
        setReportError('The uploaded file does not contain valid JSON formatting.');
      }
    };
    reader.readAsText(file);
  };

  // Clear source code
  const handleClearCode = () => {
    setSourceCode('');
    setCodeError(null);
  };

  // Main Submit Handler
  const handleStartScan = () => {
    setGeneralError(null);

    // 1. Validation phase
    if (scanMode === 'repository') {
      if (!validateRepoUrl(repoUrl)) return;
    } else if (scanMode === 'source_code') {
      if (!sourceCode.trim()) {
        setCodeError('Source code cannot be empty. Paste code or load an example vulnerability.');
        return;
      }
      setCodeError(null);
    } else if (scanMode === 'scan_report') {
      if (!reportContent.trim()) {
        setReportError('Report content is empty. Please upload or load a valid SARIF JSON report.');
        return;
      }
      setReportError(null);
    }

    // 2. Set progress state
    setProgressState('validating');
    setScanProgress(5);
    setDiscoveredFindings([]);

    const targetLabel =
      scanMode === 'repository'
        ? `repo: ${repoUrl} (${branch})`
        : scanMode === 'source_code'
        ? `file: ${codeFilename} (${codeLanguage})`
        : `report: ${reportFileName}`;

    setTerminalLogs([
      `[00:00.01] Validating scan target ${targetLabel}...`,
      `[00:00.04] Target validated. Profile: ${scanProfile.toUpperCase()} · Ruleset: OWASP-2026-STRICT`,
    ]);

    setTimeout(() => {
      setProgressState('submitting');
      setScanProgress(15);
      setTerminalLogs((prev) => [
        ...prev,
        `[00:00.12] Dispatching job to AST Ephemeral Sandbox...`,
        `[00:00.18] Container initialized. Beginning lexical tokenization.`,
      ]);
    }, 600);

    setTimeout(() => {
      setProgressState('scanning');
      setScanPhase(1);
      setScanProgress(30);
      setTerminalLogs((prev) => [
        ...prev,
        `[00:01.05] Phase 1: AST parsing and call-graph construction complete.`,
        `[00:01.40] Phase 2: Inter-procedural taint flow analysis starting...`,
      ]);
    }, 1400);

    setTimeout(() => {
      setScanPhase(2);
      setScanProgress(55);
      const isSqlMatching = sourceCode.includes('customerId') || scanMode === 'repository';
      setTerminalLogs((prev) => [
        ...prev,
        `[00:02.10] Taint flow tracking active: analyzing sources and sinks...`,
        `[00:02.45] SINK DETECTED: Untrusted input reaches execution sink without parameterized guard.`,
      ]);
      setDiscoveredFindings([MOCK_VULNERABILITIES[0]]);
    }, 2800);

    setTimeout(() => {
      setScanPhase(3);
      setScanProgress(80);
      setTerminalLogs((prev) => [
        ...prev,
        `[00:03.20] Phase 3: SMT Constraint Solver (Z3 theorem prover) engaged.`,
        `[00:03.55] Path satisfiability proved: Exploit reachability confirmed with tautology vector.`,
        `[00:03.80] Discovered secondary candidate: Blind SSRF in notification dispatcher.`,
      ]);
      setDiscoveredFindings([MOCK_VULNERABILITIES[0], MOCK_VULNERABILITIES[1]]);
    }, 4200);

    setTimeout(() => {
      setScanPhase(4);
      setScanProgress(95);
      setTerminalLogs((prev) => [
        ...prev,
        `[00:04.40] Phase 4: Neural-Symbolic patch synthesis generated formal invariant fix.`,
        `[00:04.75] Invariant verification passed: SQL statement query tokenizer edge severed.`,
      ]);
    }, 5400);

    setTimeout(() => {
      setProgressState('completed');
      setScanProgress(100);
      setTerminalLogs((prev) => [
        ...prev,
        `[00:05.10] Scan execution finished successfully! 2 critical findings identified with verifiable patches.`,
      ]);
    }, 6200);
  };

  const handleResetScan = () => {
    setProgressState('idle');
    setScanPhase(0);
    setScanProgress(0);
    setTerminalLogs([]);
    setDiscoveredFindings([]);
    setGeneralError(null);
  };

  // Character and line count calculations for code mode
  const codeLinesCount = sourceCode ? sourceCode.split('\n').length : 0;
  const codeCharsCount = sourceCode ? sourceCode.length : 0;

  // Primary action button label
  const primaryButtonLabel = {
    repository: 'Scan Repository',
    source_code: 'Analyze Source Code',
    scan_report: 'Ingest & Process Report',
  }[scanMode];

  return (
    <div className="space-y-7 animate-fade-in pb-12">
      {/* 1. PAGE HEADER */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2.5 mb-2">
            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#38BDF8]/10 text-[#38BDF8] border border-[#38BDF8]/25 font-semibold tracking-wider">
              SCAN CONFIGURATION
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#F59E0B]/10 text-[#FBBF24] border border-[#F59E0B]/20 font-medium">
              DEMO DATA
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-display font-bold text-white tracking-tight">
            Start a Security Scan
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-3xl leading-relaxed">
            Inspect source code or a repository to identify security weaknesses and prepare them for AI-assisted remediation.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {progressState !== 'idle' && (
            <button
              onClick={handleResetScan}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#0A162B] hover:bg-[#122444] border border-white/10 text-xs font-mono text-slate-200 transition-colors btn-press"
            >
              <RotateCcw size={13} />
              <span>Reset Configuration</span>
            </button>
          )}
        </div>
      </div>

      {/* 2. TWO-COLUMN WORKSPACE LAYOUT */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT COLUMN: Input Source & Scan Configuration (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          {/* Scan Source Segmented Selector */}
          <div className="rounded-2xl glass-card p-6 border border-white/10 space-y-5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-wider text-slate-300 font-semibold">
                1. Select Scan Target Source
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                Supported: Git, Raw Code, SARIF
              </span>
            </div>

            {/* Segmented 3-Way Tabs */}
            <div className="grid grid-cols-3 p-1.5 rounded-full bg-[#0A162B] border border-white/10 text-xs font-mono">
              <button
                type="button"
                onClick={() => {
                  setScanMode('repository');
                  handleResetScan();
                }}
                disabled={progressState === 'scanning' || progressState === 'validating'}
                className={`py-2 px-3 rounded-full transition-all flex items-center justify-center gap-2 btn-press ${
                  scanMode === 'repository'
                    ? 'bg-[#122444] text-[#38BDF8] font-bold border border-[#38BDF8]/40 shadow-md shadow-[#2563EB]/15'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <GitBranch size={14} />
                <span>Repository</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setScanMode('source_code');
                  handleResetScan();
                }}
                disabled={progressState === 'scanning' || progressState === 'validating'}
                className={`py-2 px-3 rounded-full transition-all flex items-center justify-center gap-2 btn-press ${
                  scanMode === 'source_code'
                    ? 'bg-[#122444] text-[#38BDF8] font-bold border border-[#38BDF8]/40 shadow-md shadow-[#2563EB]/15'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <Code2 size={14} />
                <span>Source Code</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setScanMode('scan_report');
                  handleResetScan();
                }}
                disabled={progressState === 'scanning' || progressState === 'validating'}
                className={`py-2 px-3 rounded-full transition-all flex items-center justify-center gap-2 btn-press ${
                  scanMode === 'scan_report'
                    ? 'bg-[#122444] text-[#38BDF8] font-bold border border-[#38BDF8]/40 shadow-md shadow-[#2563EB]/15'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <UploadCloud size={14} />
                <span>Scan Report</span>
              </button>
            </div>

            {/* A. REPOSITORY MODE PANEL */}
            {scanMode === 'repository' && (
              <div className="space-y-4 pt-1 animate-fade-in">
                <div>
                  <label className="text-[11px] font-mono uppercase tracking-wider text-slate-200 block mb-1.5 font-medium">
                    Git Repository URL <span className="text-[#F87171]">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={repoUrl}
                      onChange={(e) => handleRepoUrlChange(e.target.value)}
                      placeholder="https://github.com/org/repo.git or git@github.com:org/repo.git"
                      disabled={progressState === 'scanning' || progressState === 'validating'}
                      className={`w-full px-4 py-2.5 rounded-xl bg-[#0A162B] border text-xs font-mono text-slate-100 placeholder-slate-500 outline-none transition-colors ${
                        repoUrlError
                          ? 'border-[#F87171] focus:border-[#F87171] focus:ring-1 focus:ring-[#F87171]'
                          : 'border-white/10 focus:border-[#38BDF8]'
                      }`}
                    />
                  </div>
                  {repoUrlError && (
                    <div className="flex items-center gap-1.5 text-xs text-[#F87171] mt-1.5 font-mono">
                      <AlertCircle size={13} className="shrink-0" />
                      <span>{repoUrlError}</span>
                    </div>
                  )}

                  {/* Preset Quick Repositories */}
                  <div className="mt-2.5 flex flex-wrap items-center gap-2 text-[11px] font-mono text-slate-400">
                    <span>Sample targets:</span>
                    <button
                      type="button"
                      onClick={() => handleSelectPresetRepo('https://github.com/acme-secops/checkout-service-api', 'TypeScript / JavaScript')}
                      className="px-2.5 py-0.5 rounded-full bg-[#122444] hover:bg-[#1A325E] text-[#38BDF8] border border-[#38BDF8]/20 transition-colors"
                    >
                      checkout-service-api (TS)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSelectPresetRepo('https://github.com/acme-secops/auth-gateway-v2', 'Go')}
                      className="px-2.5 py-0.5 rounded-full bg-[#122444] hover:bg-[#1A325E] text-[#38BDF8] border border-[#38BDF8]/20 transition-colors"
                    >
                      auth-gateway-v2 (Go)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSelectPresetRepo('https://github.com/acme-secops/payment-vault', 'Rust')}
                      className="px-2.5 py-0.5 rounded-full bg-[#122444] hover:bg-[#1A325E] text-[#38BDF8] border border-[#38BDF8]/20 transition-colors"
                    >
                      payment-vault (Rust)
                    </button>
                  </div>
                </div>

                {/* Branch and Language Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="text-[11px] font-mono uppercase tracking-wider text-slate-200 block mb-1.5 font-medium">
                      Branch / Tag <span className="text-slate-400">(Optional)</span>
                    </label>
                    <div className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-[#0A162B] border border-white/10 font-mono text-xs text-slate-200">
                      <GitBranch size={14} className="text-[#38BDF8] shrink-0" />
                      <input
                        type="text"
                        value={branch}
                        onChange={(e) => setBranch(e.target.value)}
                        placeholder="e.g. main, staging, release/2.4"
                        disabled={progressState === 'scanning' || progressState === 'validating'}
                        className="bg-transparent w-full outline-none text-slate-100 font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-mono uppercase tracking-wider text-slate-200 block mb-1.5 font-medium">
                      Language Mode
                    </label>
                    <select
                      value={repoLanguage}
                      onChange={(e) => setRepoLanguage(e.target.value)}
                      disabled={progressState === 'scanning' || progressState === 'validating'}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A162B] border border-white/10 text-slate-100 text-xs font-mono outline-none focus:border-[#38BDF8] transition-colors"
                    >
                      <option value="Auto-detect">Auto-detect from repo manifests</option>
                      <option value="TypeScript / JavaScript">TypeScript / JavaScript</option>
                      <option value="Go">Go</option>
                      <option value="Python">Python</option>
                      <option value="Rust">Rust</option>
                      <option value="Java">Java</option>
                      <option value="C / C++">C / C++</option>
                    </select>
                  </div>
                </div>

                {/* Security notice */}
                <div className="p-3 rounded-xl bg-[#0A162B]/80 border border-white/10 text-xs text-slate-300 flex items-start gap-2.5">
                  <ShieldCheck size={16} className="text-[#10B981] shrink-0 mt-0.5" />
                  <p className="leading-relaxed text-[11px]">
                    Repository code is analyzed in an isolated sandbox and never executed directly in your browser. Personal access tokens or credentials are never exposed in frontend code.
                  </p>
                </div>
              </div>
            )}

            {/* B. SOURCE CODE MODE PANEL */}
            {scanMode === 'source_code' && (
              <div className="space-y-4 pt-1 animate-fade-in">
                {/* Language and Filename */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="text-[11px] font-mono uppercase tracking-wider text-slate-200 block mb-1.5 font-medium">
                      Language
                    </label>
                    <select
                      value={codeLanguage}
                      onChange={(e) => setCodeLanguage(e.target.value)}
                      disabled={progressState === 'scanning' || progressState === 'validating'}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A162B] border border-white/10 text-slate-100 text-xs font-mono outline-none focus:border-[#38BDF8] transition-colors"
                    >
                      <option value="TypeScript">TypeScript</option>
                      <option value="JavaScript">JavaScript</option>
                      <option value="Go">Go</option>
                      <option value="Python">Python</option>
                      <option value="Rust">Rust</option>
                      <option value="Java">Java</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-mono uppercase tracking-wider text-slate-200 block mb-1.5 font-medium">
                      Filename / Path
                    </label>
                    <input
                      type="text"
                      value={codeFilename}
                      onChange={(e) => setCodeFilename(e.target.value)}
                      placeholder="e.g. orderController.ts"
                      disabled={progressState === 'scanning' || progressState === 'validating'}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A162B] border border-white/10 text-slate-100 text-xs font-mono outline-none focus:border-[#38BDF8] transition-colors"
                    />
                  </div>
                </div>

                {/* Example vulnerability loader strip */}
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-mono">
                    <span className="text-slate-400">Load test flaw:</span>
                    <button
                      type="button"
                      onClick={() => handleLoadSnippet('sqli')}
                      className="px-2.5 py-0.5 rounded-full bg-[#38BDF8]/15 text-[#38BDF8] border border-[#38BDF8]/30 hover:bg-[#38BDF8]/25 transition-colors font-medium"
                    >
                      SQLi (CWE-89)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleLoadSnippet('ssrf')}
                      className="px-2.5 py-0.5 rounded-full bg-[#818CF8]/15 text-[#A5B4FC] border border-[#818CF8]/30 hover:bg-[#818CF8]/25 transition-colors font-medium"
                    >
                      SSRF (CWE-918)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleLoadSnippet('proto')}
                      className="px-2.5 py-0.5 rounded-full bg-white/5 text-slate-300 border border-white/10 hover:bg-white/10 transition-colors"
                    >
                      Proto Pollute (CWE-1321)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleLoadSnippet('deserial')}
                      className="px-2.5 py-0.5 rounded-full bg-white/5 text-slate-300 border border-white/10 hover:bg-white/10 transition-colors"
                    >
                      Pickle (CWE-502)
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={handleClearCode}
                    className="inline-flex items-center gap-1 text-[11px] font-mono text-slate-400 hover:text-[#F87171] transition-colors"
                  >
                    <Trash2 size={12} />
                    <span>Clear</span>
                  </button>
                </div>

                {/* Monospace Code Editor */}
                <div className="rounded-xl border border-white/10 bg-[#060D1A] overflow-hidden">
                  <div className="px-4 py-2 bg-[#091529] border-b border-white/10 flex items-center justify-between text-[11px] font-mono text-slate-400">
                    <div className="flex items-center gap-2">
                      <FileCode size={13} className="text-[#38BDF8]" />
                      <span className="text-slate-200">{codeFilename}</span>
                    </div>
                    <div className="flex items-center gap-3 tabular-nums">
                      <span>{codeLinesCount} lines</span>
                      <span>{codeCharsCount.toLocaleString()} chars</span>
                    </div>
                  </div>

                  <textarea
                    value={sourceCode}
                    onChange={(e) => {
                      setSourceCode(e.target.value);
                      if (codeError) setCodeError(null);
                    }}
                    disabled={progressState === 'scanning' || progressState === 'validating'}
                    rows={12}
                    placeholder="// Paste source code here for AST taint analysis..."
                    className="w-full p-4 bg-transparent text-xs font-mono text-slate-200 outline-none resize-y leading-relaxed font-normal selection:bg-[#38BDF8]/25"
                    spellCheck={false}
                  />
                </div>

                {codeError && (
                  <div className="flex items-center gap-1.5 text-xs text-[#F87171] font-mono">
                    <AlertCircle size={13} className="shrink-0" />
                    <span>{codeError}</span>
                  </div>
                )}

                {/* Confidentiality Warning Notice */}
                <div className="p-3 rounded-xl bg-[#0A162B]/80 border border-white/10 text-xs text-slate-300 flex items-start gap-2.5">
                  <Info size={15} className="text-[#FBBF24] shrink-0 mt-0.5" />
                  <p className="leading-relaxed text-[11px]">
                    Submitted code must <strong className="text-white">not contain secrets, private API keys, or confidential production credentials</strong>. Code analysis runs in ephemeral memory.
                  </p>
                </div>
              </div>
            )}

            {/* C. SCAN REPORT MODE PANEL */}
            {scanMode === 'scan_report' && (
              <div className="space-y-4 pt-1 animate-fade-in">
                <div>
                  <label className="text-[11px] font-mono uppercase tracking-wider text-slate-200 block mb-1.5 font-medium">
                    Upload Scanner Report (JSON / SARIF)
                  </label>
                  <p className="text-xs text-slate-300 mb-3 leading-relaxed">
                    Ingest existing results from Snyk, Semgrep, Trivy, or custom SARIF static analyzers to synthesize AST repair patches and verification tests.
                  </p>

                  {/* Dropzone */}
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="p-6 rounded-2xl border-2 border-dashed border-white/15 hover:border-[#38BDF8]/60 bg-[#0A162B]/60 hover:bg-[#0E203D]/60 transition-all text-center cursor-pointer group"
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".json,.sarif"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                    <UploadCloud size={32} className="mx-auto text-slate-400 group-hover:text-[#38BDF8] transition-colors mb-2" />
                    <span className="text-xs font-semibold text-white block">
                      Click to choose or drag & drop SARIF report file
                    </span>
                    <span className="text-[11px] font-mono text-slate-400 mt-1 block">
                      Supports SARIF v2.1.0 or VULNEX AST JSON schema (.json, .sarif)
                    </span>
                  </div>

                  {reportFileName && (
                    <div className="mt-3 p-3 rounded-xl bg-[#0A162B] border border-white/10 flex items-center justify-between text-xs font-mono">
                      <div className="flex items-center gap-2">
                        <FileText size={15} className="text-[#10B981]" />
                        <span className="text-slate-200 font-medium">{reportFileName}</span>
                        <span className="text-[10px] text-slate-400">({(reportContent.length / 1024).toFixed(1)} KB)</span>
                      </div>
                      <span className="text-[10px] text-[#10B981] bg-[#10B981]/10 px-2.5 py-0.5 rounded-full border border-[#10B981]/25 font-semibold">
                        Parsed 2 Findings
                      </span>
                    </div>
                  )}

                  {reportError && (
                    <div className="flex items-center gap-1.5 text-xs text-[#F87171] mt-2 font-mono">
                      <AlertCircle size={13} className="shrink-0" />
                      <span>{reportError}</span>
                    </div>
                  )}
                </div>

                {/* Honesty note */}
                <div className="p-3 rounded-xl bg-[#0A162B]/80 border border-white/10 text-xs text-slate-300 flex items-start gap-2.5">
                  <Info size={15} className="text-[#38BDF8] shrink-0 mt-0.5" />
                  <p className="leading-relaxed text-[11px]">
                    Ingesting a report processes existing finding records to generate code patches and regression proofs. It does not initiate a new AST scan of the remote repository.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* 3. SCAN PROFILE SELECTOR */}
          <div className="rounded-2xl glass-card p-6 border border-white/10 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-wider text-slate-300 font-semibold">
                2. Select Scan Profile
              </span>
              <span className="text-[10px] font-mono text-slate-300 bg-white/5 px-2 py-0.5 rounded-full border border-white/10">
                Simulation Engine
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Quick Scan */}
              <button
                type="button"
                onClick={() => setScanProfile('quick')}
                disabled={progressState === 'scanning' || progressState === 'validating'}
                className={`p-4 rounded-xl border text-left transition-all btn-press ${
                  scanProfile === 'quick'
                    ? 'bg-[#122444] border-[#38BDF8]/60 text-white shadow-md shadow-[#2563EB]/20'
                    : 'bg-[#0A162B]/70 border-white/10 text-slate-300 hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-display font-bold text-xs uppercase tracking-wider text-white">
                    Quick Scan
                  </span>
                  <span className="text-[10px] font-mono text-[#10B981] font-semibold">~15s</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-snug">
                  Fast AST syntax analysis for high-probability vulnerability signatures.
                </p>
              </button>

              {/* Standard Scan */}
              <button
                type="button"
                onClick={() => setScanProfile('standard')}
                disabled={progressState === 'scanning' || progressState === 'validating'}
                className={`p-4 rounded-xl border text-left transition-all btn-press ${
                  scanProfile === 'standard'
                    ? 'bg-[#122444] border-[#38BDF8]/60 text-white shadow-md shadow-[#2563EB]/20'
                    : 'bg-[#0A162B]/70 border-white/10 text-slate-300 hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-display font-bold text-xs uppercase tracking-wider text-white">
                    Standard Scan
                  </span>
                  <span className="text-[10px] font-mono text-[#38BDF8] font-semibold">~45s</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-snug">
                  Broader static taint propagation with cross-module call graph inspection.
                </p>
              </button>

              {/* Deep Analysis */}
              <button
                type="button"
                onClick={() => setScanProfile('deep')}
                disabled={progressState === 'scanning' || progressState === 'validating'}
                className={`p-4 rounded-xl border text-left transition-all btn-press ${
                  scanProfile === 'deep'
                    ? 'bg-[#122444] border-[#818CF8]/60 text-white shadow-md shadow-[#818CF8]/20'
                    : 'bg-[#0A162B]/70 border-white/10 text-slate-300 hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-display font-bold text-xs uppercase tracking-wider text-white">
                    Deep Analysis
                  </span>
                  <span className="text-[10px] font-mono text-[#A5B4FC] font-semibold">~2m</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-snug">
                  Full SMT constraint solving, symbolic execution, and automated patch synthesis.
                </p>
              </button>
            </div>

            <p className="text-[10px] font-mono text-slate-400">
              Note: Actual scan capabilities depend on backend connection. Currently running simulated depth stages.
            </p>
          </div>

          {/* 4. COLLAPSIBLE ADVANCED OPTIONS */}
          <div className="rounded-2xl glass-card border border-white/10 overflow-hidden">
            <button
              type="button"
              onClick={() => setAdvancedOpen(!advancedOpen)}
              className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-white/[0.02] transition-colors btn-press"
            >
              <div className="flex items-center gap-2">
                <Sliders size={16} className="text-[#38BDF8]" />
                <span className="text-xs font-semibold text-white">
                  Advanced Options & Analyzer Toggles
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#F59E0B]/10 text-[#FBBF24] border border-[#F59E0B]/20 font-medium">
                  DEMO PREVIEW
                </span>
              </div>
              {advancedOpen ? <ChevronUp size={16} className="text-slate-400" /> : <ChevronDown size={16} className="text-slate-400" />}
            </button>

            {advancedOpen && (
              <div className="p-6 pt-2 border-t border-white/10 space-y-4 text-xs animate-fade-in">
                {/* Severity threshold */}
                <div>
                  <label className="text-[10px] font-mono uppercase tracking-wider text-slate-300 block mb-1 font-semibold">
                    Minimum Severity Threshold
                  </label>
                  <select
                    value={severityThreshold}
                    onChange={(e) => setSeverityThreshold(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0A162B] border border-white/10 text-slate-100 text-xs font-mono outline-none focus:border-[#38BDF8]"
                  >
                    <option value="All">All Findings (Low, Medium, High, Critical)</option>
                    <option value="Medium">Medium and Higher</option>
                    <option value="High">High and Critical Only</option>
                  </select>
                </div>

                {/* Scan Categories */}
                <div>
                  <label className="text-[10px] font-mono uppercase tracking-wider text-slate-300 block mb-1.5 font-semibold">
                    Active Vulnerability Classes
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-200">
                    <label className="flex items-center gap-2 p-2.5 rounded-xl bg-[#0A162B] border border-white/10 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={categoryInjection}
                        onChange={(e) => setCategoryInjection(e.target.checked)}
                        className="accent-[#38BDF8]"
                      />
                      <span className="text-[11px] font-mono">Injection (CWE-89 SQLi/NoSQL)</span>
                    </label>

                    <label className="flex items-center gap-2 p-2.5 rounded-xl bg-[#0A162B] border border-white/10 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={categoryNetwork}
                        onChange={(e) => setCategoryNetwork(e.target.checked)}
                        className="accent-[#38BDF8]"
                      />
                      <span className="text-[11px] font-mono">SSRF & Egress (CWE-918)</span>
                    </label>

                    <label className="flex items-center gap-2 p-2.5 rounded-xl bg-[#0A162B] border border-white/10 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={categoryAuth}
                        onChange={(e) => setCategoryAuth(e.target.checked)}
                        className="accent-[#38BDF8]"
                      />
                      <span className="text-[11px] font-mono">Auth & JWT Confusion (CWE-287)</span>
                    </label>
                  </div>
                </div>

                {/* Additional Toggles */}
                <div className="pt-2 border-t border-white/10 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-slate-200 font-medium block text-xs">Dependency Findings (SCA / SBOM)</span>
                      <span className="text-[10px] font-mono text-slate-400">Flag vulnerable third-party npm/pip/go modules.</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={includeDependencies}
                      onChange={(e) => setIncludeDependencies(e.target.checked)}
                      className="accent-[#38BDF8] cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-slate-200 font-medium block text-xs">Secret & Token Detection</span>
                      <span className="text-[10px] font-mono text-slate-400">Entropy scans for hardcoded API keys or cloud tokens.</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={includeSecrets}
                      onChange={(e) => setIncludeSecrets(e.target.checked)}
                      className="accent-[#38BDF8] cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-slate-200 font-medium block text-xs">Infrastructure & Docker Config Checks</span>
                      <span className="text-[10px] font-mono text-slate-400">Verify Dockerfile and Kubernetes manifest security baselines.</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={includeIaC}
                      onChange={(e) => setIncludeIaC(e.target.checked)}
                      className="accent-[#38BDF8] cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* PRIMARY SUBMIT BUTTON (Reference White Pill Button) */}
          <div>
            <button
              type="button"
              onClick={handleStartScan}
              disabled={progressState === 'scanning' || progressState === 'validating' || progressState === 'submitting'}
              className={`w-full py-3.5 px-6 rounded-full text-sm font-bold flex items-center justify-center gap-2.5 transition-all btn-press ${
                progressState === 'scanning' || progressState === 'validating' || progressState === 'submitting'
                  ? 'bg-[#122444] text-[#38BDF8] border border-[#38BDF8]/30 cursor-not-allowed shadow-md'
                  : 'btn-primary-pill text-[#070E1B] cursor-pointer'
              }`}
            >
              {progressState === 'validating' && (
                <>
                  <RefreshCw size={16} className="animate-spin text-[#38BDF8]" />
                  <span>Validating Target Inputs...</span>
                </>
              )}
              {progressState === 'submitting' && (
                <>
                  <Cpu size={16} className="animate-spin text-[#38BDF8]" />
                  <span>Initializing Sandbox Container...</span>
                </>
              )}
              {progressState === 'scanning' && (
                <>
                  <Cpu size={16} className="animate-spin text-[#38BDF8]" />
                  <span>Executing AST Pipeline ({scanProgress}%)...</span>
                </>
              )}
              {progressState === 'idle' && (
                <>
                  <Play size={16} className="fill-current text-[#070E1B]" />
                  <span>{primaryButtonLabel}</span>
                </>
              )}
              {progressState === 'completed' && (
                <>
                  <CheckCircle2 size={16} className="text-[#070E1B]" />
                  <span>Re-run Scan with Current Config</span>
                </>
              )}
            </button>

            {generalError && (
              <div className="mt-2 flex items-center gap-1.5 text-xs text-[#F87171] font-mono">
                <AlertCircle size={14} />
                <span>{generalError}</span>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: Compact Security Overview & Progress Display (5 cols) */}
        <div className="lg:col-span-5 space-y-5">
          {/* Security Overview Card */}
          <div className="rounded-2xl glass-card p-6 border border-white/10 space-y-4">
            <div className="pb-3 border-b border-white/10 flex items-center justify-between">
              <h2 className="text-base font-display font-bold text-white tracking-tight">
                Scan Target Overview
              </h2>
              <span className="text-[10px] font-mono uppercase px-2.5 py-0.5 rounded-full bg-[#38BDF8]/10 text-[#38BDF8] border border-[#38BDF8]/25 font-semibold">
                {scanMode.replace('_', ' ')}
              </span>
            </div>

            <div className="space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-white/5">
                <span className="text-slate-400">Target Scope:</span>
                <span className="text-slate-200 truncate max-w-[200px] font-semibold">
                  {scanMode === 'repository'
                    ? repoUrl.replace('https://github.com/', '') || 'Custom Repo'
                    : scanMode === 'source_code'
                    ? codeFilename
                    : reportFileName}
                </span>
              </div>

              <div className="flex items-center justify-between pb-2 border-b border-white/5">
                <span className="text-slate-400">Target Language:</span>
                <span className="text-[#38BDF8] font-semibold">
                  {scanMode === 'repository' ? repoLanguage : scanMode === 'source_code' ? codeLanguage : 'SARIF Multi-lingual'}
                </span>
              </div>

              <div className="flex items-center justify-between pb-2 border-b border-white/5">
                <span className="text-slate-400">Selected Profile:</span>
                <span className="text-[#A5B4FC] uppercase font-bold">
                  {scanProfile} analysis
                </span>
              </div>

              <div className="flex items-center justify-between pb-2 border-b border-white/5">
                <span className="text-slate-400">Active Check Classes:</span>
                <span className="text-slate-200">
                  {categoryInjection ? 'SQLi, ' : ''}
                  {categoryNetwork ? 'SSRF, ' : ''}
                  {categoryAuth ? 'Auth' : ''}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-400">Expected Output:</span>
                <span className="text-[#10B981] font-semibold">AST Diffs + Proofs</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[#0A162B]/80 border border-white/10 flex items-center justify-between text-[11px] font-mono">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] shadow-[0_0_8px_#10B981]" />
                <span className="text-slate-300">AST Engine Runtime:</span>
              </div>
              <span className="text-white font-semibold">In-Memory Sandbox</span>
            </div>
          </div>

          {/* Progress / Telemetry Section */}
          <div className="rounded-2xl glass-card p-6 border border-white/10 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="text-sm font-semibold text-white tracking-tight">
                Scan Pipeline State
              </span>
              <span className="font-mono text-xs text-[#38BDF8] font-bold tabular-nums">
                {scanProgress}% Completed
              </span>
            </div>

            {/* Progress Bar with Cobalt-Azure Gradient */}
            <div className="w-full h-2 rounded-full bg-[#0A162B] overflow-hidden border border-white/10">
              <div
                className="h-full bg-gradient-to-r from-[#2563EB] via-[#38BDF8] to-[#818CF8] transition-all duration-300"
                style={{ width: `${scanProgress}%` }}
              />
            </div>

            {/* 4 Pipeline Phases */}
            <div className="space-y-2 pt-1">
              {phases.map((phase) => {
                const isPassed = scanPhase > phase.id || progressState === 'completed';
                const isCurrent = scanPhase === phase.id && progressState === 'scanning';

                return (
                  <div
                    key={phase.id}
                    className={`p-3 rounded-xl border text-xs transition-all ${
                      isPassed
                        ? 'bg-[#122444]/60 border-[#10B981]/30 text-slate-200'
                        : isCurrent
                        ? 'bg-[#122444] border-[#38BDF8]/60 text-white shadow-md shadow-[#2563EB]/15'
                        : 'bg-[#0A162B]/60 border-white/5 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {isPassed ? (
                          <CheckCircle2 size={14} className="text-[#10B981] shrink-0" />
                        ) : isCurrent ? (
                          <span className="w-2 h-2 rounded-full bg-[#38BDF8] animate-pulse shrink-0" />
                        ) : (
                          <span className="w-2 h-2 rounded-full bg-white/20 shrink-0" />
                        )}
                        <span className="font-mono font-semibold text-[11px]">
                          Phase {phase.id}: {phase.title}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono text-slate-400">
                        {isPassed ? 'Verified' : isCurrent ? 'Running...' : 'Queued'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Live Terminal Output */}
          <div className="rounded-2xl glass-card p-5 border border-white/10 space-y-3 font-mono">
            <div className="flex items-center justify-between text-xs pb-2 border-b border-white/10 text-slate-300">
              <div className="flex items-center gap-2">
                <Terminal size={14} className="text-[#38BDF8]" />
                <span>Engine Telemetry Log</span>
              </div>
              <span className="text-[10px] text-slate-400">
                {terminalLogs.length} events
              </span>
            </div>

            <div className="h-44 overflow-y-auto bg-[#060D1A] p-3.5 rounded-xl border border-white/10 text-xs space-y-1.5">
              {terminalLogs.length === 0 ? (
                <div className="h-full flex items-center justify-center text-slate-400 text-xs text-center px-4">
                  Ready. Click "{primaryButtonLabel}" to trigger simulated AST taint analysis.
                </div>
              ) : (
                terminalLogs.map((log, index) => (
                  <div
                    key={index}
                    className={`leading-relaxed text-[11px] ${
                      log.includes('CRITICAL') || log.includes('SINK') || log.includes('DETECTOR')
                        ? 'text-[#F87171]'
                        : log.includes('finished') || log.includes('passed') || log.includes('complete')
                        ? 'text-[#10B981]'
                        : 'text-slate-300'
                    }`}
                  >
                    {log}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Discovered Findings Cards (once completed or found) */}
          {discoveredFindings.length > 0 && (
            <div className="rounded-2xl glass-card p-5 border border-[#F87171]/40 bg-[#0E203D]/90 space-y-3 animate-fade-in shadow-2xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Flame size={17} className="text-[#F87171]" />
                  <span className="text-sm font-semibold text-white tracking-tight">
                    Discovered Vulnerabilities ({discoveredFindings.length})
                  </span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#F59E0B]/10 text-[#FBBF24] border border-[#F59E0B]/20 font-medium">
                  DEMO DATA
                </span>
              </div>

              <div className="space-y-2.5">
                {discoveredFindings.map((finding) => (
                  <div
                    key={finding.id}
                    className="p-3.5 rounded-xl bg-[#0A162B] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono font-bold text-[#F87171] bg-[#F87171]/10 px-2 py-0.5 rounded-full border border-[#F87171]/25">
                          {finding.cwe}
                        </span>
                        <span className="text-xs font-semibold text-white">
                          {finding.title}
                        </span>
                      </div>
                      <span className="text-[11px] font-mono text-slate-400 block mt-0.5">
                        {finding.file}:{finding.line} · CVSS {finding.cvss}
                      </span>
                    </div>

                    <button
                      onClick={() => {
                        onSelectVulnerability(finding.id);
                        onNavigate('remediation');
                      }}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-mono font-bold text-[#070E1B] bg-white hover:bg-slate-100 shrink-0 transition-colors btn-press shadow-md"
                    >
                      <span>Review Patch</span>
                      <ArrowRight size={13} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

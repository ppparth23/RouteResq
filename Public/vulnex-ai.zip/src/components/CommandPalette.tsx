import React, { useState, useEffect, useRef } from 'react';
import { Search, ShieldAlert, FileCode, Wrench, ArrowRight, X, Terminal, Cpu } from 'lucide-react';
import { MOCK_VULNERABILITIES } from '../data/mockData';
import { NavigationTab } from './Sidebar';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: NavigationTab) => void;
  onSelectVulnerability: (vulnId: string) => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onSelectVulnerability,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
      if (!isOpen) return;

      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filteredVulns = MOCK_VULNERABILITIES.filter(
    (v) =>
      v.title.toLowerCase().includes(query.toLowerCase()) ||
      v.cwe.toLowerCase().includes(query.toLowerCase()) ||
      (v.cve && v.cve.toLowerCase().includes(query.toLowerCase())) ||
      v.file.toLowerCase().includes(query.toLowerCase())
  );

  const navigationActions = [
    { label: 'Start New Security Scan', tab: 'new-scan' as NavigationTab, icon: Terminal },
    { label: 'Review Vulnerability Findings (24 open)', tab: 'vulnerabilities' as NavigationTab, icon: ShieldAlert },
    { label: 'Open AI Remediation Diff Workbench', tab: 'remediation' as NavigationTab, icon: Wrench },
    { label: 'Validation Lab & Regression Prover', tab: 'validation-lab' as NavigationTab, icon: Cpu },
    { label: 'Generate Compliance & Audit Reports', tab: 'reports' as NavigationTab, icon: FileCode },
  ].filter((a) => a.label.toLowerCase().includes(query.toLowerCase()));

  const handleSelectVuln = (id: string) => {
    onSelectVulnerability(id);
    onNavigate('remediation');
    onClose();
  };

  const handleSelectAction = (tab: NavigationTab) => {
    onNavigate(tab);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/80 backdrop-blur-xl animate-fade-in">
      <div
        className="w-full max-w-2xl rounded-3xl bg-[#081224] border border-white/15 shadow-[0_24px_70px_-15px_rgba(0,0,0,0.9),0_0_30px_rgba(56,189,248,0.12)] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Input header */}
        <div className="flex items-center px-4 py-3.5 border-b border-white/10 gap-3 bg-[#0A162B]">
          <Search size={17} className="text-[#38BDF8] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search CVEs, vulnerabilities, file paths, or commands..."
            className="w-full bg-transparent text-sm text-white placeholder-slate-500 outline-none font-sans"
          />
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors btn-press"
          >
            <X size={16} />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-2.5 space-y-3.5">
          {navigationActions.length > 0 && (
            <div>
              <div className="px-3 py-1 text-[10px] font-mono uppercase tracking-wider text-slate-400 font-semibold">
                Navigation & Tasks
              </div>
              <div className="mt-1 space-y-1">
                {navigationActions.map((action) => {
                  const Icon = action.icon;
                  return (
                    <button
                      key={action.label}
                      onClick={() => handleSelectAction(action.tab)}
                      className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs text-slate-200 hover:bg-[#122444] hover:text-[#38BDF8] transition-colors group btn-press"
                    >
                      <div className="flex items-center gap-2.5">
                        <Icon size={14} className="text-slate-400 group-hover:text-[#38BDF8]" />
                        <span>{action.label}</span>
                      </div>
                      <ArrowRight size={13} className="text-slate-500 group-hover:text-[#38BDF8]" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {filteredVulns.length > 0 && (
            <div>
              <div className="px-3 py-1 text-[10px] font-mono uppercase tracking-wider text-slate-400 flex justify-between font-semibold">
                <span>Vulnerability Findings</span>
                <span>{filteredVulns.length} matches</span>
              </div>
              <div className="mt-1 space-y-1">
                {filteredVulns.map((vuln) => (
                  <button
                    key={vuln.id}
                    onClick={() => handleSelectVuln(vuln.id)}
                    className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-left bg-white/[0.02] hover:bg-[#122444] border border-white/5 hover:border-[#38BDF8]/30 transition-all group btn-press shadow-sm"
                  >
                    <div className="flex flex-col min-w-0 pr-2">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                            vuln.severity === 'Critical'
                              ? 'text-[#F87171] bg-[#F87171]/10 border border-[#F87171]/25'
                              : 'text-[#FBBF24] bg-[#FBBF24]/10 border border-[#FBBF24]/25'
                          }`}
                        >
                          {vuln.cwe}
                        </span>
                        <span className="text-xs font-semibold text-slate-200 group-hover:text-white truncate">
                          {vuln.title}
                        </span>
                      </div>
                      <span className="text-[11px] font-mono text-slate-400 mt-0.5 truncate">
                        {vuln.repository} · {vuln.file}:{vuln.line}
                      </span>
                    </div>
                    <div className="shrink-0 flex items-center gap-2">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/5 text-slate-300 border border-white/10 font-medium">
                        CVSS {vuln.cvss}
                      </span>
                      <ArrowRight size={13} className="text-slate-400 group-hover:text-[#38BDF8]" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {filteredVulns.length === 0 && navigationActions.length === 0 && (
            <div className="py-12 text-center text-xs text-slate-400">
              No matching findings or actions found for "{query}".
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="px-4 py-2.5 border-t border-white/10 bg-[#060D1A] flex items-center justify-between text-[11px] font-mono text-slate-400">
          <div className="flex items-center gap-3">
            <span>↑↓ Navigate</span>
            <span>↵ Select</span>
            <span>ESC Close</span>
          </div>
          <span className="text-[#38BDF8] font-semibold">VULNEX AST Index</span>
        </div>
      </div>
    </div>
  );
};

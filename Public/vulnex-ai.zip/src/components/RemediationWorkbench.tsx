import React, { useState, useEffect, useMemo } from 'react';
import {
  Wrench,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Copy,
  Check,
  Download,
  RotateCcw,
  Play,
  ArrowLeft,
  Maximize2,
  Minimize2,
  FileCode2,
  Sparkles,
  Layers,
  Terminal,
  Cpu,
  Info,
  ExternalLink,
  ChevronRight,
  Split,
  Eye,
  Activity,
  AlertCircle,
  Clock,
  HelpCircle,
} from 'lucide-react';
import { MOCK_VULNERABILITIES, Vulnerability } from '../data/mockData';
import { NavigationTab } from './Sidebar';

interface RemediationWorkbenchProps {
  onNavigate: (tab: NavigationTab) => void;
  selectedVulnId: string;
  onSelectVulnId: (id: string) => void;
}

// Stage state types
export type WorkflowStageState = 'not_started' | 'in_progress' | 'completed' | 'failed' | 'requires_review';

export interface WorkflowStage {
  id: number;
  name: string;
  description: string;
  state: WorkflowStageState;
}

export type CheckStatus = 'Pending' | 'Running' | 'Passed' | 'Failed' | 'Not available';

export interface ValidationCheckItem {
  id: string;
  name: string;
  type: 'syntax' | 'unit' | 'regression' | 'sast' | 'dependency';
  status: CheckStatus;
  duration?: string;
  detail: string;
  isImplemented: boolean; // Distinguishes checks that actually ran from those not yet implemented
}

export interface DetailedRemediationData {
  whatWasWrong: string;
  whyRisky: string;
  whatPatchChanges: string;
  whyReducesRisk: string;
  compatibilityConsiderations: string;
  remainingUncertainties: string;
  validationChecks: ValidationCheckItem[];
}

export const RemediationWorkbench: React.FC<RemediationWorkbenchProps> = ({
  onNavigate,
  selectedVulnId,
  onSelectVulnId,
}) => {
  // Active vulnerability
  const currentVuln: Vulnerability = useMemo(() => {
    return MOCK_VULNERABILITIES.find((v) => v.id === selectedVulnId) || MOCK_VULNERABILITIES[0];
  }, [selectedVulnId]);

  // Diff & display modes
  const [viewMode, setViewMode] = useState<'split' | 'unified'>('split');
  const [isExpanded, setIsExpanded] = useState(false);
  const [copiedOriginal, setCopiedOriginal] = useState(false);
  const [copiedPatch, setCopiedPatch] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Workflow stages state
  const [currentStageId, setCurrentStageId] = useState<number>(3); // 1 to 5
  const [patchGenerated, setPatchGenerated] = useState<boolean>(true);
  const [isValidating, setIsValidating] = useState<boolean>(false);
  const [validationRunCount, setValidationRunCount] = useState<number>(0);
  const [simulatedFailureMode, setSimulatedFailureMode] = useState<boolean>(false);

  // Detailed AI explanation & validation data for each vulnerability
  const remediationData: DetailedRemediationData = useMemo(() => {
    switch (currentVuln.cwe) {
      case 'CWE-89': // SQL Injection
        return {
          whatWasWrong:
            'The controller directly interpolated unescaped HTTP query parameters (req.query.customerId and req.query.status) into a dynamic SQL string literal executed via the raw database driver interface.',
          whyRisky:
            'An unauthenticated attacker can supply boolean tautology payloads (e.g. "\' OR \'1\'=\'1") or stacked queries (e.g. "; DROP TABLE customer_orders --") to bypass row-level access control, exfiltrate sensitive customer records, or mutate database state.',
          whatPatchChanges:
            'Replaces string template literal concatenation with PostgreSQL parameterized placeholders ($1, $2). Introduces runtime input format validation ensuring customerId adheres to strict alphanumeric format rules before touching the connection pool.',
          whyReducesRisk:
            'Parameterized query drivers send query structures and user-supplied arguments in separate wire-protocol phases. Database parsers treat parameters purely as scalar literal values, rendering SQL syntax manipulation mathematically impossible.',
          compatibilityConsiderations:
            'Clients passing customerId values outside the strict alphanumeric regex (^[a-zA-Z0-9_-]{8,64}$) will now receive HTTP 400 Bad Request instead of silent SQL evaluation. Downstream services must adhere to this contract.',
          remainingUncertainties:
            'While the controller query is secured, upstream API gateways should also enforce request size limits, and secondary read-replicas must maintain identical parameter binding semantics.',
          validationChecks: [
            {
              id: 'chk-syntax',
              name: 'TypeScript Compiler AST & Syntax Check',
              type: 'syntax',
              status: 'Passed',
              duration: '18ms',
              detail: 'Transpilation passed with strict null checks. No untyped parameters.',
              isImplemented: true,
            },
            {
              id: 'chk-unit',
              name: 'Controller Route Unit Test (Valid Customer ID)',
              type: 'unit',
              status: 'Passed',
              duration: '12ms',
              detail: 'HTTP 200 returned with correct 4 active orders for valid customer id.',
              isImplemented: true,
            },
            {
              id: 'chk-regr',
              name: 'Regression Invariant: Tautology Exploit Injection Payload',
              type: 'regression',
              status: 'Passed',
              duration: '15ms',
              detail: "Payload (' OR '1'='1) treated strictly as literal string parameter; 0 unexpected records returned.",
              isImplemented: true,
            },
            {
              id: 'chk-sast',
              name: 'Static Security Re-scan (AST Taint Propagation Sink)',
              type: 'sast',
              status: 'Passed',
              duration: '24ms',
              detail: 'Taint edge between req.query and db.query is broken. Zero raw queries detected.',
              isImplemented: true,
            },
            {
              id: 'chk-dep',
              name: 'Database Driver Connection Pool Configuration Audit',
              type: 'dependency',
              status: 'Not available',
              detail: 'Live database connection pool testing requires remote staging environment integration.',
              isImplemented: false,
            },
          ],
        };

      case 'CWE-79': // Cross-Site Scripting
        return {
          whatWasWrong:
            'User-controlled search terms were passed directly into dangerouslySetInnerHTML after a naive string replace without HTML entity escaping or sanitized DOM structure validation.',
          whyRisky:
            'Attackers can craft search URLs with embedded <script> tags or <img src=x onerror=...> event attributes. Victims clicking the link execute arbitrary JavaScript within their browsing session, exposing authentication tokens and session cookies.',
          whatPatchChanges:
            'Eliminates dangerouslySetInnerHTML entirely. Replaces raw markup interpolation with native React JSX virtual DOM elements and splits highlighted terms safely into isolated virtual text nodes.',
          whyReducesRisk:
            'React virtual DOM inherently escapes raw string values when rendering JSX text nodes, eliminating DOM parser script evaluation vectors at the architecture level.',
          compatibilityConsiderations:
            'Custom HTML markup previously styled inside user query strings will now be rendered as literal escaped text. CSS classes for highlighted marks must be maintained.',
          remainingUncertainties:
            'Ensure adjacent components or error notification wrappers in this view do not re-introduce unescaped innerHTML bindings.',
          validationChecks: [
            {
              id: 'chk-syntax',
              name: 'JSX / React Element Transpiler Check',
              type: 'syntax',
              status: 'Passed',
              duration: '14ms',
              detail: 'JSX compiles without syntax errors or dangerous props.',
              isImplemented: true,
            },
            {
              id: 'chk-unit',
              name: 'Text Token Splitter & Highlighting Unit Test',
              type: 'unit',
              status: 'Passed',
              duration: '8ms',
              detail: 'Keywords properly enclosed in <mark> tags while preserving whitespace.',
              isImplemented: true,
            },
            {
              id: 'chk-regr',
              name: 'Regression Invariant: Script & Event Handler Injection',
              type: 'regression',
              status: 'Passed',
              duration: '11ms',
              detail: '<img src=x onerror=alert(1)> safely rendered as literal string in Virtual DOM.',
              isImplemented: true,
            },
            {
              id: 'chk-sast',
              name: 'AST DOM Sink Re-scan',
              type: 'sast',
              status: 'Passed',
              duration: '19ms',
              detail: 'dangerouslySetInnerHTML AST call eliminated from component subtree.',
              isImplemented: true,
            },
            {
              id: 'chk-dep',
              name: 'DOMPurify NPM Package Version Verification',
              type: 'dependency',
              status: 'Not available',
              detail: 'Package lock integrity verification pending CI dependency resolution run.',
              isImplemented: false,
            },
          ],
        };

      case 'CWE-22': // Path Traversal
        return {
          whatWasWrong:
            'The file handler used filepath.Join with untrusted relative path segments without resolving canonical path boundaries or preventing directory traversal sequences (../).',
          whyRisky:
            'Attackers can pass arguments like "../../../../etc/passwd" to read sensitive system configuration, private credentials, or container secrets from the host filesystem.',
          whatPatchChanges:
            'Applies filepath.Clean to both base directory and user filename. Uses filepath.Rel to mathematically verify that the resolved path is strictly contained within the root storage boundary.',
          whyReducesRisk:
            'Any relative path resolving outside the cleaned root jail fails the boundary assertion and is terminated immediately before calling os.ReadFile.',
          compatibilityConsiderations:
            'Legitimate symlinks pointing outside the base directory will now be rejected. Storage layout must maintain all assets within the designated root tree.',
          remainingUncertainties:
            'File permissions and operating system level DAC controls must also prevent directory listing traversal.',
          validationChecks: [
            {
              id: 'chk-syntax',
              name: 'Go Compiler Type & Grammar Check',
              type: 'syntax',
              status: 'Passed',
              duration: '22ms',
              detail: 'Go 1.22 package builds with zero syntax or format errors.',
              isImplemented: true,
            },
            {
              id: 'chk-unit',
              name: 'Standard Asset Retrieval Unit Test',
              type: 'unit',
              status: 'Passed',
              duration: '9ms',
              detail: 'Successfully reads valid assets located in base directory.',
              isImplemented: true,
            },
            {
              id: 'chk-regr',
              name: 'Regression Test: Multiple ../ Parent Directory Escapes',
              type: 'regression',
              status: 'Passed',
              duration: '14ms',
              detail: 'Traversal payload rejected with HTTP 403 Forbidden; zero filesystem access.',
              isImplemented: true,
            },
            {
              id: 'chk-sast',
              name: 'Path Reachability Symbolic Analysis',
              type: 'sast',
              status: 'Passed',
              duration: '31ms',
              detail: 'Symbolic prover verified targetPath strictly resides within cleanBase.',
              isImplemented: true,
            },
            {
              id: 'chk-dep',
              name: 'POSIX File Permissions & Chroot Audit',
              type: 'dependency',
              status: 'Not available',
              detail: 'Operating system host jail checks require container deployment agent.',
              isImplemented: false,
            },
          ],
        };

      default:
        // Generic fallback for other vulnerabilities
        return {
          whatWasWrong: `Direct sink invocation in ${currentVuln.file}:${currentVuln.line} without input boundary sanitation.`,
          whyRisky: currentVuln.description,
          whatPatchChanges: currentVuln.patchExplanation,
          whyReducesRisk: currentVuln.formalInvariant,
          compatibilityConsiderations: 'Verify downstream callers handle updated validation errors appropriately.',
          remainingUncertainties: 'Monitor production error logs following deployment to detect unexpected edge-case inputs.',
          validationChecks: [
            {
              id: 'chk-syntax',
              name: 'Language Compiler & Grammar Validation',
              type: 'syntax',
              status: 'Passed',
              duration: '16ms',
              detail: 'Code compiles cleanly with strict type assertions.',
              isImplemented: true,
            },
            {
              id: 'chk-unit',
              name: 'Standard Operational Unit Test',
              type: 'unit',
              status: 'Passed',
              duration: '10ms',
              detail: 'Base scenario executed successfully with expected return data.',
              isImplemented: true,
            },
            {
              id: 'chk-regr',
              name: 'Exploit Vector Simulation & Regression Check',
              type: 'regression',
              status: 'Passed',
              duration: '17ms',
              detail: 'Adversarial payload blocked before reaching vulnerable sink.',
              isImplemented: true,
            },
            {
              id: 'chk-sast',
              name: 'Static Security Re-scan (AST Invariant Check)',
              type: 'sast',
              status: 'Passed',
              duration: '22ms',
              detail: 'Taint flow severed; AST invariant holds.',
              isImplemented: true,
            },
            {
              id: 'chk-dep',
              name: 'Runtime Infrastructure & Secret Store Integration',
              type: 'dependency',
              status: 'Not available',
              detail: 'Remote infrastructure integration test not configured in local harness.',
              isImplemented: false,
            },
          ],
        };
    }
  }, [currentVuln]);

  // Live checklist state that can be mutated during simulation
  const [liveChecks, setLiveChecks] = useState<ValidationCheckItem[]>(remediationData.validationChecks);

  // Sync live checks when vulnerability changes
  useEffect(() => {
    setLiveChecks(remediationData.validationChecks);
    setValidationRunCount(0);
    setCurrentStageId(3); // Default to stage 3: Patch Review
  }, [currentVuln.id, remediationData]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Workflow Stages definition
  const workflowStages: WorkflowStage[] = useMemo(() => {
    const isFindingSelected: WorkflowStageState = 'completed';
    const isPatchGen: WorkflowStageState = patchGenerated ? 'completed' : 'in_progress';
    const isPatchReview: WorkflowStageState =
      currentStageId === 3
        ? 'in_progress'
        : currentStageId > 3
        ? 'completed'
        : 'not_started';

    let validationState: WorkflowStageState = 'not_started';
    if (isValidating) {
      validationState = 'in_progress';
    } else if (validationRunCount > 0) {
      const hasFailure = liveChecks.some((c) => c.status === 'Failed');
      validationState = hasFailure ? 'failed' : 'completed';
    }

    let finalState: WorkflowStageState = 'not_started';
    if (validationRunCount > 0) {
      const hasFailure = liveChecks.some((c) => c.status === 'Failed');
      const hasUnimplemented = liveChecks.some((c) => !c.isImplemented || c.status === 'Not available');
      if (hasFailure) {
        finalState = 'failed';
      } else if (hasUnimplemented) {
        finalState = 'requires_review';
      } else {
        finalState = 'completed';
      }
    }

    return [
      {
        id: 1,
        name: 'Finding Selected',
        description: `${currentVuln.cwe} · ${currentVuln.file}`,
        state: isFindingSelected,
      },
      {
        id: 2,
        name: 'Patch Generation',
        description: patchGenerated ? 'AST Invariant Patch Synthesized' : 'Generating AST patch...',
        state: isPatchGen,
      },
      {
        id: 3,
        name: 'Patch Review',
        description: 'Side-by-side diff review',
        state: isPatchReview,
      },
      {
        id: 4,
        name: 'Validation',
        description:
          isValidating
            ? 'Running verification harness...'
            : validationRunCount > 0
            ? `${liveChecks.filter((c) => c.status === 'Passed').length} checks passed`
            : 'Validation pending',
        state: validationState,
      },
      {
        id: 5,
        name: 'Final Result',
        description:
          validationRunCount === 0
            ? 'Awaiting test execution'
            : finalState === 'failed'
            ? 'Validation Failed'
            : finalState === 'requires_review'
            ? 'Requires Review (Partial)'
            : 'Patch Validated',
        state: finalState,
      },
    ];
  }, [currentVuln, patchGenerated, currentStageId, isValidating, validationRunCount, liveChecks]);

  // Handle Validation Run Simulation
  const handleRunValidation = () => {
    setIsValidating(true);
    setCurrentStageId(4);
    showToast('Executing validation harness isolate container...');

    // Reset checks to pending first
    setLiveChecks((prev) =>
      prev.map((c) => (c.isImplemented ? { ...c, status: 'Running' } : c))
    );

    // Sequentially complete checks with step animation
    let step = 0;
    const implementedChecks = liveChecks.filter((c) => c.isImplemented);

    const interval = setInterval(() => {
      if (step < implementedChecks.length) {
        const targetCheck = implementedChecks[step];
        setLiveChecks((current) =>
          current.map((c) => {
            if (c.id === targetCheck.id) {
              // If simulated failure mode is active, fail the 3rd check
              if (simulatedFailureMode && c.type === 'regression') {
                return {
                  ...c,
                  status: 'Failed',
                  detail: 'Exploit simulation detected unexpected non-zero exit code: assertion failure in test harness.',
                };
              }
              return { ...c, status: 'Passed' };
            }
            return c;
          })
        );
        step++;
      } else {
        clearInterval(interval);
        setIsValidating(false);
        setValidationRunCount((count) => count + 1);
        setCurrentStageId(5);
        showToast('Validation execution complete');
      }
    }, 450);
  };

  // Handle Generate Patch Simulation
  const handleGeneratePatch = () => {
    setPatchGenerated(false);
    setCurrentStageId(2);
    showToast('Synthesizing neural-symbolic AST patch...');

    setTimeout(() => {
      setPatchGenerated(true);
      setCurrentStageId(3);
      showToast('Patch synthesized successfully');
    }, 900);
  };

  // Handle Reset Changes
  const handleResetChanges = () => {
    setValidationRunCount(0);
    setCurrentStageId(1);
    setLiveChecks(remediationData.validationChecks.map((c) => ({ ...c, status: c.isImplemented ? 'Pending' : 'Not available' })));
    setSimulatedFailureMode(false);
    showToast('Remediation state reset to original finding');
  };

  // Handle Download Patch
  const handleDownloadPatch = () => {
    const filename = `vulnex-remediation-${currentVuln.id.toLowerCase()}.patch`;
    const diffHeader = `--- a/${currentVuln.file}\n+++ b/${currentVuln.file}\n@@ -${currentVuln.line},12 +${currentVuln.line},18 @@\n`;
    const diffBody = [
      ...currentVuln.vulnerableCode.split('\n').map((l) => `- ${l}`),
      ...currentVuln.patchedCode.split('\n').map((l) => `+ ${l}`),
    ].join('\n');
    const content = `${diffHeader}${diffBody}\n\n# Patch generated by VULNEX AI Neural-Symbolic Prover\n# Weakness: ${currentVuln.cwe} - ${currentVuln.title}\n# AST Invariant: ${currentVuln.formalInvariant}\n`;

    const blob = new Blob([content], { type: 'text/x-diff;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showToast(`Downloaded unified patch file: ${filename}`);
  };

  // Copy helpers
  const handleCopyOriginal = () => {
    navigator.clipboard?.writeText(currentVuln.vulnerableCode);
    setCopiedOriginal(true);
    showToast('Original code copied to clipboard');
    setTimeout(() => setCopiedOriginal(false), 2000);
  };

  const handleCopyPatch = () => {
    navigator.clipboard?.writeText(currentVuln.patchedCode);
    setCopiedPatch(true);
    showToast('Proposed patch copied to clipboard');
    setTimeout(() => setCopiedPatch(false), 2000);
  };

  // Computed Final Result State
  const finalResultState = useMemo(() => {
    if (validationRunCount === 0) {
      return {
        status: 'UNTESTED',
        title: 'Validation Pending',
        description: 'This patch has not yet undergone sandbox isolate verification or regression test harness execution.',
        badgeColor: 'bg-slate-800 text-slate-400 border-slate-700',
        icon: Clock,
      };
    }

    const hasFailure = liveChecks.some((c) => c.status === 'Failed');
    if (hasFailure) {
      const failedCheck = liveChecks.find((c) => c.status === 'Failed');
      return {
        status: 'VALIDATION FAILED',
        title: 'Validation Failed',
        description: `Check "${failedCheck?.name}" failed during verification: ${failedCheck?.detail}`,
        badgeColor: 'bg-[#F87171]/15 text-[#F87171] border-[#F87171]/40',
        icon: XCircle,
      };
    }

    const hasUnimplemented = liveChecks.some((c) => !c.isImplemented || c.status === 'Not available');
    if (hasUnimplemented) {
      const ranCount = liveChecks.filter((c) => c.status === 'Passed').length;
      return {
        status: 'REQUIRES REVIEW',
        title: 'Requires Review (Partial Validation)',
        description: `${ranCount} of ${liveChecks.length} checks executed and passed in sandbox isolate. Dependency/configuration audit is not implemented in local runtime and requires peer review.`,
        badgeColor: 'bg-[#FBBF24]/15 text-[#FBBF24] border-[#FBBF24]/40',
        icon: AlertTriangle,
      };
    }

    const passedChecksList = liveChecks.filter((c) => c.status === 'Passed').map((c) => c.name);
    return {
      status: 'PATCH VALIDATED',
      title: 'Patch Validated',
      description: `All configured checks passed: ${passedChecksList.join(', ')}. AST Invariant holds.`,
      badgeColor: 'bg-[#10B981]/15 text-[#34D399] border-[#10B981]/40',
      icon: CheckCircle2,
    };
  }, [validationRunCount, liveChecks]);

  return (
    <div className="space-y-6 animate-fade-in pb-16">
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-[#0D2040] border border-[#38BDF8]/40 text-slate-100 text-xs font-mono shadow-[0_10px_30px_rgba(0,0,0,0.8),0_0_20px_rgba(56,189,248,0.2)] animate-fade-in">
          <CheckCircle2 size={14} className="text-[#38BDF8]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. PAGE HEADER */}
      <div className="rounded-3xl glass-card p-6 border border-white/10 space-y-4 shadow-xl relative overflow-hidden">
        {/* Soft radial backdrop illumination */}
        <div className="absolute top-0 right-1/4 w-96 h-32 bg-[#2563EB]/15 blur-3xl rounded-full pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2.5">
              <h1 className="text-2xl sm:text-3xl font-display font-bold text-white tracking-tight">
                AI Remediation Lab
              </h1>

              {/* Sample Data Badge */}
              <span className="text-[10px] font-mono font-semibold px-2.5 py-0.5 rounded-full bg-[#F59E0B]/10 text-[#FBBF24] border border-[#F59E0B]/30 tracking-wide uppercase">
                SAMPLE PATCH DATA · PRE-RELEASE ENGINE
              </span>

              {/* Guardrail Callout */}
              <span className="inline-flex items-center gap-1.5 text-xs font-mono px-3 py-1 rounded-full bg-[#122444] text-[#38BDF8] border border-[#38BDF8]/30">
                <ShieldCheck size={13} className="text-[#38BDF8]" />
                Verification Required Before Merge
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
              Review proposed security fixes, compare code changes, and validate the result before accepting a patch. Never assume a patch is secure simply because an AI model generated it.
            </p>
          </div>

          {/* Target Finding Selector & Back Action */}
          <div className="flex items-center gap-2.5 shrink-0 self-start lg:self-center">
            <button
              onClick={() => onNavigate('vulnerabilities')}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-full bg-[#0A162B] hover:bg-[#122444] border border-white/15 text-xs font-mono text-slate-300 hover:text-white transition-all btn-press"
            >
              <ArrowLeft size={13} />
              <span>Back to Findings</span>
            </button>

            <div className="flex items-center gap-2">
              <select
                value={currentVuln.id}
                onChange={(e) => onSelectVulnId(e.target.value)}
                className="bg-[#070E1B] border border-white/20 rounded-full px-3.5 py-2 text-xs font-mono text-slate-100 outline-none focus:border-[#38BDF8] transition-colors max-w-xs truncate"
              >
                {MOCK_VULNERABILITIES.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.cwe} · {v.title.slice(0, 36)}... ({v.file.split('/').pop()})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Selected Vulnerability & File Banner */}
        <div className="pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-slate-400">Target Weakness:</span>
            <span className="text-white font-bold">{currentVuln.title}</span>
            <span className="text-[#38BDF8]">({currentVuln.cwe})</span>
            <span>·</span>
            <span className="text-slate-300 bg-[#070E1B] px-2 py-0.5 rounded border border-white/10">
              {currentVuln.file}:{currentVuln.line}
            </span>
          </div>

          <div className="text-[11px] text-slate-400">
            Repository: <span className="text-slate-200">{currentVuln.repository}</span> ({currentVuln.language})
          </div>
        </div>
      </div>

      {/* 2. REMEDIATION STATUS WORKFLOW INDICATOR */}
      <div className="rounded-3xl glass-card p-5 border border-white/10 space-y-3 shadow-lg">
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
            Remediation Workflow Pipeline
          </span>
          <span className="text-[11px] text-[#38BDF8]">
            Stage {currentStageId} of 5 Active
          </span>
        </div>

        {/* Step Indicator Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 font-mono text-xs">
          {workflowStages.map((stage) => {
            const isCurrent = stage.id === currentStageId;
            const isCompleted = stage.state === 'completed';
            const isInProgress = stage.state === 'in_progress';
            const isFailed = stage.state === 'failed';
            const isRequiresReview = stage.state === 'requires_review';

            return (
              <div
                key={stage.id}
                onClick={() => setCurrentStageId(stage.id)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer relative ${
                  isCurrent
                    ? 'bg-[#0E2242] border-[#38BDF8] shadow-[0_0_15px_rgba(56,189,248,0.25)] ring-1 ring-[#38BDF8]/40'
                    : isCompleted
                    ? 'bg-[#091D1A] border-[#10B981]/30 hover:border-[#10B981]/50'
                    : isFailed
                    ? 'bg-[#241014] border-[#F87171]/40'
                    : isRequiresReview
                    ? 'bg-[#261B0B] border-[#FBBF24]/40'
                    : 'bg-[#070E1B] border-white/10 opacity-75 hover:opacity-100'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] font-bold text-slate-400">
                    0{stage.id}
                  </span>
                  <div>
                    {isCompleted && <CheckCircle2 size={13} className="text-[#34D399]" />}
                    {isInProgress && (
                      <span className="w-2 h-2 rounded-full bg-[#38BDF8] animate-pulse inline-block shadow-[0_0_6px_#38BDF8]" />
                    )}
                    {isFailed && <XCircle size={13} className="text-[#F87171]" />}
                    {isRequiresReview && <AlertTriangle size={13} className="text-[#FBBF24]" />}
                    {stage.state === 'not_started' && (
                      <span className="w-1.5 h-1.5 rounded-full bg-slate-600 inline-block" />
                    )}
                  </div>
                </div>

                <div className="font-semibold text-white truncate text-xs">
                  {stage.name}
                </div>

                <div
                  className={`text-[10px] truncate mt-1 ${
                    isCompleted
                      ? 'text-[#34D399]'
                      : isInProgress
                      ? 'text-[#38BDF8]'
                      : isFailed
                      ? 'text-[#F87171]'
                      : isRequiresReview
                      ? 'text-[#FBBF24]'
                      : 'text-slate-400'
                  }`}
                >
                  {stage.description}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. VULNERABILITY CONTEXT */}
      <div className="rounded-3xl glass-card p-6 border border-white/10 space-y-4 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <span
              className={`text-xs font-mono px-2.5 py-0.5 rounded-full font-bold ${
                currentVuln.severity === 'Critical'
                  ? 'text-[#F87171] bg-[#F87171]/15 border border-[#F87171]/30'
                  : 'text-[#FBBF24] bg-[#FBBF24]/15 border border-[#FBBF24]/30'
              }`}
            >
              {currentVuln.severity}
            </span>

            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-slate-200 font-semibold">
              {currentVuln.cwe}
            </span>

            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-[#38BDF8]/10 text-[#38BDF8] border border-[#38BDF8]/25 font-semibold">
              CVSS {currentVuln.cvss}
            </span>
          </div>

          <div className="text-xs font-mono text-slate-400">
            Affected File: <span className="text-[#38BDF8]">{currentVuln.file}:{currentVuln.line}</span>
          </div>
        </div>

        {/* Side-by-Side: Scanner Finding vs AI Commentary */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs font-mono">
          {/* Scanner Findings (Deterministic Evidence) */}
          <div className="p-4 rounded-2xl bg-[#070E1B] border border-white/10 space-y-2.5">
            <div className="flex items-center justify-between text-[#38BDF8]">
              <span className="font-bold flex items-center gap-1.5 uppercase text-[10px] tracking-wider">
                <Cpu size={13} />
                <span>Deterministic Scanner Evidence</span>
              </span>
              <span className="text-[10px] text-slate-400">Verified Sink</span>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 block uppercase">Source-Code Taint Flow:</span>
              <div className="p-2.5 rounded-xl bg-[#050B16] border border-white/10 text-[#38BDF8] text-[11px] font-semibold break-all">
                {currentVuln.taintedFlow}
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 block uppercase">Original Security Rule:</span>
              <p className="text-slate-300 font-sans text-xs leading-relaxed">
                {currentVuln.whyFlagged}
              </p>
            </div>
          </div>

          {/* AI-Generated Commentary & Risk Summary */}
          <div className="p-4 rounded-2xl bg-[#0A162B] border border-[#38BDF8]/25 space-y-2.5">
            <div className="flex items-center justify-between text-[#60A5FA]">
              <span className="font-bold flex items-center gap-1.5 uppercase text-[10px] tracking-wider">
                <Sparkles size={13} />
                <span>AI Risk Assessment & Guidance</span>
              </span>
              <span className="text-[10px] text-slate-400">Neural-Symbolic Analysis</span>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 block uppercase">Original Recommendation:</span>
              <p className="text-slate-200 font-sans text-xs leading-relaxed">
                {currentVuln.suggestedRemediation}
              </p>
            </div>

            {/* Compact CIA Impact rating */}
            <div className="pt-1">
              <span className="text-[10px] text-slate-400 block uppercase mb-1">Impact Breakdown (CIA):</span>
              <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
                <div className="p-1.5 rounded-lg bg-[#070E1B] border border-white/10">
                  <span className="text-[9px] text-slate-400 block">Confidentiality</span>
                  <span className="font-bold text-[#F87171]">{currentVuln.potentialImpact.confidentiality}</span>
                </div>
                <div className="p-1.5 rounded-lg bg-[#070E1B] border border-white/10">
                  <span className="text-[9px] text-slate-400 block">Integrity</span>
                  <span className="font-bold text-[#FBBF24]">{currentVuln.potentialImpact.integrity}</span>
                </div>
                <div className="p-1.5 rounded-lg bg-[#070E1B] border border-white/10">
                  <span className="text-[9px] text-slate-400 block">Availability</span>
                  <span className="font-bold text-slate-300">{currentVuln.potentialImpact.availability}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4. SIDE-BY-SIDE CODE COMPARISON & DIFF VIEWER */}
      <div className={`rounded-3xl glass-card border border-white/15 overflow-hidden shadow-2xl transition-all ${isExpanded ? 'fixed inset-4 z-50 overflow-y-auto bg-[#070E1B]' : ''}`}>
        {/* Diff Toolbar */}
        <div className="p-4 border-b border-white/10 bg-[#091529] flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-white font-bold">
              <FileCode2 size={15} className="text-[#38BDF8]" />
              <span>{currentVuln.file}</span>
            </div>

            <span className="text-slate-500">|</span>

            {/* View Mode Toggle */}
            <div className="flex items-center p-0.5 rounded-full bg-[#060D1A] border border-white/15">
              <button
                onClick={() => setViewMode('split')}
                className={`px-3 py-1 rounded-full transition-all btn-press ${
                  viewMode === 'split' ? 'bg-[#122444] text-[#38BDF8] font-bold shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                Side-by-Side
              </button>
              <button
                onClick={() => setViewMode('unified')}
                className={`px-3 py-1 rounded-full transition-all btn-press ${
                  viewMode === 'unified' ? 'bg-[#122444] text-[#38BDF8] font-bold shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                Unified Diff
              </button>
            </div>

            <span className="text-[11px] text-slate-400 hidden sm:inline">
              Inspecting line {currentVuln.line}
            </span>
          </div>

          {/* Copy & View Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyOriginal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#0A162B] hover:bg-[#122444] text-slate-300 hover:text-white border border-white/10 transition-colors btn-press"
              title="Copy original vulnerable snippet"
            >
              {copiedOriginal ? <Check size={12} className="text-[#34D399]" /> : <Copy size={12} />}
              <span>{copiedOriginal ? 'Copied' : 'Copy Original'}</span>
            </button>

            <button
              onClick={handleCopyPatch}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#122444] hover:bg-[#1A335E] text-[#38BDF8] border border-[#38BDF8]/30 transition-colors btn-press font-semibold"
              title="Copy proposed secure patch"
            >
              {copiedPatch ? <Check size={12} className="text-[#34D399]" /> : <Copy size={12} />}
              <span>{copiedPatch ? 'Copied' : 'Copy Patch'}</span>
            </button>

            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1.5 rounded-full bg-[#0A162B] hover:bg-[#122444] text-slate-400 hover:text-white border border-white/10 transition-colors btn-press"
              title={isExpanded ? 'Collapse' : 'Expand full-screen'}
            >
              {isExpanded ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
            </button>
          </div>
        </div>

        {/* Code Diff Canvas */}
        {viewMode === 'split' ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-white/10 font-mono text-xs">
            {/* LEFT: Original Vulnerable Code */}
            <div className="bg-[#050B16] flex flex-col">
              <div className="px-4 py-2.5 bg-[#1F0E14]/80 border-b border-[#F87171]/20 flex items-center justify-between text-[#F87171]">
                <span className="font-bold flex items-center gap-2 text-xs">
                  <span className="w-2 h-2 rounded-full bg-[#F87171]" />
                  Original Code (Vulnerable Sink)
                </span>
                <span className="text-[11px] text-slate-400">Lines {currentVuln.line - 2}–{currentVuln.line + 10}</span>
              </div>

              <div className="p-4 overflow-x-auto space-y-1 flex-1">
                {currentVuln.vulnerableCode.split('\n').map((line, idx) => {
                  const lineNum = currentVuln.line - 2 + idx;
                  const isFlagged = lineNum === currentVuln.line || line.includes('VULNERABLE') || line.includes('${') || line.includes('raw(');

                  return (
                    <div
                      key={idx}
                      className={`flex items-start gap-3 px-2 py-0.5 rounded leading-relaxed ${
                        isFlagged
                          ? 'bg-[#F87171]/20 text-[#FCA5A5] border-l-2 border-[#F87171]'
                          : 'text-slate-400 hover:bg-white/[0.02]'
                      }`}
                    >
                      <span className="w-6 shrink-0 text-right select-none text-slate-600 text-[11px]">
                        {lineNum}
                      </span>
                      <span className="select-none text-[#F87171] font-bold shrink-0">-</span>
                      <pre className="font-mono overflow-x-auto whitespace-pre">{line}</pre>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* RIGHT: Proposed Secure Patch */}
            <div className="bg-[#050B16] flex flex-col">
              <div className="px-4 py-2.5 bg-[#092318]/80 border-b border-[#10B981]/25 flex items-center justify-between text-[#34D399]">
                <span className="font-bold flex items-center gap-2 text-xs">
                  <span className="w-2 h-2 rounded-full bg-[#34D399]" />
                  Proposed Secure Patch (Invariant Enforced)
                </span>
                <span className="text-[11px] text-[#34D399]">AST Parameterized</span>
              </div>

              <div className="p-4 overflow-x-auto space-y-1 flex-1">
                {currentVuln.patchedCode.split('\n').map((line, idx) => {
                  const lineNum = currentVuln.line - 2 + idx;
                  const isAdded = line.includes('SECURE') || line.includes('$1') || line.includes('regex') || line.includes('typeof');

                  return (
                    <div
                      key={idx}
                      className={`flex items-start gap-3 px-2 py-0.5 rounded leading-relaxed ${
                        isAdded
                          ? 'bg-[#10B981]/20 text-[#A7F3D0] border-l-2 border-[#10B981]'
                          : 'text-slate-300 hover:bg-white/[0.02]'
                      }`}
                    >
                      <span className="w-6 shrink-0 text-right select-none text-slate-600 text-[11px]">
                        {lineNum}
                      </span>
                      <span className="select-none text-[#34D399] font-bold shrink-0">+</span>
                      <pre className="font-mono overflow-x-auto whitespace-pre">{line}</pre>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          /* UNIFIED DIFF VIEW */
          <div className="bg-[#050B16] p-4 overflow-x-auto font-mono text-xs space-y-2">
            <div className="text-[11px] text-slate-400 pb-2 border-b border-white/10 flex items-center justify-between">
              <span>unified diff · a/{currentVuln.file} b/{currentVuln.file}</span>
              <span className="text-[#38BDF8]">@@ -{currentVuln.line},12 +{currentVuln.line},18 @@</span>
            </div>

            <div className="space-y-1">
              {currentVuln.vulnerableCode.split('\n').map((line, idx) => (
                <div key={`rem-${idx}`} className="flex items-start gap-3 px-2 py-0.5 rounded bg-[#F87171]/15 text-[#FCA5A5] border-l-2 border-[#F87171]">
                  <span className="w-6 text-right select-none text-slate-600 text-[11px]">{currentVuln.line - 2 + idx}</span>
                  <span className="text-[#F87171] font-bold select-none">-</span>
                  <pre className="font-mono overflow-x-auto whitespace-pre">{line}</pre>
                </div>
              ))}

              {currentVuln.patchedCode.split('\n').map((line, idx) => (
                <div key={`add-${idx}`} className="flex items-start gap-3 px-2 py-0.5 rounded bg-[#10B981]/15 text-[#A7F3D0] border-l-2 border-[#10B981]">
                  <span className="w-6 text-right select-none text-slate-600 text-[11px]">{currentVuln.line - 2 + idx}</span>
                  <span className="text-[#34D399] font-bold select-none">+</span>
                  <pre className="font-mono overflow-x-auto whitespace-pre">{line}</pre>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 5. AI EXPLANATION PANEL */}
      <div className="rounded-3xl glass-card p-6 border border-white/10 space-y-5 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-[#38BDF8]" />
            <h2 className="text-base font-display font-bold text-white tracking-tight">
              AI Patch Explanation & Soundness Analysis
            </h2>
          </div>
          <span className="text-[11px] font-mono text-slate-400">
            * Formal invariant assessment; model confidence is not proof of security.
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          {/* What was wrong */}
          <div className="p-4 rounded-2xl bg-[#070E1B] border border-white/10 space-y-1.5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold block text-[#F87171]">
              1. What was wrong
            </span>
            <p className="font-sans text-slate-300 leading-relaxed text-xs">
              {remediationData.whatWasWrong}
            </p>
          </div>

          {/* Why risky */}
          <div className="p-4 rounded-2xl bg-[#070E1B] border border-white/10 space-y-1.5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold block text-[#FBBF24]">
              2. Why original implementation is risky
            </span>
            <p className="font-sans text-slate-300 leading-relaxed text-xs">
              {remediationData.whyRisky}
            </p>
          </div>

          {/* What patch changes */}
          <div className="p-4 rounded-2xl bg-[#070E1B] border border-white/10 space-y-1.5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold block text-[#38BDF8]">
              3. What the patch changes
            </span>
            <p className="font-sans text-slate-300 leading-relaxed text-xs">
              {remediationData.whatPatchChanges}
            </p>
          </div>

          {/* Why reduces risk */}
          <div className="p-4 rounded-2xl bg-[#070E1B] border border-white/10 space-y-1.5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold block text-[#34D399]">
              4. Why proposed change reduces risk
            </span>
            <p className="font-sans text-slate-300 leading-relaxed text-xs">
              {remediationData.whyReducesRisk}
            </p>
          </div>

          {/* Potential compatibility considerations */}
          <div className="p-4 rounded-2xl bg-[#0A162B] border border-white/10 space-y-1.5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold block text-[#A5B4FC]">
              5. Compatibility Considerations
            </span>
            <p className="font-sans text-slate-300 leading-relaxed text-xs">
              {remediationData.compatibilityConsiderations}
            </p>
          </div>

          {/* Remaining uncertainties */}
          <div className="p-4 rounded-2xl bg-[#0A162B] border border-white/10 space-y-1.5">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold block text-amber-300">
              6. Remaining Uncertainties
            </span>
            <p className="font-sans text-slate-300 leading-relaxed text-xs">
              {remediationData.remainingUncertainties}
            </p>
          </div>
        </div>
      </div>

      {/* 6. VALIDATION PANEL */}
      <div className="rounded-3xl glass-card p-6 border border-white/10 space-y-5 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-white/10">
          <div>
            <h2 className="text-base font-display font-bold text-white tracking-tight flex items-center gap-2">
              <CheckCircle2 size={16} className="text-[#38BDF8]" />
              <span>Automated Verification Checklist</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Distinguishes tests executed in the sandbox container from checks awaiting deployment integration.
            </p>
          </div>

          {/* Simulated Failure Mode Toggle for Testing */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSimulatedFailureMode(!simulatedFailureMode)}
              className={`px-3 py-1 rounded-full text-xs font-mono transition-colors border ${
                simulatedFailureMode
                  ? 'bg-[#F87171]/20 text-[#F87171] border-[#F87171]/40'
                  : 'bg-[#070E1B] text-slate-400 border-white/10 hover:text-white'
              }`}
              title="Toggle simulated test failure for regression check"
            >
              Test Failure Mode: {simulatedFailureMode ? 'ON' : 'OFF'}
            </button>

            <button
              onClick={handleRunValidation}
              disabled={isValidating}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 text-[#070E1B] text-xs font-mono font-bold transition-all shadow-md btn-press disabled:opacity-50"
            >
              <Play size={13} className={isValidating ? 'animate-spin' : ''} />
              <span>{isValidating ? 'Executing Checks...' : 'Run All Validation Checks'}</span>
            </button>
          </div>
        </div>

        {/* Checklist Rows */}
        <div className="space-y-3 font-mono text-xs">
          {liveChecks.map((check) => {
            const isPassed = check.status === 'Passed';
            const isFailed = check.status === 'Failed';
            const isRunning = check.status === 'Running';
            const isNotAvail = check.status === 'Not available';

            return (
              <div
                key={check.id}
                className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  isPassed
                    ? 'bg-[#091D1A]/80 border-[#10B981]/30'
                    : isFailed
                    ? 'bg-[#241014]/90 border-[#F87171]/40'
                    : isRunning
                    ? 'bg-[#0E2242]/80 border-[#38BDF8]/40 shadow-sm'
                    : isNotAvail
                    ? 'bg-[#070E1B] border-white/10 opacity-70'
                    : 'bg-[#070E1B] border-white/10'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2.5">
                    {/* Status Icon */}
                    {isPassed && <CheckCircle2 size={16} className="text-[#34D399] shrink-0" />}
                    {isFailed && <XCircle size={16} className="text-[#F87171] shrink-0" />}
                    {isRunning && <Activity size={16} className="text-[#38BDF8] animate-spin shrink-0" />}
                    {isNotAvail && <AlertCircle size={16} className="text-slate-500 shrink-0" />}
                    {check.status === 'Pending' && <Clock size={16} className="text-slate-500 shrink-0" />}

                    <span className="font-bold text-white text-xs">{check.name}</span>

                    {/* Execution tag */}
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full border ${
                        check.isImplemented
                          ? 'bg-[#122444] text-[#38BDF8] border-[#38BDF8]/30'
                          : 'bg-slate-800 text-slate-400 border-slate-700'
                      }`}
                    >
                      {check.isImplemented ? 'Executed in Isolate' : 'Awaiting Integration'}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-300 font-sans pl-6">
                    {check.detail}
                  </p>
                </div>

                <div className="flex items-center gap-3 shrink-0 pl-6 sm:pl-0">
                  {check.duration && (
                    <span className="text-[11px] text-slate-400 tabular-nums">
                      {check.duration}
                    </span>
                  )}

                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold border ${
                      isPassed
                        ? 'bg-[#10B981]/20 text-[#34D399] border-[#10B981]/40'
                        : isFailed
                        ? 'bg-[#F87171]/20 text-[#F87171] border-[#F87171]/40'
                        : isRunning
                        ? 'bg-[#38BDF8]/20 text-[#38BDF8] border-[#38BDF8]/40'
                        : isNotAvail
                        ? 'bg-slate-800 text-slate-400 border-slate-700'
                        : 'bg-white/5 text-slate-400 border-white/10'
                    }`}
                  >
                    {check.status}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 7. FINAL RESULT CARD */}
      <div className={`rounded-3xl p-6 border shadow-xl space-y-3 font-mono text-xs ${finalResultState.badgeColor}`}>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <finalResultState.icon size={18} />
            <span className="text-sm font-bold uppercase tracking-wider">
              {finalResultState.title}
            </span>
          </div>

          <span className="text-[11px] px-2.5 py-0.5 rounded-full border border-current font-bold">
            {finalResultState.status}
          </span>
        </div>

        <p className="text-slate-200 font-sans text-xs leading-relaxed">
          {finalResultState.description}
        </p>

        {/* Disclaimer constraint */}
        <div className="pt-2 border-t border-white/10 text-[11px] text-slate-400">
          * Guardrail policy: Patches must never be automatically merged without regression test verification.
        </div>
      </div>

      {/* 8. WORKSPACE ACTIONS FOOTER */}
      <div className="rounded-3xl glass-card p-5 border border-white/10 flex flex-wrap items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={() => onNavigate('vulnerabilities')}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#070E1B] hover:bg-white/10 border border-white/15 text-slate-300 hover:text-white transition-colors btn-press"
          >
            <ArrowLeft size={13} />
            <span>Back to Findings</span>
          </button>

          <button
            onClick={handleResetChanges}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#070E1B] hover:bg-white/10 border border-white/15 text-slate-300 hover:text-white transition-colors btn-press"
          >
            <RotateCcw size={13} />
            <span>Reset Changes</span>
          </button>
        </div>

        <div className="flex items-center gap-2.5 font-mono text-xs">
          <button
            onClick={handleGeneratePatch}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#0A162B] hover:bg-[#122444] border border-[#38BDF8]/30 text-[#38BDF8] font-bold transition-all btn-press shadow-sm"
          >
            <Wrench size={13} />
            <span>Generate Patch</span>
          </button>

          <button
            onClick={handleRunValidation}
            disabled={isValidating}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#122444] hover:bg-[#1A335E] border border-white/20 text-white font-bold transition-all btn-press shadow-sm disabled:opacity-50"
          >
            <Play size={13} className={isValidating ? 'animate-spin' : ''} />
            <span>Validate Patch</span>
          </button>

          <button
            onClick={handleDownloadPatch}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-white hover:bg-slate-100 text-[#070E1B] font-bold transition-all shadow-md btn-press"
          >
            <Download size={14} />
            <span>Download .patch</span>
          </button>
        </div>
      </div>
    </div>
  );
};

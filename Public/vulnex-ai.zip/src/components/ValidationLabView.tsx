import React, { useState } from 'react';
import {
  FlaskConical,
  CheckCircle2,
  XCircle,
  Play,
  Cpu,
  ShieldCheck,
  Terminal,
} from 'lucide-react';
import { MOCK_VULNERABILITIES, Vulnerability } from '../data/mockData';
import { NavigationTab } from './Sidebar';

interface ValidationLabViewProps {
  onNavigate: (tab: NavigationTab) => void;
  selectedVulnId: string;
  onSelectVulnId: (id: string) => void;
}

export const ValidationLabView: React.FC<ValidationLabViewProps> = ({
  onNavigate,
  selectedVulnId,
  onSelectVulnId,
}) => {
  const [isRunning, setIsRunning] = useState(false);
  const [activeTestIndex, setActiveTestIndex] = useState<number | null>(null);
  const [consoleLogs, setConsoleLogs] = useState<string[]>([
    'Validation Lab initialized with libFuzzer and SMT Invariant Prover.',
    'Ready to execute test harness against synthesized AST patches.',
  ]);

  const currentVuln: Vulnerability =
    MOCK_VULNERABILITIES.find((v) => v.id === selectedVulnId) ||
    MOCK_VULNERABILITIES[0];

  const handleRunAllTests = () => {
    setIsRunning(true);
    setConsoleLogs([
      `[00:00.01] Starting formal verification suite for ${currentVuln.id} (${currentVuln.cwe})...`,
      `[00:00.05] Sandboxing process in ephemeral isolate container`,
      `[00:00.12] Injecting exploit vector simulation payloads...`,
    ]);

    let step = 0;
    const interval = setInterval(() => {
      if (step < currentVuln.validationTests.length) {
        const test = currentVuln.validationTests[step];
        setActiveTestIndex(step);
        setConsoleLogs((prev) => [
          ...prev,
          `[00:0${step + 1}.20] Running test: "${test.name}" (${test.type})`,
          `[00:0${step + 1}.45] Result: PASSED (${test.duration}) -> ${test.detail}`,
        ]);
        step++;
      } else {
        clearInterval(interval);
        setIsRunning(false);
        setActiveTestIndex(null);
        setConsoleLogs((prev) => [
          ...prev,
          `[00:0${step + 1}.80] All ${currentVuln.validationTests.length} tests completed successfully. Zero regressions detected!`,
        ]);
      }
    }, 900);
  };

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2.5 mb-1.5">
            <h1 className="text-2xl font-display font-bold text-white tracking-tight">
              Validation Lab & Regression Prover
            </h1>
            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/25 font-semibold">
              83% FLEET PASS RATE
            </span>
          </div>
          <p className="text-xs text-slate-300 mt-1">
            Automated exploit replay, fuzzing vectors, and functional regression harnesses verifying proposed code repairs.
          </p>
        </div>

        {/* Finding selector */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-mono text-slate-400">Target Finding:</label>
          <select
            value={currentVuln.id}
            onChange={(e) => onSelectVulnId(e.target.value)}
            disabled={isRunning}
            className="px-3.5 py-1.5 rounded-full bg-[#0A162B] border border-white/10 text-xs font-mono text-slate-100 outline-none focus:border-[#38BDF8] transition-colors"
          >
            {MOCK_VULNERABILITIES.map((v) => (
              <option key={v.id} value={v.id}>
                {v.cwe} - {v.title.slice(0, 35)}...
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Target Info Strip */}
      <div className="rounded-2xl glass-card p-5 border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full font-bold text-[#F87171] bg-[#F87171]/10 border border-[#F87171]/25">
              {currentVuln.cwe}
            </span>
            <span className="text-sm font-semibold text-white tracking-tight">
              {currentVuln.title}
            </span>
          </div>
          <span className="text-xs font-mono text-slate-400 block mt-1">
            {currentVuln.repository} · {currentVuln.file}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('remediation')}
            className="px-3.5 py-2 rounded-full bg-[#0A162B] hover:bg-white/10 border border-white/10 text-xs font-mono text-slate-200 transition-colors btn-press"
          >
            Review Code Diff
          </button>

          <button
            onClick={handleRunAllTests}
            disabled={isRunning}
            className={`inline-flex items-center gap-2 px-5 py-2 rounded-full text-xs font-mono font-bold transition-all btn-press ${
              isRunning
                ? 'bg-[#122444] text-[#38BDF8] border border-[#38BDF8]/30 cursor-not-allowed shadow-md'
                : 'btn-primary-pill text-[#070E1B] cursor-pointer'
            }`}
          >
            {isRunning ? (
              <>
                <Cpu size={14} className="animate-spin text-[#38BDF8]" />
                <span>Running Harness...</span>
              </>
            ) : (
              <>
                <Play size={14} className="fill-current text-[#070E1B]" />
                <span>Execute Test Suite ({currentVuln.validationTests.length})</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Test Suite Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Test items (7 cols) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between text-xs font-mono text-slate-300 px-1">
            <span className="uppercase text-[10px] tracking-wider text-slate-400 font-semibold">Automated Verification Vectors</span>
            <span className="tabular-nums font-medium">{currentVuln.validationTests.length} Total Asserts</span>
          </div>

          <div className="space-y-3">
            {currentVuln.validationTests.map((test, index) => {
              const isExecutingThis = isRunning && activeTestIndex === index;

              return (
                <div
                  key={test.name}
                  className={`p-4 rounded-2xl border transition-all ${
                    isExecutingThis
                      ? 'bg-[#122444] border-[#38BDF8] shadow-[0_0_20px_rgba(56,189,248,0.2)]'
                      : 'glass-card border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      {test.status === 'passed' ? (
                        <CheckCircle2 size={16} className="text-[#10B981] shrink-0 mt-0.5" />
                      ) : (
                        <XCircle size={16} className="text-[#F87171] shrink-0 mt-0.5" />
                      )}
                      <div>
                        <span className="text-xs font-semibold text-white block">
                          {test.name}
                        </span>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[10px] font-mono px-2 py-0.2 rounded-full bg-white/5 border border-white/10 text-slate-300">
                            {test.type}
                          </span>
                          <span className="text-[10px] font-mono text-[#10B981] tabular-nums font-semibold">
                            Latency: {test.duration}
                          </span>
                        </div>
                      </div>
                    </div>

                    <span
                      className={`text-[10px] font-mono uppercase px-2.5 py-0.5 rounded-full font-bold ${
                        test.status === 'passed'
                          ? 'text-[#10B981] bg-[#10B981]/15 border border-[#10B981]/25'
                          : 'text-[#F87171] bg-[#F87171]/15 border border-[#F87171]/25'
                      }`}
                    >
                      {test.status}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 mt-2.5 pl-6 font-mono leading-relaxed bg-[#060D1A]/70 p-3 rounded-xl border border-white/5">
                    {test.detail}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Real-time Test Output Console (5 cols) */}
        <div className="lg:col-span-5 rounded-2xl glass-card p-5 border border-white/10 space-y-3 font-mono shadow-xl">
          <div className="flex items-center justify-between text-xs pb-2 border-b border-white/10 text-slate-300">
            <div className="flex items-center gap-2">
              <Terminal size={14} className="text-[#10B981]" />
              <span>Regression Runner Telemetry</span>
            </div>
            <span className="text-[10px] text-slate-400">Docker Ephemeral Pod</span>
          </div>

          <div className="h-80 overflow-y-auto bg-[#060D1A] p-3.5 rounded-xl border border-white/10 text-xs space-y-2">
            {consoleLogs.map((log, i) => (
              <div
                key={i}
                className={`leading-relaxed text-[11px] ${
                  log.includes('PASSED') || log.includes('Zero regressions')
                    ? 'text-[#10B981]'
                    : log.includes('Starting') || log.includes('Injecting')
                    ? 'text-[#38BDF8]'
                    : 'text-slate-300'
                }`}
              >
                {log}
              </div>
            ))}
          </div>

          <div className="p-3.5 rounded-xl bg-[#0A162B] border border-white/10 text-xs space-y-1">
            <span className="text-[10px] font-mono uppercase text-slate-400 block font-semibold">
              Formal Invariant Status:
            </span>
            <span className="text-white font-semibold flex items-center gap-1.5">
              <ShieldCheck size={14} className="text-[#10B981]" />
              Verified & Proof-Carrying Code Invariant
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { Sidebar, NavigationTab } from './components/Sidebar';
import { TopNav } from './components/TopNav';
import { CommandPalette } from './components/CommandPalette';
import { OverviewView } from './components/OverviewView';
import { NewScanView } from './components/NewScanView';
import { VulnerabilitiesView } from './components/VulnerabilitiesView';
import { RemediationWorkbench } from './components/RemediationWorkbench';
import { ValidationLabView } from './components/ValidationLabView';
import { ScanHistoryView } from './components/ScanHistoryView';
import { ReportsView } from './components/ReportsView';
import { SettingsView } from './components/SettingsView';
import { MOCK_SUMMARY, MOCK_VULNERABILITIES, ScanRecord } from './data/mockData';
import { X } from 'lucide-react';
import { BrandLogo } from './components/BrandLogo';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavigationTab>('overview');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [selectedVulnId, setSelectedVulnId] = useState<string>(MOCK_VULNERABILITIES[0].id);
  const [selectedScan, setSelectedScan] = useState<ScanRecord | null>(null);

  // Keyboard shortcut for Cmd+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleNavigate = (tab: NavigationTab) => {
    setCurrentTab(tab);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectVulnerability = (id: string) => {
    setSelectedVulnId(id);
  };

  const handleSelectScan = (scan: ScanRecord) => {
    setSelectedScan(scan);
  };

  const handleTriggerNewScan = () => {
    setCurrentTab('new-scan');
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#070E1B] text-[#F1F5F9] bg-ambient-grid flex flex-col antialiased selection:bg-[#38BDF8]/30 selection:text-white">
      {/* Desktop & Tablet Layout Wrapper */}
      <div className="flex flex-1 min-h-screen relative">
        {/* Persistent Desktop Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={handleNavigate}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          criticalCount={MOCK_SUMMARY.criticalFindings}
          totalFindings={MOCK_SUMMARY.totalFindings}
        />

        {/* Mobile Navigation Drawer Overlay */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            <div
              className="fixed inset-0 bg-black/80 backdrop-blur-md"
              onClick={() => setMobileMenuOpen(false)}
            />
            <div className="relative w-72 max-w-[85vw] bg-[#081224] border-r border-white/10 h-full flex flex-col justify-between z-10 p-5">
              <div className="flex items-center justify-between pb-4 border-b border-white/10">
                <BrandLogo collapsed={false} size="sm" />
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-white/10"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="mt-4 flex-1 overflow-y-auto space-y-1.5">
                {[
                  { id: 'overview', label: 'Overview' },
                  { id: 'new-scan', label: 'New Scan' },
                  { id: 'scan-history', label: 'Scan History' },
                  { id: 'vulnerabilities', label: 'Vulnerability Findings' },
                  { id: 'remediation', label: 'AI Remediation' },
                  { id: 'validation-lab', label: 'Validation Lab' },
                  { id: 'reports', label: 'Reports' },
                  { id: 'settings', label: 'Settings' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleNavigate(item.id as NavigationTab)}
                    className={`w-full text-left px-3.5 py-2.5 rounded-full text-xs transition-colors ${
                      currentTab === item.id
                        ? 'bg-[#122444] text-[#38BDF8] font-bold border border-[#38BDF8]/30 shadow-sm'
                        : 'text-slate-300 hover:bg-white/5 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              <div className="pt-4 border-t border-white/10 text-xs text-slate-400 font-mono">
                VULNEX AI · SecOps Engine v2.4
              </div>
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-w-0">
          <TopNav
            currentTab={currentTab}
            onOpenCommandPalette={() => setCommandPaletteOpen(true)}
            onOpenMobileMenu={() => setMobileMenuOpen(true)}
            onTriggerScanModal={handleTriggerNewScan}
          />

          <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
            {currentTab === 'overview' && (
              <OverviewView
                onNavigate={handleNavigate}
                onSelectScan={handleSelectScan}
                onTriggerScanModal={handleTriggerNewScan}
              />
            )}

            {currentTab === 'new-scan' && (
              <NewScanView
                onNavigate={handleNavigate}
                onSelectVulnerability={handleSelectVulnerability}
              />
            )}

            {currentTab === 'vulnerabilities' && (
              <VulnerabilitiesView
                onNavigate={handleNavigate}
                onSelectVulnerability={handleSelectVulnerability}
                selectedVulnId={selectedVulnId}
              />
            )}

            {currentTab === 'remediation' && (
              <RemediationWorkbench
                onNavigate={handleNavigate}
                selectedVulnId={selectedVulnId}
                onSelectVulnId={handleSelectVulnerability}
              />
            )}

            {currentTab === 'validation-lab' && (
              <ValidationLabView
                onNavigate={handleNavigate}
                selectedVulnId={selectedVulnId}
                onSelectVulnId={handleSelectVulnerability}
              />
            )}

            {currentTab === 'scan-history' && (
              <ScanHistoryView
                onNavigate={handleNavigate}
                onSelectScan={handleSelectScan}
                selectedScan={selectedScan}
                onTriggerScanModal={handleTriggerNewScan}
              />
            )}

            {currentTab === 'reports' && <ReportsView />}

            {currentTab === 'settings' && <SettingsView />}
          </main>

          {/* Minimalist Professional Footer */}
          <footer className="border-t border-white/10 px-6 py-4 text-xs text-slate-400 font-mono flex flex-col sm:flex-row items-center justify-between gap-2 bg-[#070E1B]/85 backdrop-blur-md">
            <div className="flex items-center gap-2">
              <span className="text-white font-semibold">VULNEX AI</span>
              <span>·</span>
              <span>Find the flaw. Understand the risk. Patch with proof.</span>
            </div>
            <div className="flex items-center gap-4 text-[11px]">
              <span>AST Taint Engine Active</span>
              <span className="text-[#38BDF8] font-semibold">v2.4.0-preview</span>
            </div>
          </footer>
        </div>
      </div>

      {/* Global Command Palette Modal */}
      <CommandPalette
        isOpen={commandPaletteOpen}
        onClose={() => setCommandPaletteOpen(false)}
        onNavigate={handleNavigate}
        onSelectVulnerability={handleSelectVulnerability}
      />
    </div>
  );
}
